"""the collection and entry model for the Couchbox dashboard.

A collection is one file. An entry is a block inside it. Both are plain text and
line oriented, so a person can read one, write one, and see what is wrong with
one without needing a tool to tell them.

The format is deliberately not Pegasus's. Pegasus's metadata was the right shape
for Pegasus and its parser came with it, but adopting the format would mean this
project adopting the compatibility surface of a project it no longer ships.

The rules:

  - blank lines, and lines whose first non-space character is `#`, are ignored
  - `key: value` sets a key
  - `entry: value` starts a new entry, and the value is that entry's name
  - `collection` and `sort` are required at the top of the file
  - `launcher` is required in every entry

An unknown key is an error rather than something to skip. A misspelled key that
silently does nothing is the worst behaviour available here, because the file
still looks correct and the dashboard quietly disagrees with it.

An entry whose launcher does not exist is skipped rather than shown, and the
reason is written to the log. That is what keeps a collection honest on an image
where a wrapper is missing.

An entry may also name the catalogue id of the application behind it (`catalogue:`),
and then it is shown only while that application is installed. An application that
is not on the machine is not on the dashboard at all: a tile that explains that it
could have been installed is not what a person holding a controller came for, and
the store is where they would go instead. The store writes these entries when it
installs something, and removes them when it removes it.
"""

from __future__ import annotations

import dataclasses
import logging
import os
from collections.abc import Iterator
from pathlib import Path

log = logging.getLogger("couchbox.shell.entries")

# where the stable wrapper names live, searched in this order. applications are in
# the first, the system actions (sleep, restart, shutdown) in the second. the
# dashboard knows these two directories and nothing else about how anything is
# installed or started, which is the rule that keeps application packaging decisions
# out of the user interface.
#
# both are overridable so that a checkout can be checked without installing
# anything into /usr, which is what tests/check-collections.sh does.
def _dirs_from_env(variable: str, default: tuple[str, ...]) -> tuple[str, ...]:
    raw = os.environ.get(variable)
    if not raw:
        return default
    return tuple(part for part in raw.split(os.pathsep) if part)


LAUNCHER_DIRS = _dirs_from_env(
    "COUCHBOX_LAUNCHER_DIRS",
    ("/usr/lib/couchbox/launchers", "/usr/lib/couchbox/system"),
)

# the directory holding the system actions, which is the second one above. An entry whose
# wrapper is found here is something done to the machine rather than something to play, and
# that is the only test the overlay needs to offer the power actions: no collection name is
# matched, so a collection can be renamed or translated without the overlay noticing, and a
# system action that a later release adds appears in the overlay by existing.
SYSTEM_DIR = LAUNCHER_DIRS[1] if len(LAUNCHER_DIRS) > 1 else None

# read in this order, so a user's own collection is seen after the image's.
# neither directory is required to exist.
COLLECTION_DIRS = _dirs_from_env(
    "COUCHBOX_COLLECTION_DIRS",
    (
        "/usr/share/couchbox/collections",
        "/usr/local/share/couchbox/collections",
        str(Path.home() / ".local/share/couchbox/collections"),
    ),
)

COLLECTION_SUFFIX = ".collection"

# where the artwork for an entry lives when the entry does not name its own. A launcher called
# `kodi` gets `kodi.svg` here, which means a collection file does not have to repeat a path that
# is already implied by the wrapper it names, and adding artwork to an application is one file
# rather than one file and one edit. Overridable so that a checkout is checked without installing
# anything, the same as the two directories above.
ICON_DIR = Path(
    os.environ.get("COUCHBOX_ICON_DIR") or "/usr/share/couchbox/icons"
)

# where the applications' own icons live, fetched by `scripts/fetch-icons.py` and named after the
# wrapper. Kept apart from ICON_DIR because the two are different pictures of the same thing: the
# tile there is a coloured card with a category glyph, and the icon here is the mark a person
# recognises from the box. The interface draws the card and puts the icon on it.
APPICON_DIR = Path(
    os.environ.get("COUCHBOX_APPICON_DIR") or "/usr/share/couchbox/appicons"
)

# keys a collection file understands, and keys an entry understands. anything
# else is refused rather than ignored.
COLLECTION_KEYS = frozenset({"collection", "sort"})
ENTRY_KEYS = frozenset({"entry", "launcher", "description", "icon", "catalogue", "live-only"})


class CollectionError(Exception):
    """a collection file that cannot be trusted.

    This is raised rather than worked around. A collection that half loads is
    worse than one that refuses, because the user sees a dashboard that is
    quietly missing entries and has no reason to suspect the file.
    """

    def __init__(self, path: Path, line_number: int, message: str):
        self.path = path
        self.line_number = line_number
        self.message = message
        super().__init__(f"{path}:{line_number}: {message}")


@dataclasses.dataclass(frozen=True, slots=True)
class Entry:
    """one thing the dashboard can start.

    `launcher` is the name of a wrapper, never a path to an application binary,
    and never a command line. What a wrapper does with no arguments is the
    wrapper's business.
    """

    name: str
    launcher: str
    description: str = ""
    icon: str = ""

    # offered only while this machine is running from the medium. The installer is the case: an
    # installed machine offering to install itself is a machine offering to erase itself, and the
    # rule this project already has is that an application which is not installed is not on the
    # dashboard at all
    live_only: bool = False

    # the catalogue id of the application this entry starts, when there is one. Empty for an entry
    # the image ships rather than one the store wrote, which is why the power actions and the
    # bring-up entry are unaffected by it
    catalogue: str = ""

    @property
    def path(self) -> str:
        """where this entry's launcher actually is.

        Searched rather than assumed, because the wrapper directories hold two kinds
        of thing and an entry should not have to say which kind it is.
        """
        for directory in LAUNCHER_DIRS:
            candidate = os.path.join(directory, self.launcher)
            if os.path.isfile(candidate):
                return candidate
        # nothing matched, so report the conventional location. the caller is
        # expected to have asked exists() first, and this keeps the log line it
        # prints pointing at the place a missing wrapper should have been.
        return os.path.join(LAUNCHER_DIRS[0], self.launcher)

    def exists(self) -> bool:
        """is this entry runnable on this machine.

        Both the file and its executable bit are checked. A wrapper that is present
        but not executable is a packaging mistake, and a dashboard that offers it
        anyway turns that mistake into a tile that does nothing when pressed.
        """
        # COUCHBOX_LIVE is for the checks, which run on a machine that is not booted from the
        # medium and would otherwise report every live-only entry as missing its launcher
        if self.live_only and not (
            os.path.exists("/run/live/medium") or os.environ.get("COUCHBOX_LIVE")
        ):
            return False
        return any(
            os.path.isfile(os.path.join(directory, self.launcher))
            and os.access(os.path.join(directory, self.launcher), os.X_OK)
            for directory in LAUNCHER_DIRS
        )

    @property
    def system(self) -> bool:
        """is this an action done to the machine rather than something to start.

        The power actions are the case, and they are exactly the ones whose wrapper
        lives in the second launcher directory. The overlay offers those, because
        offering the user's games while a game is running is what the dashboard is
        for and not what an overlay over that game is for.
        """
        return bool(
            SYSTEM_DIR
            and os.path.isfile(os.path.join(SYSTEM_DIR, self.launcher))
        )

    def artwork(self) -> str:
        """where this entry's tile art is, as something a Qt image can load.

        The entry's own `icon` when it names one, and otherwise the file named after the
        launcher in the image's icon directory. An entry with neither returns the empty string,
        which the interface draws as a readable tile with the name on it rather than as a hole.

        `file://` is prepended because a bare absolute path is a *relative* URL to QML, and a
        relative URL starting with a slash resolves to nothing on a machine with no web server,
        which is every machine this ships to. Getting that wrong is an interface where every
        tile silently loses its artwork, which is why it is done here once rather than in QML.
        """
        given = self.icon or str(ICON_DIR / f"{self.launcher}.svg")
        if not given:
            return ""
        if given.startswith(("file://", "qrc:", "http://", "https://")):
            return given
        if "/" in given:
            return f"file://{given}"
        return given

    @property
    def appicon(self) -> str:
        """the application's own icon, or "" when there is not one.

        Empty rather than a fallback, because the fallback is the tile the interface already has:
        an entry with no icon of its own is a card with a category glyph on it, which is what this
        project shipped before it had any of these, and Warzone 2100 is the one entry left where
        that is still true.
        """
        for suffix in (".png", ".svg"):
            candidate = APPICON_DIR / f"{self.launcher}{suffix}"
            if candidate.is_file():
                return f"file://{candidate}"
        return ""

    @property
    def has_artwork(self) -> bool:
        """is there a file behind `artwork`, so the interface does not flash an empty tile."""
        candidate = self.icon or str(ICON_DIR / f"{self.launcher}.svg")
        if not candidate:
            return False
        if candidate.startswith(("qrc:", "http://", "https://")):
            return True
        if candidate.startswith("file://"):
            candidate = candidate[len("file://"):]
        return os.path.isfile(candidate)


@dataclasses.dataclass(frozen=True, slots=True)
class Collection:
    """a named group of entries, and where it belongs in the rail.

    `sort` is explicit rather than derived from the name or the file order. The
    power actions have to come last so that a mistimed press cannot land on
    Shut Down, and making that a property of the file rather than a rule in the
    code means the reason is visible where the entry is written.
    """

    name: str
    sort: int
    entries: tuple[Entry, ...]

    def as_dict(self) -> dict:
        return {
            "name": self.name,
            "sort": self.sort,
            "entries": [
                {
                    "name": entry.name,
                    "launcher": entry.launcher,
                    "description": entry.description,
                    # a URL rather than a path, and the launcher's own artwork when the entry
                    # names none. Empty when there is no file behind it, so the interface can
                    # draw a readable tile instead of waiting for an image that will not load
                    "icon": entry.artwork() if entry.has_artwork else "",
                    # the application's own mark, drawn over the card. Separate from `icon`
                    # because they are both pictures and only one of them is the tile
                    "appicon": entry.appicon,
                    # the catalogue id, so an interface can tell an entry the store wrote from
                    # one the image ships without matching on names
                    "catalogue": entry.catalogue,
                    # the overlay offers the system actions and nothing else, so a
                    # misspelled name here would be visible rather than silent
                    "system": entry.system,
                }
                for entry in self.entries
            ],
        }


def _split(line: str) -> tuple[str, str] | None:
    """split a `key: value` line, or return None for a line to ignore."""
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return None
    if ":" not in stripped:
        return "", ""
    key, _, value = stripped.partition(":")
    return key.strip().lower(), value.strip()


def parse_collection(path: Path, text: str) -> Collection:
    """parse one collection file, or raise CollectionError explaining why not."""
    name: str | None = None
    sort: int | None = None
    entries: list[Entry] = []
    current: dict[str, str] | None = None

    for number, line in enumerate(text.splitlines(), start=1):
        pair = _split(line)
        if pair is None:
            continue
        key, value = pair

        if key == "":
            raise CollectionError(path, number, "expected 'key: value', found neither")
        if current is not None and key in COLLECTION_KEYS and key != "entry":
            raise CollectionError(
                path, number, f"'{key}' belongs at the top of the file, before the first entry"
            )
        if key == "entry":
            if not value:
                raise CollectionError(path, number, "an entry needs a name")
            if current is not None:
                entries.append(_finish_entry(path, number, current))
            current = {"entry": value}
            continue
        if current is None:
            if key not in COLLECTION_KEYS:
                raise CollectionError(
                    path,
                    number,
                    f"'{key}' is not a collection key, expected one of {sorted(COLLECTION_KEYS)}",
                )
            if key == "collection":
                name = value
            else:
                try:
                    sort = int(value)
                except ValueError:
                    raise CollectionError(path, number, f"'sort' must be a whole number, got '{value}'") from None
            continue
        if key not in ENTRY_KEYS:
            raise CollectionError(
                path, number, f"'{key}' is not an entry key, expected one of {sorted(ENTRY_KEYS)}"
            )
        current[key] = value

    if current is not None:
        entries.append(_finish_entry(path, len(text.splitlines()) or 1, current))

    if name is None:
        raise CollectionError(path, 1, "no 'collection' line, so this file has no name")
    if sort is None:
        raise CollectionError(path, 1, "no 'sort' line, so this collection has no place in the rail")

    return Collection(name=name, sort=sort, entries=tuple(entries))


def _finish_entry(path: Path, line_number: int, fields: dict[str, str]) -> Entry:
    launcher = fields.get("launcher")
    if not launcher:
        raise CollectionError(
            path, line_number, f"entry '{fields['entry']}' has no 'launcher', so it cannot start anything"
        )
    if "/" in launcher:
        raise CollectionError(
            path,
            line_number,
            f"entry '{fields['entry']}' names a path ('{launcher}'). a launcher is a wrapper name, "
            "so that the dashboard never learns how anything is installed",
        )
    return Entry(
        name=fields["entry"],
        launcher=launcher,
        description=fields.get("description", ""),
        icon=fields.get("icon", ""),
        catalogue=fields.get("catalogue", ""),
        live_only=fields.get("live-only", "").strip().lower() == "yes",
    )


@dataclasses.dataclass(frozen=True, slots=True)
class LoadResult:
    """what could be used, and everything that could not."""

    collections: tuple[Collection, ...]
    problems: tuple[str, ...]


def load_report(directories: Iterator[str | Path] | None = None) -> LoadResult:
    """read every collection, and report everything that could not be used.

    The two callers want opposite things from the same reading, and this returns
    both so that they cannot disagree about it. The dashboard wants whatever it can
    get, because a section missing from the screen is a bug but a machine that will
    not start is a worse one. A repository check wants to hear about every problem,
    because there is nothing on screen to be wrong in its place.

    A collection with no usable entries is dropped rather than shown empty, because
    an empty section in the rail is a promise the machine cannot keep.
    """
    found: list[Collection] = []
    problems: list[str] = []
    seen: set[str] = set()

    for directory in directories if directories is not None else COLLECTION_DIRS:
        directory = Path(directory)
        if not directory.is_dir():
            continue
        for path in sorted(directory.glob(f"*{COLLECTION_SUFFIX}")):
            try:
                collection = parse_collection(path, path.read_text(encoding="utf-8"))
            except (CollectionError, OSError) as problem:
                problems.append(str(problem))
                continue

            # first one wins, so a user's own file cannot silently replace a section
            # the image provides by reusing its name
            if collection.name in seen:
                problems.append(f"{path}: another collection is already named '{collection.name}'")
                continue
            seen.add(collection.name)

            kept = tuple(entry for entry in collection.entries if entry.exists())
            for entry in collection.entries:
                if not entry.exists():
                    problems.append(
                        f"{path}: entry '{entry.name}' has no launcher named '{entry.launcher}' "
                        f"in {' or '.join(LAUNCHER_DIRS)}"
                    )

            if not kept:
                problems.append(
                    f"{path}: collection '{collection.name}' has no usable entries, so the "
                    "dashboard will not show it at all"
                )
                continue
            found.append(dataclasses.replace(collection, entries=kept))

    found.sort(key=lambda collection: (collection.sort, collection.name.lower()))
    return LoadResult(collections=tuple(found), problems=tuple(problems))


def load(directories: Iterator[str | Path] | None = None) -> list[Collection]:
    """the collections the dashboard can actually show, with problems logged.

    Problems are logged rather than raised, because a dashboard with one broken
    section is a bug while a dashboard that does not come up is a broken machine, and
    the person in front of it has a controller and no keyboard.
    """
    result = load_report(directories)
    for problem in result.problems:
        log.error("%s", problem)
    return list(result.collections)
