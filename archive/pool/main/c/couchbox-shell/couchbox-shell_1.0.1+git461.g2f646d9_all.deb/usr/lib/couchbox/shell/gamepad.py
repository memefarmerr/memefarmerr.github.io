"""gamepad input, translated into the same key events the keyboard produces.

The dashboard has exactly one navigation model, and this module is why. A gamepad
button and a keyboard key both arrive at QML as a Qt key event, so the interface
cannot tell them apart and therefore cannot support one without the other.
"Everything important is reachable with a gamepad and with a keyboard" stops being
a rule a contributor has to remember and becomes a property of the design.

SDL2 rather than reading the input devices directly, because SDL2 carries the
controller database. That database maps several hundred controllers by their own
identifiers and grows as hardware is released, and maintaining it is not this
project's work.

Two details that are easy to get wrong:

  - The polling runs on a worker thread, and the key events are emitted as a Qt
    signal so they are delivered on the thread Qt is running on. Posting an event
    to a window from another thread is not allowed, and it fails in ways that look
    like the application being unresponsive rather than like a threading mistake.

  - SDL must be started and pumped on the same thread. Starting it here and
    pumping it in the main loop would appear to work and would never deliver a
    button press.

The guide button is deliberately not handled here. It belongs to couchbox-guide,
which reads the devices directly, because this process only exists while the
dashboard is in front and the guide button has to work while something else is.
"""

from __future__ import annotations

import logging

from PySide6.QtCore import QObject, Qt, Signal, Slot

import controller_config

log = logging.getLogger("couchbox.shell.gamepad")

# gamepad button to Qt key. the interface handles the key and never asks where it
# came from, so anything added here is immediately reachable from both devices.
#
# Two of these depend on what the person chose in the settings: which button means yes (A on an
# Xbox controller, B on a Nintendo one) and which way the shoulder buttons move through a screen.
# They are applied by `key_for`, which is what a press is translated with, rather than by editing
# this table, so a change in the settings is picked up without restarting anything.
#
# The face buttons are the console layout rather than four more ways to cancel: A is yes, B is
# back, and Y is "the other view", which on the dashboard is the library grid and everywhere else
# is nothing. X is a second back, because every console has one and because a Nintendo pad's
# cancel is where an Xbox pad's X is.
BUTTON_TO_KEY = {
    "A": Qt.Key.Key_Return,
    "B": Qt.Key.Key_Escape,
    "X": Qt.Key.Key_Escape,
    "Y": Qt.Key.Key_Y,
    "DPAD_LEFT": Qt.Key.Key_Left,
    "DPAD_RIGHT": Qt.Key.Key_Right,
    "DPAD_UP": Qt.Key.Key_Up,
    "DPAD_DOWN": Qt.Key.Key_Down,
    "START": Qt.Key.Key_Menu,
    "BACK": Qt.Key.Key_Back,
    # the shoulder buttons move between regions rather than within one, which on a console is
    # what bumpers do: pages in the settings, the list and the queue in the store, sections on
    # the dashboard. They arrive as Tab and Shift+Tab, which is what a keyboard already uses
    # for exactly that (ADR-0034)
    "LEFT_SHOULDER": Qt.Key.Key_Backtab,
    "RIGHT_SHOULDER": Qt.Key.Key_Tab,
}


def forward_to_focus(window, key: int) -> None:
    """hand a controller button to whatever has the focus, as the key it stands for.

    Applications that are not the dashboard get their controller buttons this way, and the obvious
    way is wrong, which is worth writing down because it was wrong here for months.

    A key is delivered to the focused *control*, and Qt works that out for real platform key events
    only. An event sent by hand goes to the widget it is addressed to, and a QWidget passes a key
    up to its parent and never down to a child. The store and the settings sent their keys to the
    window, on the reasoning written in their own docstrings that Qt routes them through the focus
    chain. It does not: measured, with the focus on a child widget, the list did not move on Down,
    the category did not change on Right, and Return did not press the button. The only controller
    keys that worked were the shoulders, because QApplication handles focus traversal itself.

    So the target is the focused control, and the modal window first so that a dialog stays usable
    with a controller, which is what makes the settings' keypad work.

    And nothing at all when this window is not the one on screen. Applications keep running behind
    the dashboard by design, and this forwarded every press into a window nobody could see and
    called `activateWindow` on it, which took the screen back on every button press.
    """
    from PySide6.QtCore import QCoreApplication, QEvent, Qt
    from PySide6.QtGui import QKeyEvent
    from PySide6.QtWidgets import QApplication, QPushButton

    modal = QApplication.activeModalWidget()
    if modal is None and not window.isActiveWindow():
        return

    target = modal or QApplication.focusWidget() or QApplication.activeWindow() or window
    if target is None:
        return

    # A button that is not in a dialog does not answer Return, only Space, which is a fact about
    # QPushButton rather than about controllers. A is Return everywhere else, and on a button it
    # is Space, so that pressing A works on every button in both applications without setting
    # autoDefault on thirteen of them and forgetting the fourteenth.
    if isinstance(target, QPushButton) and key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
        key = Qt.Key.Key_Space

    for kind in (QEvent.Type.KeyPress, QEvent.Type.KeyRelease):
        QCoreApplication.sendEvent(target, QKeyEvent(kind, key, Qt.KeyboardModifier.NoModifier))


def key_for(button_name: str) -> int | None:
    """the Qt key a controller button stands for, with the person's own settings applied.

    Called on the way to every press rather than once at startup, so that changing the confirm
    button in the settings reaches a dashboard that is already running. The settings module
    keeps its own one-second cache, so this is a stat call at worst.
    """
    settings = controller_config.settings()

    if settings["confirm"] == "b":
        # the Nintendo layout, where the right-hand button confirms. B confirms and A cancels,
        # which is what somebody holding a Nintendo controller expects without being told. X and
        # Y swap with them, because on a Nintendo pad the top face button is where an Xbox pad's
        # left one is: leaving them alone would put the view toggle under a different finger from
        # the one that has been finding it all evening
        if button_name == "A":
            return Qt.Key.Key_Escape
        if button_name == "B":
            return Qt.Key.Key_Return
        if button_name == "X":
            return Qt.Key.Key_Y
        if button_name == "Y":
            return Qt.Key.Key_Escape

    if settings["bumpers"] == "swapped":
        if button_name == "LEFT_SHOULDER":
            button_name = "RIGHT_SHOULDER"
        elif button_name == "RIGHT_SHOULDER":
            button_name = "LEFT_SHOULDER"

    return BUTTON_TO_KEY.get(button_name)

# which SDL controller buttons those names are. kept separate from the table above
# so that the mapping reads as the interface's business and this reads as SDL's.
SDL_BUTTONS = {
    "A": "SDL_CONTROLLER_BUTTON_A",
    "B": "SDL_CONTROLLER_BUTTON_B",
    "X": "SDL_CONTROLLER_BUTTON_X",
    "Y": "SDL_CONTROLLER_BUTTON_Y",
    "DPAD_LEFT": "SDL_CONTROLLER_BUTTON_DPAD_LEFT",
    "DPAD_RIGHT": "SDL_CONTROLLER_BUTTON_DPAD_RIGHT",
    "DPAD_UP": "SDL_CONTROLLER_BUTTON_DPAD_UP",
    "DPAD_DOWN": "SDL_CONTROLLER_BUTTON_DPAD_DOWN",
    "START": "SDL_CONTROLLER_BUTTON_START",
    "BACK": "SDL_CONTROLLER_BUTTON_BACK",
    "LEFT_SHOULDER": "SDL_CONTROLLER_BUTTON_LEFTSHOULDER",
    "RIGHT_SHOULDER": "SDL_CONTROLLER_BUTTON_RIGHTSHOULDER",
}


class Gamepad(QObject):
    """watches the controllers and reports button presses as key events.

    If SDL is not installed, or there are no controllers, this reports that once
    and then does nothing. A machine with no gamepad is a supported machine: the
    keyboard is a first-class input device, not a fallback.
    """

    keyPressed = Signal(int)

    def __init__(self, parent: QObject | None = None):
        super().__init__(parent)
        self._thread = None
        self._worker = None
        self._controller = None
        self._button_map: dict[int, int] = {}
        self._sdl = None

    def start(self) -> bool:
        """start watching. returns False if there is nothing to watch with."""
        try:
            import sdl2
        except ImportError:
            log.warning("python3-sdl2 is not installed, so controllers will not work")
            return False

        self._sdl = sdl2

        from PySide6.QtCore import QThread

        # and this watches whether or not one is attached right now, because a pad plugged in after
        # the installer started is opened when SDL says it arrived. It used to say nothing either
        # way, so the line a person reads to find out whether their controller will work said
        # "watching the controllers" on a machine with none; that is the caller's sentence to get
        # right, and it says "watching for controllers" now.
        self._worker = _Worker(sdl2, dict(SDL_BUTTONS))
        self._thread = QThread()
        self._worker.moveToThread(self._thread)
        self._worker.keyPressed.connect(self.keyPressed)
        self._thread.started.connect(self._worker.run)
        self._thread.start()
        return True

    @Slot()
    def stop(self) -> None:
        if self._worker is not None:
            self._worker.stop()
        if self._thread is not None:
            self._thread.quit()
            self._thread.wait(2000)
            self._thread = None


class _Worker(QObject):
    keyPressed = Signal(int)

    def __init__(self, sdl2, sdl_buttons: dict[str, str]):
        super().__init__()
        self._sdl = sdl2
        self._sdl_buttons = sdl_buttons
        self._running = False
        self._controller = None
        # the instance id of the open controller, which is what a removal event names
        self._instance = None

    @Slot()
    def run(self) -> None:
        sdl2 = self._sdl

        # the game controller subsystem, not the joystick one, because only this
        # one applies the database that makes an arbitrary controller look like a
        # standard one
        if sdl2.SDL_Init(sdl2.SDL_INIT_GAMECONTROLLER) != 0:
            log.error("SDL could not start: %s", sdl2.SDL_GetError())
            return

        self._running = True
        log.info("looking for controllers")

        while self._running:
            event = sdl2.SDL_Event()
            while sdl2.SDL_PollEvent(event) != 0:
                self._handle(event)

            if self._controller is None:
                self._open_first_controller()

            # 5ms. fast enough that a button never feels late, slow enough that
            # this is invisible in a process listing on the hardware this targets
            sdl2.SDL_Delay(5)

        self._close_controller()
        sdl2.SDL_QuitSubSystem(sdl2.SDL_INIT_GAMECONTROLLER)

    def _open_first_controller(self) -> None:
        sdl2 = self._sdl
        for index in range(sdl2.SDL_NumJoysticks()):
            if not sdl2.SDL_IsGameController(index):
                continue
            self._controller = sdl2.SDL_GameControllerOpen(index)
            if self._controller is None:
                log.error("could not open controller %d: %s", index, sdl2.SDL_GetError())
                continue
            # what this controller is, so that it can be recognised when it is the one that went
            # away. SDL numbers devices as they arrive and reuses the numbers, and the removal
            # event carries the instance rather than the index for exactly this reason
            self._instance = sdl2.SDL_JoystickInstanceID(
                sdl2.SDL_GameControllerGetJoystick(self._controller)
            )
            name = sdl2.SDL_GameControllerName(self._controller)
            log.info("controller %d attached: %s", index, name.decode() if name else "unnamed")
            return

    def _close_controller(self) -> None:
        if self._controller is not None:
            self._sdl.SDL_GameControllerClose(self._controller)
            self._controller = None
            self._instance = None

    def _handle(self, event) -> None:
        sdl2 = self._sdl
        kind = event.type

        if kind == sdl2.SDL_CONTROLLERDEVICEADDED:
            if self._controller is None:
                self._open_first_controller()
            return
        if kind == sdl2.SDL_CONTROLLERDEVICEREMOVED:
            # only the controller that went away. This closed whatever was open, so unplugging a
            # second pad closed the first one: it was reopened on the next pass of the loop, and
            # every button pressed in that gap was lost, which a person sees as a controller that
            # stops answering for a moment when somebody unplugs the other one
            if getattr(event, "cdevice", None) is not None \
                    and event.cdevice.which == self._instance:
                self._close_controller()
            return
        if kind != sdl2.SDL_CONTROLLERBUTTONDOWN:
            return

        button = event.cbutton.button
        for name, sdl_name in self._sdl_buttons.items():
            if getattr(sdl2, sdl_name) == button:
                # asked per press rather than remembered from startup, so that the settings
                # application changing the confirm button is felt the next time one is pressed
                key = key_for(name)
                if key is not None:
                    log.debug("gamepad %s -> key %s", name, key)
                    self.keyPressed.emit(int(key))
                return

        # a button nobody mapped. logging it is how the tables above get extended
        # honestly, rather than by guessing which button number a controller uses.
        log.info("gamepad button %d is not mapped to anything", button)

    def stop(self) -> None:
        self._running = False
