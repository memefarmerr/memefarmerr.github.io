"""the Qt side of the Couchbox dashboard: the window, and starting things.

Separated from couchbox-shell so that the entry point can answer --check without a
GUI toolkit installed. Nothing else in the project depends on this module.

The shape is small on purpose. QML gets the entries and two slots and owns its own
navigation state, because a view that has to ask Python where the focus is produces
a round trip for something the view already knew.
"""

from __future__ import annotations

import dataclasses
import logging
import os
import re
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import (
    Property,
    QCoreApplication,
    QEvent,
    QObject,
    QProcess,
    Qt,
    QTimer,
    QUrl,
    Signal,
    Slot,
)
from PySide6.QtGui import QGuiApplication, QKeyEvent
from PySide6.QtQml import QQmlApplicationEngine, qmlRegisterSingletonInstance

import entries as entry_model
import gamepad as gamepad_input
import hotkey as hotkey_input
import recent as recent_model
import systeminfo
import update_config

# the catalogue and the question "is this application on the machine". They live in the parent
# directory because the store's own command line and its application read them too: one catalogue,
# one parser, one answer (ADR-0026), and this is the third reader of it
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

try:
    import store as store_model
except ImportError as error:  # pragma: no cover - a broken image
    store_model = None
    # spelled out rather than through the module's own logger, which is defined below this point
    logging.getLogger("couchbox.shell").warning(
        "the catalogue is not available, so entries cannot be checked against it: %s", error
    )

log = logging.getLogger("couchbox.shell")

# where this directory is, so the QML beside it is found without a build step
HERE = Path(__file__).resolve().parent

# the program that gives an application a process group of its own.
#
# Pausing an application has to stop what the application started as well, or a wrapper that
# starts a game and waits for it would leave the game drawing behind the overlay while the
# wrapper is the thing that stopped. QProcess can do this in C++ through
# setChildProcessModifier, and that setter is **not bound in PySide6** while the signal that
# reports it failing is, which is the worst of both: the design looks supported, the attribute
# check that looks like it covers the case reports a signal rather than a method, and the
# process everything depends on then never becomes a group leader. That was measured rather
# than reasoned about, by asking a running application what its group was.
#
# So the application is started through setsid instead. It is util-linux, it is essential in
# Debian, and it does not fork when the process calling it is not already a group leader,
# which is this case: the pid QProcess watches stays the pid of the application itself, which
# is what the launcher rules depend on. A machine that somehow lacks it still starts
# applications and still pauses them, one process at a time, and says so in the log.
# the one thing allowed to install anything, and the only program this dashboard runs as
# root. The sudoers rule grants this file and nothing else, and what the file accepts is a
# verb and a catalogue id, so the privilege is bounded by its own arguments (ADR-0026)
HELPER = "/usr/lib/couchbox/couchbox-store-helper"

SETSID = next(
    (path for path in ("/usr/bin/setsid", "/bin/setsid") if os.access(path, os.X_OK)),
    None,
)

# How long after one guide word a second one is still the same press.
#
# A keyboard reaches the dashboard twice, because the window manager binds the key as well as the
# guide reading the devices, and both of them act on the press: the two words arrive milliseconds
# apart and this is what makes that harmless. It is short on purpose. It was raised to a second and
# a half to cover a key that was held, because the guide used to send its word on the release and a
# held key therefore opened the overlay and closed it again; the guide sends on the press now, so a
# held key sends one word like a tap does, and a person who presses the key twice deliberately gets
# two presses rather than one.
GUIDE_REPEAT_SECONDS = 0.4

# how long an application is given to stop when it is asked to, before it is made to. Four
# seconds is longer than a program that handles the request needs and shorter than a person
# pressing a key twice and deciding it does not work
# How long an application is given to leave after being asked, before it is made to.
#
# It was four seconds, and four seconds is a long time to look at a frozen overlay: long enough to
# conclude that the row did nothing and press it again, which is exactly what was reported. The
# grace exists for the application that wants to save something on the way out, and an application
# that wants to save something answers within a second or it is not saving anything. The settings
# and the store are Qt programs with a thread each and they die on the request; a game that ignores
# it is still killed, just sooner.
# The status the dashboard exits with when it wants to be started again, which happens when an
# update has replaced the package it is running from. Any other status is either a person quitting
# (zero) or a fault, and the session acts on all three differently. It is 75 because it is unused by
# anything else and because a status is the only thing a dying process can say.
EXIT_FOR_AN_UPDATE = 75

# and the status for leaving because somebody asked, which is what a plain exit is
EXIT_OK = 0

STOP_GRACE_MS = 1200

# an application is given a starting screen rather than a black one, and the dashboard gets out
# of the way only once the application has a window of its own (ADR-0034). These are how often
# that window is looked for, how long the look is kept up before the dashboard yields anyway,
# and the program that answers the question: xprop is in the image already, because
# couchbox-xsession reads the same root property to tell whether a dashboard is running
LAUNCH_WATCH_MS = 250
LAUNCH_GIVE_UP_SECONDS = 30
# the one program that can tell X which window should be in front, for switching between
# applications that are already running
XDOTOOL = next(
    (path for path in ("/usr/bin/xdotool", "/bin/xdotool") if os.access(path, os.X_OK)),
    "/usr/bin/xdotool",
)

XPROP = next(
    (path for path in ("/usr/bin/xprop", "/bin/xprop") if os.access(path, os.X_OK)),
    None,
)

# how often the install engine's state file is read, so that the strip on screen is never more
# than a moment behind what the machine is actually doing
INSTALL_POLL_MS = 600

# how often the dashboard asks what the machine is doing: the clock and the battery are file
# reads and cost nothing, so they are asked often enough that the minute rolls over when it
# should; the network name is a command and is asked on every third pass, which is a slow
# enough timer for an indicator and quiet enough for hardware from 2012.
#
# None of it runs while an application is in front, because the shell goes completely quiet
# then (see _poll_system), so the cost of all of this while somebody is playing a game is zero.
SYSTEM_POLL_MS = 5000
SYSTEM_SLOW_EVERY = 3

# how many of the machine's recently started applications the overlay offers. The panel has to
# fit on a 720 high screen with the quick settings and the power rows beneath it, and a list of
# everything ever started is a library rather than a shortcut. Four is what fits with room to
# spare, and the dashboard is where the whole list lives
RECENT_ROWS_SHOWN = 4

# how far one press of a volume row moves the sink, as a percentage
VOLUME_STEP = 5


@dataclasses.dataclass(eq=False)
class RunningApplication:
    """one application this dashboard started.

    Several of these run at once, and the dashboard is hidden for only one of them: the front
    application, the most recently shown. Everything needed to manage one lives here rather
    than in a handful of parallel attributes, because an application such as Steam is itself a
    service that keeps running while the user does something else, and a single process-shaped
    slot cannot tell that apart from one that has gone away.

    `entry` is kept whole rather than unpacked, because the wrapper's name, its path and the
    name a person sees all belong to the entry, and a second copy here is a second copy that
    can disagree with the tiles on the dashboard.

    `paused_group` is the process group the overlay stopped, if this is the application it
    stopped. It is a group rather than a pid because stopping one process of a wrapper that
    started something else leaves the thing the user is looking at running.

    `eq=False` because a record is an identity rather than a value: the same application
    started twice is two records, and one of them must stay findable after its own signals
    have arrived.
    """

    name: str
    entry: entry_model.Entry
    process: QProcess
    # whether the stop that is happening was asked for, which decides whether the dashboard
    # says anything about it: a person who chose Close does not need to be told that the
    # thing they closed closed, and reporting it as an error was exactly the noise that made
    # stopping a game feel like a fault
    stop_requested: bool = False
    paused_group: int | None = None

    @property
    def launcher(self) -> str:
        """the stable wrapper name the application was started from, and is found by."""
        return self.entry.launcher

    @property
    def paused(self) -> bool:
        """whether the overlay has this application stopped, which only it may do."""
        return self.paused_group is not None


@dataclasses.dataclass(eq=False)
class SystemAction:
    """a one-off command the overlay ran, such as sleeping or restarting the machine.

    Not an application: it is not reported by `runningApplications`, the dashboard is never
    hidden for it, and none of the application lifecycle applies to it. What it needs is the
    finish that brings the dashboard back after a sleep, which is why its process is watched
    at all.
    """

    name: str
    process: QProcess


class Shell(QObject):
    """everything QML is allowed to know about."""

    collectionsChanged = Signal()
    statusChanged = Signal()
    overlayChanged = Signal()
    recentChanged = Signal()
    # which applications are running, which the overlay reads to decide which rows make
    # sense. separate from the overlay's own signal because the two change at different
    # moments and a row that says "resume" while nothing is running is worse than no row
    runningChanged = Signal()
    # The tiles depend on what is running and on which of them is in front, and neither of those
    # is a change to whether the overlay is open. They were declared against `overlayChanged`,
    # which is emitted when the overlay opens and closes and at no other time, so a tile row could
    # have gone on drawing an application that had already exited.
    tilesChanged = Signal()
    # an application is starting and its window is not on screen yet. the dashboard draws a
    # starting screen while this is true (ADR-0034)
    launchingChanged = Signal()
    # what the install engine is doing, read from its state file. the dashboard shows a strip
    # while something is installing, whether or not the store window is open (ADR-0033)
    installsChanged = Signal()
    # the rows the overlay offers changed: something started, something stopped, the recent list
    # moved, or the collections were read again
    overlayActionsChanged = Signal()
    # the machine's own state moved: the clock, the battery, the network, the volume. One signal
    # for all of it, because they are read together and a dashboard redrawing four separate
    # corners of itself for one poll would be four times the work for the same picture
    systemChanged = Signal()

    # the network readings, which run programs, come back from a thread through this. A signal
    # rather than a queue because Qt already delivers one on the thread that owns this object, which
    # is the thread that draws
    systemRead = Signal(object)

    # where a paused application's process group is written, so that a dashboard which
    # dies while something is paused can be recovered from. See _pause_application.
    PAUSED_MARKER = "couchbox-paused"

    def __init__(self, windowed: bool = False, size: tuple[int, int] | None = None):
        super().__init__()
        self._windowed = windowed
        # the size to lay out. in fullscreen the window manager sizes the window and
        # this is not used, but the layout is a function of the window size, so in a
        # window this reproduces any screen exactly. 1280x720 is the reference.
        self._size = size if size is not None else (1280, 720)
        self._collections: list[entry_model.Collection] = []
        self._status = ""
        # everything this dashboard started, oldest first. The last one is the front
        # application: the one most recently shown, which the dashboard is hidden for.
        #
        # A list rather than a single process, because applications such as Steam start
        # services of their own and keep running while the user does something else, and
        # refusing a second start was the thing that made that impossible
        self._running: list[RunningApplication] = []
        # the one-off system command the overlay last ran, if it is still running. It is not
        # an application: it is not in runningApplications, the dashboard is never hidden for
        # it, and none of the application lifecycle applies to it
        self._system_action: SystemAction | None = None
        self._window = None
        self._overlay_window = None
        self._gamepad: gamepad_input.Gamepad | None = None
        self._hotkeys: hotkey_input.HotkeyServer | None = None
        self._overlay = False
        # whether an application, rather than the dashboard, is the thing on screen. It
        # decides two things: whether the dashboard window is hidden, and which shape the
        # overlay takes when it opens. The guide key no longer means anything different in
        # the two cases: it opens the overlay wherever the person is (ADR-0042)
        self._application_in_front = False
        # whether an application can be given a process group of its own, which is what makes
        # pausing it mean pausing everything it started
        self._own_group = SETSID is not None
        # see `_start`: every process this dashboard started, so that the handlers attached to it
        # can be detached whether or not it is still running
        self._processes: list[QProcess] = []
        # when the last guide word arrived, so that the same press arriving twice is one press
        self._last_guide = 0.0
        # when this dashboard started, and whether a system update has since replaced the
        # Couchbox package it is running from. The two are compared so that the update which
        # replaced an older dashboard is seen by this one as history rather than as a second
        # restart; see _watch_for_update_restart
        self._started_at = time.time()
        self._restart_pending = False
        self._restart_acted = False
        # whether this start has already asked about updates, and what the answer was. The asking
        # happens on a thread of its own because it runs apt, which takes seconds and must not be
        # on the thread that draws the screen; the answer arrives here as a value and the poll
        # picks it up, which is the smallest thing that crosses between the two
        self._auto_update_state = "waiting"
        self._auto_update_answer: str | None = None
        # and whether an update has already been asked for from here, so that a machine which
        # cannot install one does not ask again on every poll for the rest of the day
        self._auto_update_asked = False
        # when the automatic check could not ask the sources anything. Kept so that the interface can
        # say so: "nothing to do" and "I could not find out" looked identical to a person, and the
        # second one means the machine is not being updated at all
        self._update_trouble = ""
        # and when to ask again after a question that could not be answered
        self._auto_update_retry_at: float | None = None
        self._auto_update_retries = 0
        # whether an application has been started whose window has not appeared yet, and the
        # name to show while that is true
        self._launching = False
        self._launching_name = ""
        self._launching_icon = ""
        self._launch_watcher: QTimer | None = None
        self._launch_deadline = 0.0
        # xprop answers or it does not. three answers that are not an answer in a row and the
        # dashboard stops asking, because a dashboard that can never notice an application is
        # worse than one that gets out of the way too early
        self._xprop_failures = 0
        # what the install engine is doing, as read from its state file
        self._install_timer: QTimer | None = None
        self._install_active = False
        self._install_text = ""
        self._install_percent = -1.0
        self._install_done_marker: tuple = ()
        self._recent = recent_model.load()
        # the machine's own state, read by the clock and the indicators along the top of the
        # screen. `_system_timer` is created in start_system_info, once the window exists, so a
        # Shell built by a check without a window polls nothing
        self._system_timer: QTimer | None = None
        self._system_passes = 0
        self._reading = False
        self.systemRead.connect(self._system_answered)
        self._clock = ""
        self._date = ""
        self._battery: tuple[int, bool] | None = None
        self._network_name = ""
        self._network_kind = ""
        self._has_network_hardware = False
        self._volume: tuple[int, bool] | None = None
        self._audio_available = False
        # what the volume was when the overlay's rows were last built, so that a volume change
        # rebuilds the overlay's quick settings and a change to anything else does not
        self._volume_at_last_actions: tuple[int, bool] | None = None
        self._profile = systeminfo.profile_name()
        self._version = systeminfo.version()
        self.reload()
        if not self._own_group:
            log.warning(
                "setsid is missing, so pausing an application stops only its own process. "
                "a wrapper that starts something else will leave that something on screen"
            )

    # --- what QML reads ------------------------------------------------------

    @Property("QVariantList", notify=collectionsChanged)
    def collections(self):
        return [collection.as_dict() for collection in self._collections]

    @Property(str, notify=statusChanged)
    def status(self):
        """a line of text for the user when there is something to say.

        Empty the rest of the time, so the interface shows nothing rather than an
        empty box with a border around it.
        """
        return self._status

    @Property(bool, constant=True)
    def windowed(self):
        return self._windowed

    @Property(bool, notify=overlayChanged)
    def overlayOpen(self):
        """is the overlay the thing on screen.

        One overlay, opened above whatever is in front, which the guide key opens and closes
        and never navigates with (ADR-0042). It is drawn in two places because there are two
        things it can be over: the dashboard draws it as a layer of its own window, and over
        a running application it is a small window of its own (ADR-0035). Either way it is
        the same list and nothing behind it changes.
        """
        return self._overlay

    @Property("QVariantList", notify=recentChanged)
    def recent(self):
        """the applications this machine has started, most recent first.

        Read by the overlay, which offers them as a way back to something. It is a list of
        launchers rather than of positions, so reorganising a collection does not break it.
        """
        return [item.as_dict() for item in self._recent]

    @Property(bool, notify=runningChanged)
    def applicationRunning(self):
        """is anything running at all, whatever it is and whether or not it is in front."""
        return bool(self._running)

    @Property("QVariantList", notify=runningChanged)
    def runningApplications(self):
        """every application this dashboard started, least recently shown first, the front one last.

        The interface reads this to list what is running, so that a machine running several
        applications at once is something a person can see rather than deduce from which window
        happens to be on top. The last entry is the front application, the one most recently shown,
        which is the one `runningName` names and the one a plain stop stops.

        The order is most-recently-shown and not the order things were started in. It was that,
        and `_switch_to` made it this: bringing an application forward moves it to the end. It is
        close to launch order on a machine where nothing has been switched to, which is exactly
        why nothing should read it as a fact about time. The `launcher` identifies an application
        and `front` says which one is in front, and a position in this list says neither.
        """
        front = self._front_application()
        return [
            {
                "name": application.name,
                "launcher": application.launcher,
                "front": application is front,
                "paused": application.paused,
            }
            for application in self._running
        ]

    @Property(str, notify=runningChanged)
    def runningName(self):
        """the front application's name, for a row that has to name it rather than say "the application".

        The front application is the one most recently shown, which is also the only one when
        only one is running. Empty when nothing is running, so the interface can tell the two
        states apart rather than showing a row that stops nothing.
        """
        application = self._front_application()
        return application.name if application is not None else ""

    @Property(int, constant=True)
    def windowWidth(self):
        """the width to lay out. the window manager overrides this when fullscreen."""
        return self._size[0]

    @Property(bool, notify=launchingChanged)
    def launching(self):
        """is an application starting, with no window of its own yet.

        The dashboard draws the name and a little motion while this is true, because the
        alternative was a black screen for as long as the application took to appear, which
        reads as the machine having stopped (ADR-0034).
        """
        return self._launching

    @Property(str, notify=launchingChanged)
    def launchingName(self):
        return self._launching_name

    @Property(str, notify=launchingChanged)
    def launchingIcon(self):
        """the artwork of the application that is starting, so the wait shows what is coming.

        Empty when the entry has no art, which the starting screen draws as the name alone.
        """
        return self._launching_icon

    @Property(bool, notify=installsChanged)
    def installActive(self):
        """is the install engine installing or removing anything."""
        return self._install_active

    @Property(str, notify=installsChanged)
    def installText(self):
        """what to say about it, in one line: the name, and how many are behind it."""
        return self._install_text

    @Property(float, notify=installsChanged)
    def installPercent(self):
        """how far along, or -1 when the engine cannot say yet, which is a bar that moves."""
        return self._install_percent

    @Property("QVariantList", notify=tilesChanged)
    def overlayTiles(self):
        """the row of places the overlay can take somebody, which is what a console guide is.

        The dashboard is always the first tile, because the way back to it is the thing a person
        reaches for most and a destination is easier to press than a verb. Every running
        application follows, marked if it is the one already in front.

        This is where the overlay is a switcher rather than a menu. It used to be a display row
        with a "Resume" row and a "Dashboard" row in the list below doing the same jobs as words:
        the tiles are those two destinations and one per application, and choosing one goes there.
        """
        front = self._front_application()
        tiles = [
            {
                "title": "Dashboard",
                "kind": "dashboard",
                "index": -1,
                "icon": self.couchSource,
                "detail": "",
                # "you are here" means the dashboard is the thing on screen, which is exactly when
                # no application is in front. This said the opposite, so opening the overlay over a
                # running application marked both the dashboard and the application as the current
                # place, and the panel lands on the first of those: the first press of the guide
                # took the person out of their game and back to the dashboard, which is the
                # opposite of what the guide key is for
                "front": not self._application_in_front,
            }
        ]
        for index, application in enumerate(self._running):
            tiles.append(
                {
                    "title": application.name,
                    "kind": "switch",
                    # the position is used at the moment it is pressed rather than trusted, and
                    # `launcher` is what it is checked against: this list is rebuilt whenever the
                    # running list changes, which now includes changing order
                    "index": index,
                    "launcher": application.launcher,
                    # The application's own icon when it has one, and this machine's own glyph when
                    # the application is one of the two this interface is made of. Neither Store nor
                    # Settings has an icon of its own, because they are not in the catalogue, so the
                    # switcher drew an opening letter beside a Dashboard tile that had a picture:
                    # that reads as a missing file rather than as a choice between two things. An
                    # application with neither still draws its letter, which is the right answer for
                    # a third-party program this project has no picture for.
                    "icon": application.entry.appicon
                    or systeminfo.icon(f"ui/{application.launcher}.svg"),
                    "detail": "",
                    "front": application is front and self._application_in_front,
                }
            )
        return tiles

    @Slot(str, str)
    def overlayActivateTile(self, kind: str, launcher: str) -> None:
        """choose one of the overlay's tiles: go there.

        The dashboard tile closes the overlay over the dashboard, and over an application it brings
        the dashboard back. An application tile brings that application forward, which is a switch
        rather than a start: it is already running.

        By kind and launcher rather than by position. The tile list is rebuilt whenever what is
        running changes, which includes an application exiting while the overlay is open, so a
        position the interface stored when it drew the row can name a different tile by the time it
        is pressed. The launcher is the stable name of the application and the kind says whether
        this is the dashboard, and both are what the press means.
        """
        if kind == "dashboard":
            self.showDashboard()
            return
        application = next(
            (item for item in self._running if item.launcher == launcher), None
        )
        if application is None:
            log.warning("'%s' is not running any more, so its tile does nothing", launcher)
            return
        if self._running[-1] is application and self._application_in_front:
            # already the thing on screen: the press means "let me back at it"
            self._set_overlay(False)
            self._resume_application(application)
            return
        self._switch_to(application)

    @Property("QVariantList", notify=overlayActionsChanged)
    def overlayActions(self):
        """the rows the overlay offers, built here rather than in the QML.

        The overlay is drawn in two places: over the dashboard, and in a small window of its own
        over a running application (ADR-0035). One list and one meaning for choosing a row, so
        the two places cannot drift apart, and the QML's only job is to draw what it is handed.

        A close row carries the name and the position of the application it closes, because with
        several running, "Close" on its own would be a question rather than a command.
        """
        items: list[dict] = []
        # No Resume and no Dashboard row. Both were destinations written as verbs, and both are
        # tiles in the row above now: the dashboard is the first tile and every running application
        # is one of the others. What is left here is what can be *done*, which is the other half of
        # a guide and the half a person does not want to hunt for.
        if self._running:
            # one close row per running application. The heading appears only when there is
            # more than one, so a single application needs no label to say what the row
            # below it closes
            if len(self._running) > 1:
                items.append(
                    {"title": "Running", "detail": "", "kind": "header", "key": "header:running"}
                )
            for index, application in enumerate(self._running):
                items.append(
                    {
                        # An application that has been asked to stop says so on its own row. The
                        # request is a signal and the answer is the process going away, which takes
                        # as long as the application takes: four seconds is the shell's patience
                        # and an application that is busy can use all of it. Until then nothing
                        # moved, and a row that does nothing for four seconds is a row a person
                        # presses again. Reported as "the close app feature does not work".
                        "title": (
                            f"Closing {application.name}..."
                            if application.stop_requested
                            else f"Close {application.name}"
                        ),
                        "detail": "closing" if application.stop_requested else "",
                        "kind": "stop",
                        # what identifies this row across a rebuild. The list is rebuilt whenever
                        # what is running changes, and a row that is a position moves under the
                        # person looking at it: the cursor was on "Close Kodi", a background
                        # application exited, and the cursor was on the recent row that slid up
                        # into that place with nothing pressed
                        "key": f"stop:{application.launcher}",
                        # Named rather than positioned. This carried an index into the running
                        # list as well, and the list is ordered now: bringing an application
                        # forward moves it, so a position captured when the row was built pointed
                        # at something else by the time it was pressed. The launcher is the stable
                        # identity and the name is what a person reads, and both are checked.
                        "name": application.name,
                        "launcher": application.launcher,
                    }
                )
        if self._recent:
            items.append(
                {"title": "Recent", "detail": "", "kind": "header", "key": "header:recent"}
            )
            for index, item in enumerate(self._recent[:RECENT_ROWS_SHOWN]):
                items.append(
                    {
                        "title": item.name,
                        "detail": "",
                        "kind": "recent",
                        "index": index,
                        "key": f"recent:{item.launcher}",
                        # what the row is *of*, drawn beside its name. A list of names is a list
                        # of words about games, and this machine has artwork for every one of
                        # them: a row with a picture on it is found by somebody who half
                        # remembers what they played last night
                        "artwork": self._artwork_for(item.launcher),
                    }
                )
        # the machine's own controls, above the power actions and below the applications, which
        # is where a console puts them: the rows a person reaches for while something is playing
        # come first, and the rows that stop the machine come last. Only what this machine can
        # actually do appears, so a machine with no audio stack has no volume rows at all
        # The volume is one control rather than three rows. It was "Volume up", "Volume down" and
        # "Mute" as three separate things to walk past, which is a list of the operations a person
        # could perform rather than a thing they can change: nobody wants to move a volume up, they
        # want it louder, and they want to see where it is. Left and right adjust it where it is and
        # A mutes it, so the whole of the audio is one row that shows its own level.
        # A row appears when there is a sink to move, and not merely when the machine has the
        # commands to move one with. Those were the same question while every machine that has
        # PipeWire has a sound card, and they are not: a virtual machine has `wpctl` and no sink at
        # all, and it drew a volume row that stepped nothing. The reading already says whether there
        # is an answer, and the rows are rebuilt when that answer changes, so the row appears the
        # moment a sink does.
        if self._volume is not None:
            level = self._volume[0]
            items.append(
                {"title": "Quick settings", "detail": "", "kind": "header", "key": "header:sound"}
            )
            items.append(
                {
                    "title": "Volume",
                    "detail": f"{level}%",
                    "kind": "volume",
                    "key": "volume",
                    "level": level,
                    "muted": bool(self._volume and self._volume[1]),
                }
            )
        system: list[dict] = []
        for collection_index, collection in enumerate(self._collections):
            for entry_index, entry in enumerate(collection.entries):
                if entry.system:
                    system.append(
                        {
                            "title": entry.name,
                            # no explanation follows a power row. What Sleep, Restart and
                            # Shut Down do is not a thing a controller-first interface
                            # should have to describe, and the descriptions the entries
                            # carry are for a person reading the files, not for a row
                            # somebody is trying to press from a couch
                            "detail": "",
                            "kind": "system",
                            "key": f"system:{entry.launcher}",
                            # the wrapper name, which is what identifies the entry. The two numbers
                            # beside it are where it was when the rows were built, and `reload` can
                            # move an entry by installing or removing an application, so they are a
                            # hint for the interface and never the thing that is acted on
                            "launcher": entry.launcher,
                            "collection": collection_index,
                            "entry": entry_index,
                        }
                    )
        if system:
            items.append(
                {"title": "Power", "detail": "", "kind": "header", "key": "header:power"}
            )
            items.extend(system)
        return items

    @Property(bool, notify=overlayChanged)
    def overlayOverApplication(self):
        """is the overlay drawn over a running application rather than over the dashboard.

        When it is, it is a small window of its own sitting over the application: the dashboard
        window is hidden while an application is in front, and raising the whole dashboard to
        draw a panel on it is what "the overlay switches to the dashboard" was (ADR-0035).
        """
        return self._overlay and bool(self._running) and self._application_in_front

    @Property(int, constant=True)
    def windowHeight(self):
        """the height to lay out. everything else in the layout scales from this."""
        return self._size[1]

    # --- the machine, along the top of the screen ----------------------------

    @Property(str, notify=systemChanged)
    def clock(self):
        """the time, as the machine's own locale writes it. Empty until the first poll."""
        return self._clock

    @Property(str, notify=systemChanged)
    def date(self):
        """the date, short enough to sit under the clock at a glance."""
        return self._date

    @Property(str, notify=systemChanged)
    def profileName(self):
        """what to call the person using this machine, for the profile chip."""
        return self._profile

    @Property(str, notify=systemChanged)
    def osVersion(self):
        """the Couchbox OS version this machine runs, for the overlay's footer.

        Shortened for the screen: see `systeminfo.friendly_version`. The full string is in the log
        and in `couchbox-settings --check`, which is where somebody debugging wants it.
        """
        return systeminfo.friendly_version(self._version)

    @Property(str, constant=True)
    def logoSource(self):
        """the Couchbox wordmark, drawn rather than set in a font, for the top of the screen."""
        return systeminfo.artwork("logo.svg")

    @Property(str, constant=True)
    def couchSource(self):
        """the couch mark on its own, for the overlay's dashboard tile.

        A tile is square and the wordmark is not, so the switcher draws the mark the wordmark is
        made of rather than a letter standing in for the dashboard.
        """
        return systeminfo.artwork("couch.svg")

    @Property(str, constant=True)
    def glowSource(self):
        """the soft light the dashboard puts behind the focused tile."""
        return systeminfo.artwork("glow.svg")

    @Property("QVariantMap", constant=True)
    def icons(self):
        """the small interface glyphs, by name, as URLs.

        One map rather than a property each, because they are all read the same way and a missing
        one has to come back as the empty string so the interface drops it rather than drawing a
        broken image. A machine whose artwork is missing entirely still draws a working console,
        which is the point: pictures are the last thing that should be able to stop the machine.
        """
        return {
            name: systeminfo.icon(f"ui/{name}.svg")
            for name in (
                "battery",
                "battery-full",
                "battery-charging",
                "wifi",
                "wired",
                "volume",
                "mute",
                "grid",
                "shelf",
                "back",
                "download",
            )
        }

    @Property(bool, notify=systemChanged)
    def batteryPresent(self):
        """is there a battery to report. False on a desktop, and then nothing is drawn."""
        return self._battery is not None

    @Property(int, notify=systemChanged)
    def batteryLevel(self):
        """the battery percentage, or 0 when there is no battery. Read with batteryPresent."""
        return self._battery[0] if self._battery else 0

    @Property(bool, notify=systemChanged)
    def batteryCharging(self):
        """is the machine on the mains. False when there is no battery, which is the same answer."""
        return self._battery[1] if self._battery else False

    @Property(bool, notify=systemChanged)
    def networkAvailable(self):
        """is there any network hardware at all, so the interface knows whether to show a chip."""
        return self._has_network_hardware

    @Property(bool, notify=systemChanged)
    def networkOnline(self):
        """is there a default route, which is the kernel's own answer to whether anything works."""
        return self._network_name != ""

    @Property(str, notify=systemChanged)
    def networkName(self):
        """the name of the network in use, in words a person recognises."""
        return self._network_name

    @Property(str, notify=systemChanged)
    def networkKind(self):
        """one of "wifi", "wired" or "" when there is no route."""
        return self._network_kind

    @Property(bool, notify=systemChanged)
    def volumeAvailable(self):
        """is there an audio sink to control. False means no volume row anywhere in the interface.

        A sink, and not merely the tool that would talk to one. This asked whether `wpctl` was
        installed, so a machine with the audio stack and no sound card drew a volume chip reading
        `0%` for ever, which is a number a person reads as "muted" or "broken". The overlay has
        always asked the other question, with a comment describing exactly this machine, so the two
        halves of the same interface disagreed about the same volume.
        """
        return self._volume is not None

    @Property(int, notify=systemChanged)
    def volumeLevel(self):
        """the default sink's volume, or 0 when there is none."""
        return self._volume[0] if self._volume else 0

    @Property(bool, notify=systemChanged)
    def volumeMuted(self):
        """is the default sink muted."""
        return self._volume[1] if self._volume else False

    # --- what QML calls -----------------------------------------------------

    @Slot()
    def reload(self):
        """read the collections again.

        Called at start and available from the interface, because the alternative is
        restarting the dashboard to pick up a file that changed.
        """
        self._collections = self._installed_only(entry_model.load())
        log.info("loaded %d collection(s): %s",
            len(self._collections),
            ", ".join(
                f"{collection.name}({len(collection.entries)})" for collection in self._collections
            )
            or "none",
        )
        self.collectionsChanged.emit()
        # the overlay's power rows are found in the collections, so they change with them
        self.overlayActionsChanged.emit()

    def _installed_only(self, collections):
        """drop the entries whose application is not on this machine.

        An entry that names a catalogue id is shown only while that application is installed,
        because that is the rule the whole store turns on: something that is not installed is not
        on the dashboard at all, rather than a tile that explains that it could be. An entry with no
        catalogue id is shown as it always was, which is what leaves the wrappers the image ships
        (the test entry, the power actions) alone.

        If the catalogue cannot be read, nothing is hidden. A dashboard that shows an entry it should
        not is a small fault the store can correct in a moment; a dashboard that shows nothing at all
        because a file went missing is the machine looking broken, which is much worse.
        """
        keep: set[str] | None = None

        if store_model is not None:
            try:
                # one pass over the catalogue, one question to dpkg per apt entry and one to
                # flatpak in total, rather than a subprocess per entry on every reload
                keep = store_model.installed_ids()
            except Exception as error:  # the catalogue is unreadable, or dpkg cannot be asked
                log.warning("entries were not filtered against the catalogue: %s", error)
                keep = None

        if keep is None:
            return collections

        kept = []
        for collection in collections:
            entries = tuple(
                entry for entry in collection.entries if not entry.catalogue or entry.catalogue in keep
            )
            if entries:
                kept.append(dataclasses.replace(collection, entries=entries))
            else:
                log.info("collection %s has nothing installed in it, so it is not shown", collection.name)
        return tuple(kept)

    @Slot(int, int)
    def launch(self, collection_index: int, entry_index: int):
        """start the entry at those positions, alongside anything already running.

        Starting an application never refuses because another one is running. The new
        application becomes the front one exactly the way the first one did, and the
        dashboard hides itself once the new application has a window of its own. The
        alternative closed the door on exactly the applications this machine exists to
        run: Steam is a client that stays running while the user does something else,
        and a second thing the user starts while it runs is a normal evening rather
        than an error.

        Whatever the application does, the user ends up back at the dashboard. The
        cases that matter are the ones where that is not automatic: an application
        that crashes, one that forks and leaves children behind, and one that never
        exits at all. This handles the first two by watching each process rather than
        by assuming, and leaves the third to the session, which is what owns the
        restart policy.
        """
        entry = self._entry_at(collection_index, entry_index)
        if entry is None:
            return
        if not entry.exists():
            self._set_status(f"{entry.name} is not available on this machine")
            return

        # An application that is already open is brought forward rather than started again.
        #
        # It used to start a second copy every time, so opening the store, going back to the
        # dashboard and opening the store again left two stores running, two of everything in the
        # session, and no way for the person to tell which one they were looking at. The docstring
        # above defends starting an application alongside *another* application, and that is still
        # what it does; starting the same one twice is not two things running, it is one thing
        # running twice, and every console treats the button as a way back to what is open.
        running = next(
            (item for item in self._running if item.launcher == entry.launcher), None
        )
        if running is not None:
            self._set_status("")
            self._switch_to(running)
            return

        self._set_status("")
        self._start(entry, hide=True)

    def _switch_to(self, application: RunningApplication) -> None:
        """make an application that is already running the one in front.

        The front application is the last of the list, and it is the last of the list rather than a
        number kept beside it precisely so that this is the whole of switching: move it to the end
        and everything that asks which application is in front - the dashboard's hiding, the
        overlay's pause and resume, the restart that waits for whatever is on screen to let go -
        agrees without being told.
        """
        if application not in self._running:
            return
        if self._launching:
            # Something is still on its way to the screen, and that thing wins.
            #
            # `_launching` is one fact about this dashboard rather than one per application, and
            # the starting screen is drawn for the application that set it. Switching now would
            # move the list, raise the window being asked for, and then have the application that
            # is starting arrive over the top of it a moment later and hide the dashboard on its
            # own behalf - so the list would say one thing, the screen another, and the person who
            # pressed the tile would be looking at the application they did not ask for. Waiting is
            # the honest answer: the launch is a second or two and it is going to happen anyway.
            self._set_status(f"{self._launching_name} is still starting")
            log.info(
                "'%s' was asked for while '%s' was still starting, so it keeps its place",
                application.name,
                self._launching_name,
            )
            return
        self._running.remove(application)
        self._running.append(application)
        self.runningChanged.emit()
        self.tilesChanged.emit()
        self.overlayActionsChanged.emit()

        self._set_overlay(False)
        # Everything the overlay stopped is released, not only the application being switched to.
        #
        # It resumed the target alone, which is wrong in a way that only shows up two steps later:
        # with the overlay open over A, A is stopped, and switching to B resumed B and left A
        # frozen with the marker file naming it. Open the overlay again over B and B is stopped as
        # well; close it and the resume finds the first stopped entry in the list, which is A,
        # releases A and deletes the marker, and leaves B stopped with nothing to say so. That is a
        # machine that looks hung and has no way out of it, which is the exact failure
        # PAUSED_MARKER and couchbox-xsession exist to prevent.
        self._resume_all_paused()
        if self._window is not None and not self._windowed and not self._launching:
            self._window.hide()
        # And the application's own window has to be raised, which is the part that was missing.
        #
        # Moving it to the end of the list makes this dashboard believe it is in front, and the
        # dashboard hiding itself reveals whatever X has on top, which is the most recently raised
        # window and not necessarily this one. Reported as going from settings to store and then
        # being taken back to the store when asking for settings: the list said settings and the
        # screen said store.
        self._raise_window(application)
        self._set_in_front(True)
        log.info("'%s' is back in front", application.name)

    def _artwork_for(self, launcher: str) -> str:
        """the tile artwork for the entry with this wrapper name, or "" when it has none.

        Recent entries are remembered as a launcher and a name rather than as a whole entry,
        because that is what has to keep working when the catalogue changes under it. The picture
        is looked up when the rows are built for the same reason: an application that has been
        removed since it was played keeps its name, and the row draws without a picture rather
        than with the picture of something else.
        """
        for collection in self._collections:
            for entry in collection.entries:
                if entry.launcher == launcher:
                    # `artwork` is a method and `has_artwork` is a property, which is a trap this
                    # fell into: returning `entry.artwork` returns the bound method, which is
                    # truthy, so every row claimed to have a picture and QML was handed something
                    # that is not a URL and quietly drew nothing
                    return entry.artwork() if entry.has_artwork else ""
        return ""

    def _raise_window(self, application: RunningApplication) -> None:
        """ask the window manager to put this application's window in front.

        By pid rather than by name: the shell knows the process it started and does not know what
        that process called its window, and `xdotool search --pid` asks X for the windows that
        process owns. A machine without xdotool does nothing here and behaves as it did before,
        which is the wrong application sometimes rather than no application at all.
        """
        if not os.access(XDOTOOL, os.X_OK):
            log.info("no xdotool, so '%s' cannot be raised and the list may not match the screen",
                     application.name)
            return
        pid = int(application.process.processId())
        if pid <= 0:
            return
        try:
            subprocess.run(
                [XDOTOOL, "search", "--pid", str(pid), "windowactivate"],
                capture_output=True,
                timeout=5,
                check=False,
            )
        except (OSError, subprocess.SubprocessError) as error:
            log.warning("'%s' could not be raised (%s)", application.name, error)

    @Slot(str)
    def launchLauncher(self, launcher: str) -> None:
        """start the entry with this wrapper name, wherever it is.

        The grid of everything on the machine is a flattened copy of the collections, so a
        position in it means nothing to this object: it is looked up by the one thing that is
        stable across a reload, which is the wrapper name. A launcher that is not in any
        collection any more is reported rather than silently doing nothing, which is the same
        answer `launchRecent` gives and for the same reason.
        """
        for collection_index, collection in enumerate(self._collections):
            for entry_index, entry in enumerate(collection.entries):
                if entry.launcher == launcher:
                    self.launch(collection_index, entry_index)
                    return
        log.warning("'%s' is not in any collection any more", launcher)
        self._set_status("that application is no longer listed anywhere")

    @Property(bool, notify=collectionsChanged)
    def storeAvailable(self):
        """is there a store entry on this machine for the interface to offer.

        The dashboard's empty state offers one press that opens the store, because a machine with
        nothing on it is the one moment a person most needs somewhere to go. When the store is not
        in any collection - a broken image, or a person who removed their own entry - the interface
        drops the button rather than offering one that does nothing.
        """
        return any(
            entry.launcher == "store"
            for collection in self._collections
            for entry in collection.entries
        )

    @Slot()
    def openStore(self) -> None:
        """start the store, wherever it is in the rail. The empty state's one button."""
        for collection_index, collection in enumerate(self._collections):
            for entry_index, entry in enumerate(collection.entries):
                if entry.launcher == "store":
                    self.launch(collection_index, entry_index)
                    return
        self._set_status("the store is not available on this machine")

    @Slot(int)
    def launchRecent(self, index: int):
        """start one of the applications from the recent list again.

        It is looked up by launcher rather than remembered as a position, so a collection that
        has been reorganised, renamed or removed since still works as long as the wrapper is
        there. A launcher that has gone is reported rather than silently doing nothing.
        """
        if not 0 <= index < len(self._recent):
            log.error("there is no recent application at %d", index)
            return
        wanted = self._recent[index]
        for collection_index, collection in enumerate(self._collections):
            for entry_index, entry in enumerate(collection.entries):
                if entry.launcher == wanted.launcher:
                    self.launch(collection_index, entry_index)
                    return
        log.warning("the recent application '%s' is not in any collection any more", wanted.name)
        self._set_status(f"{wanted.name} is no longer listed anywhere")

    @Slot(int, int)
    def runSystemLauncher(self, launcher: str) -> None:
        """run the system action with this wrapper name, wherever it has moved to.

        By name for the same reason as everywhere else: the position of an entry in a collection is
        a fact about the catalogue file that an install or a removal can change, and a power row
        that acts on a position is a power row that can restart the machine when somebody asked it
        to sleep.
        """
        for collection_index, collection in enumerate(self._collections):
            for entry_index, entry in enumerate(collection.entries):
                if entry.launcher == launcher:
                    self.runSystemAction(collection_index, entry_index)
                    return
        log.warning("'%s' is not a system action on this machine any more", launcher)

    def runSystemAction(self, collection_index: int, entry_index: int):
        """run a system action from the overlay, leaving every running application as it is.

        The power actions sleep, restart or switch the machine off while applications
        are running. None of those should end them or un-pause them: somebody who put
        the machine to sleep in the middle of a game expects to wake up to the dashboard
        with the game still there, and somebody who restarted has lost it either way. So
        the applications are left exactly as the overlay left them, and the dashboard
        stays in front, because putting a game back on screen while a shutdown is
        happening is the wrong thing to show.
        """
        entry = self._entry_at(collection_index, entry_index)
        if entry is None:
            return
        if not entry.system:
            # an application started over another application is two things fighting for
            # one screen, which is never what the press meant
            log.warning("'%s' is not a system action, so the overlay will not run it", entry.name)
            return
        if not entry.exists():
            self._set_status(f"{entry.name} is not available on this machine")
            return

        self._set_status("")
        self._set_overlay(False)
        self._start(entry, hide=False)

    def _entry_at(self, collection_index: int, entry_index: int):
        """the entry at those positions, or None with the reason written to the log."""
        if not 0 <= collection_index < len(self._collections):
            log.error("there is no collection at %d", collection_index)
            return None
        collection = self._collections[collection_index]
        if not 0 <= entry_index < len(collection.entries):
            log.error("there is no entry at %d in '%s'", entry_index, collection.name)
            return None
        return collection.entries[entry_index]

    def _start(self, entry, hide: bool) -> None:
        """start an entry, as an application the dashboard manages or as a system action.

        Both end up here because both want the same things: a process group of their own so
        that a stop can reach everything the wrapper started, output forwarded to the log,
        and a finish that is noticed rather than assumed. What differs is what the dashboard
        owns. An application joins `runningApplications` and can be paused, resumed and
        stopped; a system action is a one-off command whose only lasting effect is that the
        dashboard comes back when it finishes.
        """
        log.info(
            "starting '%s' with %s%s",
            entry.name,
            entry.path,
            # the path is the wrapper either way, and saying that setsid is in front of it is
            # the difference between "the pid here is the application" and a mystery
            " (through setsid, in its own process group)" if self._own_group else "",
        )
        process = QProcess(self)
        # every process this dashboard starts, kept for as long as the dashboard lives rather than
        # for as long as the application is running. `_running` is what is running now, and an
        # application that finishes leaves it; its process object stays, with the handlers that
        # were attached to it, and a signal arriving after Qt has begun tearing the dashboard down
        # calls into a half-deleted shell. That is not theoretical: it is what `shutdown` below
        # disconnects, and it caught only the applications still in `_running` when it was written
        self._processes.append(process)
        if self._own_group:
            process.setProgram(SETSID)
            process.setArguments([entry.path])
        else:
            process.setProgram(entry.path)

        # recorded before it is started, so that an application which crashes immediately is
        # still in the list of what this machine tried to run, which is more useful than a
        # list that only holds the ones that worked
        self._recent = recent_model.note(entry.launcher, entry.name)
        self.recentChanged.emit()

        if hide:
            application = RunningApplication(name=entry.name, entry=entry, process=process)
            self._running.append(application)
            self.runningChanged.emit()
            self.tilesChanged.emit()
            self.overlayActionsChanged.emit()
            # each process is answered by a handler that already knows which application it
            # belongs to: with several running, "whichever process this was" is a question
            # the shell can no longer answer from a single slot
            process.finished.connect(
                lambda code, status, held=application: self._on_finished(held, code, status)
            )
            process.errorOccurred.connect(
                lambda error, held=application: self._on_failed(held, error)
            )
        else:
            action = SystemAction(name=entry.name, process=process)
            self._system_action = action
            process.finished.connect(
                lambda code, status, held=action: self._on_system_finished(held, code, status)
            )
            process.errorOccurred.connect(
                lambda error, held=action: self._on_system_failed(held, error)
            )

        # the wrapper's own output is forwarded to the dashboard's log rather than
        # going into a pipe nobody reads, because a wrapper that fails silently is
        # the exact failure this project keeps having to design against
        process.setProcessChannelMode(QProcess.ProcessChannelMode.ForwardedChannels)

        # the dashboard does not get out of the way yet. It stays on screen with the
        # application's name until the application has a window of its own, because hiding at
        # once is the black screen this was designed to end (ADR-0034). Hiding the window is
        # what stops the dashboard drawing, so a game still gets the screen to itself as soon
        # as it has something to put on it
        process.start()
        if hide:
            self._set_in_front(True)
            self._begin_launch(
                entry.name, entry.artwork() if entry.has_artwork else ""
            )

    @Slot()
    def resumeApplication(self):
        """put the front application back in front of the dashboard, and let it run again.

        With several running, the front application is the most recent one, which is the one
        the dashboard was hidden for and therefore the one "resume" means to anybody who was
        looking at it. Whatever the overlay paused is released either way: that is the overlay
        undoing what opening it did, and leaving something frozen because it is no longer the
        most recent would be the exact failure pausing exists to avoid.
        """
        self._set_overlay(False)
        self._resume_application()
        if self._window is not None and not self._windowed and not self._launching:
            # while an application is still starting, the dashboard stays on screen with its
            # starting screen: hiding here would hand the user the black screen this exists to
            # remove
            self._window.hide()
        self._set_in_front(True)
        log.info("the most recent application is back in front")

    @Slot()
    def closeOverlay(self):
        """close the overlay, and let go of anything it paused.

        Closing puts the person back exactly where they were and nowhere else. Over an
        application that means letting the application run again; over the dashboard it
        means only closing, because the guide key opens an overlay and never takes anybody
        anywhere (ADR-0042). Going back to an application from the dashboard is the
        overlay's Resume row, which is a row rather than the key that opened the overlay.
        """
        if self.overlayOverApplication:
            # the panel was over an application, so what the person was looking at before it
            # appeared is that application, and closing hands it back running
            self.resumeApplication()
            return
        self._set_overlay(False)
        log.info("the overlay closed over the dashboard")

    @Slot()
    def stopApplication(self):
        """stop the front application, and come back to the dashboard.

        What stopping means is the wrapper's to declare (ADR-0022), and a wrapper that declares
        nothing gets the safe reading: one process, stop it to leave. The declaration is not built
        yet, so that is what everything gets today, and Steam's own answer belongs in Steam's
        wrapper when it arrives rather than here.

        The whole process group is stopped, then killed if it does not go. A wrapper execs the
        application or waits for it (tests/check-launchers.sh), so the group is the application
        and everything it started. Killing the group rather than the process is why a game that
        spawned something does not leave it drawing behind the dashboard.

        Stopping anything else is `stopApplicationByLauncher`, which the overlay's rows use: this
        keeps its one-job meaning, so a caller that just wants "the thing on screen closed"
        cannot accidentally close a background application instead.
        """
        application = self._front_application()
        if application is None:
            return
        self._stop_application(application)

    @Slot(str)
    def stopApplicationByLauncher(self, launcher: str) -> None:
        """stop the application with that wrapper name.

        By name and not by position. This was `stopApplicationAt(index)`, and a position into the
        running list is not a stable way to name anything now that bringing an application forward
        moves it: the same number means a different application a moment later, and a slot anybody
        can call with a number they stored earlier is a slot that will eventually close something
        other than what was asked for. `launchLauncher` already works this way for the same reason.

        Stopping a background application changes nothing else: what is in front stays in front,
        and the dashboard neither appears nor disappears, because a download that a person chose to
        stop is not a reason to take the screen away from what they are looking at.
        """
        application = next(
            (item for item in self._running if item.launcher == launcher), None
        )
        if application is None:
            log.warning("'%s' is not running, so there is nothing to stop", launcher)
            return
        self._stop_application(application)

    def _stop_application(self, application: RunningApplication) -> None:
        """ask one application to stop, and insist if it does not."""
        group = int(application.process.processId())
        if group <= 0:
            log.warning("'%s' has no process to stop yet", application.name)
            return

        # asked for, so whatever happens next is not reported as a fault
        application.stop_requested = True
        # and said so at once, because the alternative is a row that looks like it did nothing
        # until the process has finished dying, which people press again
        self.overlayActionsChanged.emit()

        # an application the overlay paused cannot act on a signal until it runs again, so the
        # pause this process created is undone before it is asked to leave. Otherwise the request
        # would sit unread and the four seconds below would end in a signal it cannot ignore.
        # Only this application's pause is released: the overlay's pause belongs to whatever it
        # is covering, and a named stop must not release a different application's group
        self._resume_application(application)
        log.info("asking '%s' to stop (process group %d)", application.name, group)

        try:
            if self._own_group:
                os.killpg(group, signal.SIGTERM)
            else:
                os.kill(group, signal.SIGTERM)
        except ProcessLookupError:
            return
        except OSError as error:
            log.warning("could not ask '%s' to stop (%s)", application.name, error)
            return

        # and if it is still there, it is made to stop. A program that ignores the request would
        # otherwise leave somebody pressing a key that appears to do nothing, which is the failure
        # this whole overlay exists to end
        QTimer.singleShot(STOP_GRACE_MS, lambda: self._insist(application, group))

    def _insist(self, application: RunningApplication, group: int) -> None:
        """send the signal that cannot be ignored, if the application is still running."""
        if application not in self._running:
            # it went away, which is what was asked of it
            return
        log.warning("'%s' did not stop when asked, so it is being killed", application.name)
        try:
            if self._own_group:
                os.killpg(group, signal.SIGKILL)
            else:
                os.kill(group, signal.SIGKILL)
        except ProcessLookupError:
            return
        except OSError as error:
            log.error("could not stop '%s' (%s)", application.name, error)

    @Slot()
    def showDashboard(self):
        """come back to the dashboard without stopping the applications.

        They keep running, because that is the whole of what "leaves the application where
        it is" means, and the overlay's Resume row is then the way back to the most recent
        one (ADR-0042).

        It closes the overlay whether or not anything is running, and it did not always. It began
        with `if not self._running: return`, which was harmless while the only way here was from a
        running application and stopped being harmless when the overlay gained a tile that calls it:
        with nothing running, which is exactly when the overlay is over the dashboard, the tile
        whose whole job is "go to the dashboard" did nothing at all. The guard protected nothing -
        `_resume_all_paused` is a no-op with nothing running, and showing the shell is what the
        dashboard being in front already means.
        """
        self._set_overlay(False)
        # every one of them, for the same reason as in `_switch_to`: one marker file cannot
        # describe two stopped applications
        self._resume_all_paused()
        self.showShell()
        log.info("the dashboard is in front and the applications are still running")

    @Slot()
    def showShell(self):
        """bring the dashboard back to the front."""
        self._set_in_front(False)
        if self._window is None:
            return
        if self._windowed:
            self._window.show()
        else:
            self._window.showFullScreen()
        self._window.raise_()
        # nothing was read while the shell was away, so the clock and the indicators are brought
        # up to date on the way back rather than up to five seconds later
        if self._system_timer is not None:
            self._refresh_system(slow=True)

    # --- the machine's own controls ------------------------------------------

    @Slot(int)
    def volumeStep(self, direction: int) -> None:
        """one step up or down, from a control that is not a pair of rows.

        The overlay's volume row is adjusted in place, so it needs a step rather than an action per
        direction. Unmuting on the way up is deliberate: turning a muted machine up is the most
        natural way to ask for sound, and a volume that moves while nothing can be heard is a
        control that appears broken.
        """
        if direction > 0:
            self.volumeUp()
        elif direction < 0:
            self.volumeDown()

    @Slot()
    def volumeUp(self) -> None:
        self._change_volume(VOLUME_STEP)

    @Slot()
    def volumeDown(self) -> None:
        self._change_volume(-VOLUME_STEP)

    def _unmute_if_muted(self) -> None:
        """let the machine be heard, if it was not.

        Turning a muted machine up is the most natural way anybody asks for sound, and a volume that
        moves while nothing can be heard is a control that appears broken. The overlay's volume row
        said this in a comment and never did it: the row unmuted only when A was pressed on it, so
        moving the bar up on a muted machine grew a faint bar and made no noise.
        """
        if self._volume and self._volume[1]:
            self.toggleMute()

    def _change_volume(self, step: int) -> None:
        """move the default sink, and read it back rather than assuming it worked.

        The reading is what the interface draws, so asking again is the difference between a
        bar that follows the presses and a bar that follows what the person pressed. A machine
        whose audio server refuses the change shows the same number twice, which is honest.
        """
        if step > 0:
            self._unmute_if_muted()
        worked, reason = systeminfo.volume_step(step)
        if not worked and reason:
            self._set_status(reason)
        # the slow pass, because the volume is read there: a fast pass would leave the number the
        # interface draws at its old value and the bar would follow the presses by not moving
        self._refresh_system(slow=True)

    @Slot()
    def toggleMute(self) -> None:
        worked, reason = systeminfo.toggle_mute()
        if not worked and reason:
            self._set_status(reason)
        self._refresh_system(slow=True)

    @Slot()
    def quit(self):
        """leave, because somebody asked to.

        The exit status is what tells the session the difference between this and a crash, and
        between this and a restart for an update. See `_leave`.
        """
        self._leave(EXIT_OK)

    def _leave(self, code: int) -> None:
        """stop, and say why in the only language the session understands.

        The session restarts the dashboard when it goes away, and it had no way to tell one
        departure from another. So a person who pressed Ctrl+Q, which `recovery.txt` tells them
        quits the dashboard and returns them to the console, got the dashboard back two seconds
        later, every time; and a dashboard that exits for an update was counted as a crash
        against a limit of five.

        Three answers, and the session acts on them: this one, the update one, and anything else,
        which is a fault.
        """
        # nothing is left stopped. a stopped process whose dashboard has gone away is a
        # frozen screen with no way out of it, and quitting in front of one is the last
        # moment this can be undone
        for application in self._running:
            self._resume_application(application)
        self.shutdown()
        QCoreApplication.exit(code)

    @Slot()
    def shutdown(self) -> None:
        """stop the input threads before the process goes away.

        Qt aborts a process whose QThread is still running when the application object is torn
        down ("QThread: Destroyed while thread is still running", then SIGABRT), and both the
        gamepad watcher and the hotkey server are long-lived by design. This is connected to
        aboutToQuit as well as called from quit(), because the way a dashboard usually goes away
        is not quit(): a session that stops it or an X server that ends does not come through
        here, and an abort would leave the same confusing report the store produced when it was
        closed on a booted image.
        """
        if self._gamepad is not None:
            self._gamepad.stop()
        if self._hotkeys is not None:
            self._hotkeys.stop()
        # And the applications' processes are disconnected from handlers that belong to this
        # dashboard, because those handlers outlive it otherwise. A process that is still going
        # when the interface is torn down reports it to a callback on an object that is already
        # gone: harmless in a running dashboard, where the process ends with the session, and a
        # traceback about a deleted Shell in anything that keeps the interpreter alive to look at
        # what happened, which is every check this project runs.
        #
        # Both signals and no argument, so it does not matter which of the two each process was
        # connected to or how many times: whatever this dashboard attached, this detaches.
        for process in self._processes:
            for signal_name in ("finished", "errorOccurred", "started"):
                try:
                    getattr(process, signal_name).disconnect()
                except (RuntimeError, TypeError):
                    continue
        self._processes = []

    # --- the overlay ---------------------------------------------------------

    @Slot(str)
    def _on_guide(self, message: str) -> None:
        """one press of the guide key: open the overlay, or close it.

        That is the whole of what the key means, wherever the person is and whatever is on
        screen (ADR-0042): it is an overlay key, like the console overlays it is modelled
        on, and it never takes anybody anywhere. Opening is above the dashboard and above a
        running application alike; going back to an application is the overlay's Resume
        row, and returning to the dashboard is its Dashboard row.
        """
        # the same press can arrive twice, and usually does: a keyboard gives the guide's word,
        # because it can read the devices, and the session's window manager gives its own word,
        # because it can claim the key from the display server. Either on its own is a working
        # hotkey; both together would open the overlay and shut it again. So a word that arrives
        # while the last one is still a moment old is the same press arriving twice, and is
        # ignored. The window is short enough that a person cannot press twice inside it
        now = time.monotonic()
        if now - self._last_guide < GUIDE_REPEAT_SECONDS:
            log.debug("ignoring a second %s within %.0f ms of the first", message,
                      GUIDE_REPEAT_SECONDS * 1000)
            return
        self._last_guide = now

        if self._overlay:
            # a second press closes what the first one opened, wherever that was. It has to be
            # this and not "resume the application", because the overlay also opens with
            # nothing running: a resume does nothing in that case, and a key that opens
            # something it cannot close is worse than a key that does nothing at all
            self.closeOverlay()
            return
        self.openOverlay(message)

    @Slot()
    def openOverlayFromDashboard(self) -> None:
        """open the overlay from the interface rather than from the hotkey.

        Two reasons this exists separately from the key the guide sends. The first is that the
        guide reads the input devices directly and a session that is not on this machine's own
        hardware never appears there: a remote desktop delivers its keys to X and not to evdev,
        so on a remote session the guide is blind and this is the only way in. The second is that
        pressing a key in the interface is the discoverable route for somebody who has never
        heard of a guide button.

        It means what the guide key means when it opens the overlay, and nothing else: the
        overlay opens above the dashboard, and applications that are running stay running
        behind it (ADR-0042). The way back to one is the Resume row, exactly as it is for a
        press that arrived over the socket.
        """
        # a keyboard can reach this road and the guide's road with one press. The word that
        # arrives second has to look like the same press, or one tap would open the overlay
        # here and close it again there (GUIDE_REPEAT_SECONDS)
        self._last_guide = time.monotonic()
        self.openOverlay("the dashboard")

    def openOverlay(self, message: str = hotkey_input.MESSAGE_GUIDE) -> None:
        """open the overlay above whatever is on screen: the dashboard or an application.

        Over an application the panel is a window of its own (ADR-0035) and the application
        it covers is stopped first, so what surrounds the panel is a still picture rather
        than something moving underneath it. Pausing is the default and it belongs to the
        application the panel covers and to no other (ADR-0022): an application merely
        behind the dashboard is background work that was asked to keep going (ADR-0038), so
        an overlay opened over the dashboard touches nothing at all.
        """
        if self._overlay:
            return
        log.info("showing the overlay after %s", message)
        if self._application_in_front:
            # the panel is about to cover the application, so it is stopped first, which is
            # what the pause is for. Nothing else is touched: with several running, every
            # other application is background work
            self._pause_application()
        else:
            # the dashboard draws the panel itself, so it has to be the thing on screen
            self.showShell()
        self._set_overlay(True)
        if self.overlayOverApplication:
            self._show_panel()

    def _show_panel(self) -> None:
        """bring the overlay window up and give it the keyboard.

        The window itself is a QML window bound to `overlayOverApplication`, so showing and
        hiding it is the property changing rather than a call. What has to happen here is the
        focus: a window that is drawn but not activated receives no key events, and an overlay
        that cannot be navigated is worse than no overlay
        """
        if self._overlay_window is None:
            return
        QTimer.singleShot(0, self._overlay_window.requestActivate)

    @Slot(int)
    def overlayActivate(self, index: int) -> None:
        """choose one of the overlay's rows. The list itself is built in `overlayActions`."""
        items = self.overlayActions
        if not 0 <= index < len(items):
            log.error("there is no overlay row at %d", index)
            return
        item = items[index]
        kind = item.get("kind")
        if kind == "resume":
            self.resumeApplication()
        elif kind == "dashboard":
            self.showDashboard()
        elif kind == "stop":
            # the row names the application it closes, and that is what decides which one
            # goes: with several running, stopping whatever is in front would close a row
            # that is not the row that was pressed
            self._stop_row(item)
        elif kind == "recent":
            self.launchRecent(int(item.get("index", -1)))
        elif kind == "volume":
            # the row is a control, so A is the one thing left that a control can do at a press:
            # left and right move it and this silences it
            self.toggleMute()
        elif kind == "system":
            launcher = item.get("launcher")
            if isinstance(launcher, str) and launcher:
                self.runSystemLauncher(launcher)
            else:
                # a row from before the launcher was carried on it. Nothing in this tree builds one
                # that way any more, and answering the old shape is one line where refusing it
                # would be a power row that quietly stopped working after an update
                self.runSystemAction(int(item["collection"]), int(item["entry"]))

    def _stop_row(self, item: dict) -> None:
        """close the application the row names, and not whichever one happens to be nearest.

        Found by launcher and confirmed by name, and never by position. The row used to carry the
        position it was built at, which was sound while the running list was append-only and stopped
        being sound the moment an application could be brought forward, because bringing one
        forward moves it. The name is what a person reads and the launcher is what identifies the
        application, and a background application can finish between the moment the interface drew
        a row and the moment it is pressed; closing something other than what the row says is the
        one outcome this must never have.
        """
        name = item.get("name")
        launcher = item.get("launcher")
        if not isinstance(name, str):
            log.error("an overlay row asked to close an application without naming one")
            return
        application = None
        if isinstance(launcher, str):
            application = next(
                (item_ for item_ in self._running if item_.launcher == launcher), None
            )
        if application is None:
            application = next(
                (item_ for item_ in self._running if item_.name == name), None
            )
        if application is None:
            log.warning("'%s' is not running any more, so its close row does nothing", name)
            return
        if application.name != name:
            # the launcher matched and the name did not, which means the entry was edited while it
            # was running. Closing it is still right, and the log is here because it is surprising
            log.info("'%s' is the application the row called '%s'", application.name, name)
        self._stop_application(application)

    def _set_in_front(self, value: bool) -> None:
        """record whether an application is the thing on screen, and say so when it changes.

        `overlayOverApplication` is what both hosts ask to decide which of them draws the overlay,
        and it depends on this as well as on the overlay being open. Setting the flag without
        emitting anything left the two disagreeing: opening the overlay over the dashboard and then
        starting something from it made this dashboard believe the overlay was over an application
        while the interface still had it drawn in the dashboard's own window, and the controller
        went to a window that had never been mapped. The keys went dead until the overlay was closed
        with a keyboard, which is the one thing a machine driven from a couch cannot recover from.
        """
        if value != self._application_in_front:
            self._application_in_front = value
            self.overlayChanged.emit()
            # and the tiles, which mark which of them is where the person is. Without this the
            # switcher could show no current location at all: opening the overlay over the
            # dashboard and starting something from the recent rows sets this flag after the tiles
            # were last built, and nothing rebuilt them while the panel was open
            self.tilesChanged.emit()

    def _set_overlay(self, open_: bool) -> None:
        if open_ != self._overlay:
            self._overlay = open_
            self.overlayChanged.emit()
            self.overlayActionsChanged.emit()
            self.tilesChanged.emit()

    # --- pausing, and the two ways it can go wrong ---------------------------

    def _pause_application(self) -> None:
        """stop the front application drawing until the overlay is closed.

        The front application only. Every other one is background work, and a SIGSTOP sent
        to each of them would stop exactly the helpers this dashboard exists to keep alive
        while the user is somewhere else.
        """
        application = self._front_application()
        if application is None or application.paused:
            return

        pid = int(application.process.processId())
        if pid <= 0:
            log.warning("'%s' has not started yet, so there is nothing to pause", application.name)
            return

        try:
            if self._own_group:
                os.killpg(pid, signal.SIGSTOP)
            else:
                os.kill(pid, signal.SIGSTOP)
        except ProcessLookupError:
            # it finished between the request and the signal, which is an ordinary thing
            # for a short application to do
            return
        except OSError as error:
            log.warning(
                "'%s' could not be paused (%s), so it keeps running behind the overlay, "
                "which is a supported outcome rather than a failure",
                application.name,
                error,
            )
            return

        application.paused_group = pid
        self._write_marker(pid)
        self.runningChanged.emit()
        self.tilesChanged.emit()
        log.info("paused '%s' (process group %d) while the overlay is up", application.name, pid)

    def _resume_all_paused(self) -> None:
        """release every application the overlay stopped, not just the first one it finds.

        The design says at most one application is stopped at a time, because the overlay stops the
        one it covers. A switch while the overlay is open is the way to get two, and a machine with
        two stopped applications and one marker between them is a machine that cannot be recovered
        by starting the session again.
        """
        for application in list(self._running):
            if application.paused:
                self._resume_application(application)

    def _resume_application(self, application: RunningApplication | None = None) -> None:
        """let a stopped application run again.

        Without one, this releases whichever application the overlay stopped, which is what
        closing the overlay means. With one, only that application is released, which is what
        stopping a named background application needs: releasing some other application's
        process group would be a signal sent to the wrong program.
        """
        if application is None:
            application = next((item for item in self._running if item.paused), None)
            if application is None:
                return
        if not application.paused:
            return
        group = application.paused_group
        if group is None:
            return
        application.paused_group = None
        self._clear_marker()

        try:
            if self._own_group:
                os.killpg(group, signal.SIGCONT)
            else:
                os.kill(group, signal.SIGCONT)
        except ProcessLookupError:
            return
        except OSError as error:
            log.warning("'%s' could not be resumed (%s)", application.name, error)
            return
        self.runningChanged.emit()
        self.tilesChanged.emit()
        log.info("resumed '%s' (process group %d)", application.name, group)

    def marker_path(self) -> str:
        """where a paused application is remembered.

        A stopped process stays stopped when the thing that stopped it goes away, and the
        user is then looking at a screen that does not move with no way out of it but the
        power button. This file is what lets the session undo that the next time it starts
        a dashboard, and couchbox-xsession is where that happens.
        """
        return os.path.join(os.environ.get("XDG_RUNTIME_DIR") or "/tmp", self.PAUSED_MARKER)

    def _write_marker(self, pid: int) -> None:
        try:
            with open(self.marker_path(), "w", encoding="utf-8") as handle:
                handle.write(f"{pid}\n")
        except OSError as error:
            log.warning("could not record the paused application (%s)", error)

    def _clear_marker(self) -> None:
        try:
            os.unlink(self.marker_path())
        except FileNotFoundError:
            pass
        except OSError as error:
            log.warning("could not remove the record of the paused application (%s)", error)

    # --- the processes ------------------------------------------------------

    def _on_finished(self, application: RunningApplication, code: int, status):
        log.info("'%s' finished with exit code %d", application.name, code)
        # asked before the record is forgotten, because afterwards there is nothing to ask
        unexpected = code != 0 and not application.stop_requested
        was_front = self._forget_application(application)
        if was_front is None:
            # the other handler for a signalled death already did this
            return
        if unexpected:
            # an application that dies on its own used to look like nothing happening at all:
            # the display went black and came straight back, which is indistinguishable from a
            # button that does nothing. Saying so is the difference between a bug report and a
            # shrug, and the log file has the rest. An application the user chose to close says
            # nothing: they watched it close, and a line about it is noise dressed as feedback
            self._set_status(f"{application.name} stopped unexpectedly")
        # the collections are read again on the way back, because the store's whole purpose is that
        # installing something puts a tile on this dashboard. Without this the entry would only
        # appear after the next restart, which reads as the install having failed
        self.reload()
        if was_front:
            if self._restart_for_update_if_ready(front_has_let_go=True):
                # the update was waiting for the thing in front to let go, which it just
                # did: the restart comes instead of a dashboard about to be replaced
                return
            # the dashboard was hidden for this application, so it is what the user gets
            # back. A background application finishing is not a reason to change what is on
            # screen, or to make the dashboard appear over the thing the user is looking at
            self.showShell()

    def _on_failed(self, application: RunningApplication, error):
        process = application.process
        # a process that was killed reports both an error and a finish, in whichever order Qt
        # gets to them, and whichever handler runs second must find the record the first one
        # already removed. Both orders are tolerated here, because a killed application is a
        # normal event on this machine: the user asked for it. Measured by stopping a real
        # process in the harness, where these two tracebacks were the whole of a bug report
        try:
            if error == QProcess.ProcessError.Crashed:
                log.error(
                    "'%s' was killed by signal %d (%s)",
                    application.name,
                    process.exitCode(),
                    process.errorString(),
                )
            else:
                log.error("'%s' could not be started: %s", application.name, process.errorString())
        except RuntimeError:
            pass
        was_front = self._forget_application(application)
        if was_front:
            if self._restart_for_update_if_ready(front_has_let_go=True):
                return
            self.showShell()

    def _on_system_finished(self, action: SystemAction, code: int, status):
        log.info("'%s' finished with exit code %d", action.name, code)
        if not self._forget_system_action(action):
            return
        # the overlay was closed when the action started, and is closed again here because a
        # person can open it again while a suspend is in flight; the dashboard is what comes
        # back when the machine does
        self._set_overlay(False)
        if code != 0:
            # a power action that failed is worth one line, for the same reason an application
            # that died is: the screen would otherwise simply not change and nothing would say
            # why
            self._set_status(f"{action.name} stopped unexpectedly")
        self.reload()
        self.showShell()

    def _on_system_failed(self, action: SystemAction, error):
        process = action.process
        try:
            if error == QProcess.ProcessError.Crashed:
                log.error(
                    "'%s' was killed by signal %d (%s)",
                    action.name,
                    process.exitCode(),
                    process.errorString(),
                )
            else:
                log.error("'%s' could not be started: %s", action.name, process.errorString())
        except RuntimeError:
            pass
        if self._forget_system_action(action):
            self._set_overlay(False)
            self.showShell()

    def _forget_application(self, application: RunningApplication) -> bool | None:
        """take an application out of the running collection.

        Returns whether it was the front application, or None when it was already gone: a
        killed application reports both an error and a finish, and whichever of the two
        handlers runs second must find nothing left to do rather than act on a record the
        first one has already disposed of.

        The pause this application held is released here, because a marker that names a
        process which no longer exists is a file the session will try to resume on the next
        boot. `stop_requested` is deliberately left alone: the two handlers race, and the one
        that reports the finish reads it to tell a close the user asked for from a crash.
        """
        if application not in self._running:
            return None
        was_front = application is self._front_application()
        self._running.remove(application)
        try:
            application.process.deleteLater()
        except RuntimeError:
            pass
        if application.paused:
            application.paused_group = None
            self._clear_marker()
        if was_front:
            # whatever happened to the application, the starting screen belonged to it
            self._end_launch(hide_window=False)
            # and the overlay was raised over it, so it goes away with it
            self._set_overlay(False)
        self.runningChanged.emit()
        self.tilesChanged.emit()
        self.overlayActionsChanged.emit()
        return was_front

    def _forget_system_action(self, action: SystemAction) -> bool:
        """clear the tracked system action, tolerating the racing handlers. False if gone."""
        if self._system_action is not action:
            return False
        self._system_action = None
        try:
            action.process.deleteLater()
        except RuntimeError:
            pass
        return True

    @Slot()
    def start_installs(self) -> None:
        """begin reading what the install engine is doing.

        The engine is a process of its own and it writes a state file (ADR-0033). This is a
        reader of that file, so the dashboard shows an install that was started from the store
        window even after that window has been closed, which is what "background install"
        means to the person who started it.
        """
        if store_model is None:
            log.info("there is no install engine on this machine to watch")
            return
        self._install_timer = QTimer(self)
        self._install_timer.setInterval(INSTALL_POLL_MS)
        self._install_timer.timeout.connect(self._poll_installs)
        self._install_timer.start()
        self._poll_installs()

    def _poll_installs(self) -> None:
        """read the engine's state file and turn it into one line and one number."""
        state = store_model.read_state()
        entries = state.get("items", []) if isinstance(state, dict) else []
        if not isinstance(entries, list):
            entries = []
        entries = [entry for entry in entries if isinstance(entry, dict) and entry.get("id")]

        active = [entry for entry in entries if entry.get("state") in ("queued", "working")]
        working = next((entry for entry in active if entry.get("state") == "working"), None)
        shown = working or (active[0] if active else None)

        line = ""
        percent = -1.0
        if shown is not None:
            # the strip is composed from the entry's name and the phase word only. The engine
            # also publishes the tool's own line as `text`, and it is deliberately never read
            # here: a progress strip that recites apt output is unreadable from a couch, and
            # the store's own window made the same call for the same reason
            line = str(shown.get("name") or "an application")
            if len(active) > 1:
                line += f" and {len(active) - 1} more"
            phase = str(shown.get("phase") or "")
            if phase:
                line += f"   {phase}"
            given = shown.get("percent")
            if isinstance(given, (int, float)):
                percent = float(given)

        if (shown is not None) != self._install_active or line != self._install_text \
                or percent != self._install_percent:
            self._install_active = shown is not None
            self._install_text = line
            self._install_percent = percent
            self.installsChanged.emit()

        # a finished install is the one moment the dashboard has to read the collections again:
        # the whole point of the store is that an install puts an entry on this screen (ADR-0026),
        # and noticing only at the next start would read as the install having failed
        marker = tuple(
            sorted(
                (entry.get("id"), round(entry.get("finished_at", 0)))
                for entry in entries
                if entry.get("state") == "done"
            )
        )
        if marker != self._install_done_marker:
            self._install_done_marker = marker
            if marker:
                self.reload()

        # and the one piece of news in this file that changes this process rather than being
        # shown by it: an update that replaced the Couchbox package this dashboard runs from
        self._watch_for_update_restart(entries)

        # and, before that news can ever exist, the question that produces it: this machine asks
        # once per start whether its own sources have anything newer (ADR-0051)
        self._consider_an_automatic_update()

    # --- updating itself ------------------------------------------------------

    def _consider_an_automatic_update(self) -> None:
        """ask once per start whether this machine's sources have anything newer, and act on it.

        Why a console does this without being asked. The person who turned this machine on is
        sitting on a couch with a controller and no other way to find out that the dashboard they
        are looking at is a year old. A machine that updates when it starts is a machine that is
        current; the alternative is one where the button is never pressed (ADR-0051).

        When it does not happen, and there are four of those:

          * the setting is off, so somebody has said so
          * this start has already asked, because asking is not a thing to do in a loop
          * an application is in front, because an update is a package manager writing to the
            disk and that is not something to do over somebody's game. It waits, and the poll
            asks again, which is the same waiting the restart does
          * there is no network, because the question cannot be answered and the attempt would
            only be a delay

        What it does not wait for is the overlay being open over the dashboard. That is somebody
        looking at a menu for a few seconds, it does not stop apt, and the update is quiet.

        The answer arrives on this thread as a string and is acted on in the poll, because a
        thread must not touch the engine socket or this object's state.
        """
        if self._auto_update_asked:
            return

        if self._auto_update_retry_at is not None:
            if time.monotonic() < self._auto_update_retry_at:
                return
            self._auto_update_retry_at = None
            self._auto_update_state = "waiting"

        if self._auto_update_answer is not None:
            answer, self._auto_update_answer = self._auto_update_answer, None
            self._act_on_the_update_answer(answer)
            return

        if self._auto_update_state != "waiting":
            return

        if not update_config.automatic():
            log.info("this machine is not set to look for updates when it starts")
            self._auto_update_asked = True
            return

        if self._application_in_front or self._launching:
            return

        if not self.networkOnline:
            # asked again on a later poll rather than given up on: a machine whose network arrives
            # a minute after it starts is a machine that should still update itself
            return

        self._auto_update_state = "asking"
        log.info("asking whether this machine's sources have anything newer")
        threading.Thread(
            target=self._ask_about_updates,
            name="couchbox-update-check",
            daemon=True,
        ).start()

    def _ask_about_updates(self) -> None:
        """run the question somewhere that is not the thread drawing the screen.

        The helper is the same one the store uses and the same one the Updates page asks, so a
        machine that updates itself does exactly what a machine whose owner pressed the button
        does. It is asked for the check verb, which reads apt's lists and asks apt what it would
        do, and installs nothing.
        """
        answer = ""
        try:
            result = subprocess.run(
                ["sudo", "-n", HELPER, "check-update"],
                capture_output=True,
                text=True,
                timeout=180,
                check=False,
            )
            for line in result.stdout.splitlines():
                if line.startswith("couchbox-update-check:"):
                    answer = line.split(":", 1)[1].strip()
                    break
            if not answer:
                log.info("the update check said nothing this could read")
        except (OSError, subprocess.SubprocessError) as error:
            log.info("the update check could not run (%s)", error)
        self._auto_update_answer = answer

    def _retry_the_update_check(self) -> None:
        """ask again later, after a question the sources could not answer.

        A minute, then two, then four, up to half an hour. Long enough that a machine whose archive
        is gone is not asking constantly, short enough that one whose network came back is looking
        for security updates again before anybody notices it stopped.
        """
        self._auto_update_state = "waiting"
        self._auto_update_retries += 1
        wait = min(60.0 * (2 ** (self._auto_update_retries - 1)), 1800.0)
        self._auto_update_retry_at = time.monotonic() + wait
        log.info("asking about updates again in about %d seconds", int(wait))

    def _act_on_the_update_answer(self, answer: str) -> None:
        """ask the engine for an update when the answer was that there is one.

        The engine is asked rather than the helper run directly, so that an automatic update is
        the same job as a manual one: the same progress in the same place, the same state file,
        the same line when the Couchbox package changes, and therefore the same restart of this
        dashboard afterwards. An automatic update that took a different path would be a second
        update mechanism to keep working.
        """
        self._auto_update_state = "done"

        offered = ""
        upgraded = 0
        waiting = 0
        for part in answer.split():
            key, _, value = part.partition("=")
            if key == "couchbox":
                offered = "" if value == "none" else value
            elif key == "flatpak":
                # the flatpak half of the same question. Apt knows nothing about it, and a machine
                # whose only updates are flatpak ones does have updates: without this the
                # dashboard would look at apt, find nothing, and leave Clone Hero a year old
                try:
                    waiting = int(value)
                except ValueError:
                    # a number that cannot be read is not an answer of nothing either
                    waiting = -1
            elif key == "stale":
                if value == "yes":
                    self._update_trouble = (
                        "a source could not be read, so the list of updates may be out of date"
                    )
                else:
                    self._update_trouble = ""
            elif key == "upgraded":
                try:
                    upgraded = int(value)
                except ValueError:
                    upgraded = 0

        # a real answer clears the backoff: the counter is consecutive failures, not a total
        self._auto_update_retries = 0

        if not answer:
            # The check did not run or did not answer. It used to give up for the life of this
            # process, which is the wrong shape for a machine that is left on for weeks: one failed
            # question at start-up, while the network was still coming up or while apt-daily held
            # the lists lock, meant no updates were looked for again until somebody restarted the
            # dashboard. So it waits and asks again, with the wait doubling each time, because a
            # machine whose archive is genuinely gone should not ask every fifteen seconds either.
            self._retry_the_update_check()
            return

        # -1 is "the flatpak half could not be asked", which is not the same as "nothing waiting":
        # a machine whose only updates are flatpak ones, and whose remote is briefly unhappy, would
        # otherwise decide it had nothing to do and update nothing. Running the update anyway costs
        # a few seconds, which is why it is the safe direction (ADR-0051).
        if not upgraded and not offered and waiting == 0:
            if self._update_trouble:
                # "nothing newer" and "I could not find out" are different things, and only one of
                # them means the machine is being kept up to date. A stale answer is not a reason to
                # stop asking: the source that could not be read may be back in a minute
                #
                # And the person is told, once, in the place this interface already says what
                # happened. A machine that has quietly stopped updating is the fault this whole
                # path exists to avoid, and it is invisible from a couch unless it is said out loud
                log.warning("%s; asking again later", self._update_trouble)
                self._set_status("this machine could not read one of its update sources")
                self._retry_the_update_check()
                return
            log.info("this machine's sources have nothing newer")
            self._auto_update_asked = True
            return

        if self._auto_update_asked:
            return
        self._auto_update_asked = True

        log.info(
            "this machine's sources have %d package(s) and %d flatpak application(s) newer%s, "
            "so it is updating itself",
            upgraded,
            waiting,
            f", including Couchbox {offered}" if offered else "",
        )
        self._ask_the_engine_to_update()

    def _ask_the_engine_to_update(self) -> None:
        """the same request the Updates page makes, made by the dashboard instead of a person."""
        if store_model is None:
            log.info("there is no store engine to ask, so the update is not started")
            return
        try:
            store_model.start_engine()
            answer = store_model.engine_command({"command": "update"})
        except Exception as error:  # noqa: BLE001 - a failed update must not take the dashboard
            log.warning("the update could not be asked for (%s)", error)
            return
        if isinstance(answer, dict):
            log.info("the update engine said %s", answer.get("message", "nothing"))

    def _watch_for_update_restart(self, entries: list[dict]) -> None:
        """restart the dashboard when a system update replaced the package it runs from.

        A machine updates itself in a process of its own, so the update finishing does not
        change the code this dashboard is running: somebody has to start it again, and the
        session already knows how, because a dashboard that exits is started again
        (couchbox-xsession). What this adds is the asking, and the whole of that is here: the
        helper says which version the Couchbox package reached (ADR-0043), the engine writes
        it beside the job, and this reads it and restarts once the dashboard is the thing on
        screen again, because an update never takes the screen from an application.

        The job's finish time is compared with the time this process started, and that is the
        whole of the loop protection: the update that replaced an older dashboard finished
        before this one started, so it is history here, and only a later update can restart
        this one. An update that changed nothing prints nothing, so nothing restarts for it.
        """
        if not self._restart_pending:
            for entry in entries:
                changed = entry.get("restart")
                finished = entry.get("finished_at")
                # A failed job still counts, and that is the point of it not asking about the
                # state. The apt half can have replaced the package and the flatpak half then
                # failed, which leaves new files on disk and old code running; the next check finds
                # nothing to do, so this is the only moment anything can notice. Asking for "done"
                # meant the restart was dropped exactly when it was most needed
                if not isinstance(changed, str) or not changed:
                    continue
                if not isinstance(finished, (int, float)) or finished <= self._started_at:
                    continue
                self._restart_pending = True
                log.info(
                    "an update changed the Couchbox package to %s, so this dashboard "
                    "restarts when it is back in front",
                    changed,
                )
                break
        self._restart_for_update_if_ready()

    def _restart_for_update_if_ready(self, front_has_let_go: bool = False) -> bool:
        """restart for an update when the dashboard is the thing on screen. True when it did.

        The moment is "the dashboard is in front, with nothing over it and nothing about to
        appear": while an application is in front, or the overlay is up, or a launch is in
        flight, the request waits, and every poll asks again. `front_has_let_go` says that the
        application in front has just finished and its record is already gone, which is the
        one case where the application-in-front flag reads true without an application behind
        it; the caller is the application's own finish handler.
        """
        if not self._restart_pending or self._restart_acted:
            return False
        if not front_has_let_go and self._application_in_front:
            return False
        if self._overlay or self._launching:
            return False
        self._restart_acted = True
        log.info("restarting the dashboard so the updated Couchbox package is what runs")
        self.quitForUpdate()
        return True

    @Slot()
    def quitForUpdate(self) -> None:
        """leave, because an update has replaced the package this dashboard runs from.

        A slot of its own rather than `quit` with an argument, for two reasons. The session has to
        be able to tell this from a person quitting, because it starts the dashboard again for this
        and returns to the console for that; and a method that is called by name is a method a
        check can watch, which `quit` already was.
        """
        self._leave(EXIT_FOR_AN_UPDATE)

    # --- the clock and the indicators ----------------------------------------

    @Slot()
    def start_system_info(self) -> None:
        """begin reading what the machine is doing, for the strip along the top of the screen.

        Started once the window exists, because the reading is skipped while an application is
        in front and that question cannot be asked without a window. The first reading is taken
        here rather than a poll interval later, so a dashboard does not spend its first five
        seconds with an empty clock in the corner.
        """
        self._audio_available = systeminfo.audio_available()
        self._refresh_system(slow=True)
        self._system_timer = QTimer(self)
        self._system_timer.setInterval(SYSTEM_POLL_MS)
        self._system_timer.timeout.connect(self._poll_system)
        self._system_timer.start()

    def _poll_system(self) -> None:
        """one pass over the machine's state, unless the shell is meant to be quiet.

        While an application is in front the dashboard is hidden and this reads nothing at all.
        That is the whole of the performance story for this feature: the cost of the clock, the
        battery, the network and the volume while somebody is playing a game is zero, not small.
        """
        if self._application_in_front:
            return
        if self._window is not None and not self._window.isVisible():
            return
        self._system_passes += 1
        self._refresh_system(slow=self._system_passes % SYSTEM_SLOW_EVERY == 0)

    def _ask_the_machine(self, audio_available: bool) -> None:
        """read the things that run a program, on a thread, and hand the answer back.

        Nothing here touches the interface. The answer is a plain dict and the signal carries it to
        `_system_answered`, which Qt delivers on the thread that owns this object, which is the
        thread that draws.
        """

        def read() -> None:
            answer: dict = {"volume": None, "name": "", "kind": "", "hardware": False}
            try:
                if audio_available:
                    answer["volume"] = systeminfo.volume()
                answer["name"] = systeminfo.connection_name()
                answer["kind"] = systeminfo.network_kind() if answer["name"] else ""
                answer["hardware"] = systeminfo.network_available()
            except Exception as error:  # noqa: BLE001 - nothing here is worth stopping for
                # a reading that fails leaves the strip showing what it last knew, which is better
                # than an empty strip and much better than an exception inside a thread nobody is
                # watching. The next slow pass asks again
                log.warning("could not read the machine: %s", error)
                answer["failed"] = True
            self.systemRead.emit(answer)

        threading.Thread(target=read, name="couchbox-system-read", daemon=True).start()

    @Slot(object)
    def _system_answered(self, answer: dict) -> None:
        """the machine's answer, on the thread that draws."""
        self._reading = False
        if not answer.get("failed"):
            self._volume = answer.get("volume")
            self._network_name = answer.get("name") or ""
            self._network_kind = answer.get("kind") or ""
            self._has_network_hardware = bool(answer.get("hardware"))
        # and through the same comparison as any other pass, so the interface is told about a change
        # in exactly one place
        self._refresh_system(slow=False)

    def _refresh_system(self, slow: bool) -> None:
        """read the machine's state and tell the interface when anything moved.

        The clock and the battery are read every pass, because they are files, and everything that
        runs a program is read on the slow pass. Every value is compared before the signal is
        emitted: an indicator that redraws at the same value four times a second is work the machine
        does for nobody.
        """
        clock = time.strftime("%H:%M")
        date = time.strftime("%a %-d %b")

        # a file, and cheap enough to be worth being exact about
        battery = systeminfo.battery()

        # and this spawns `wpctl`, which is why it is not here. Read every five seconds it was
        # about seven hundred processes an hour on a machine whose whole design is that an idle
        # interface does nothing, and each of them can block for two seconds when the sound server
        # is unwell. A volume change refreshes it directly, which is the only moment the number
        # needs to be current.
        volume = self._volume

        name = self._network_name
        kind = self._network_kind
        hardware = self._has_network_hardware
        if slow and not self._reading:
            # The network readings run `nmcli`, and the volume runs `wpctl`. Each has a two second
            # ceiling, which is nothing on a healthy machine and a window that stops drawing on one
            # where the service is unwell. Asking on a thread means the strip can be one refresh out
            # of date instead of the interface being one refresh behind a program (ADR-0055).
            #
            # The values are carried in, so the drawn answer is never missing: the pass that starts
            # the read draws what it already knows, and the answer arrives as a signal.
            self._reading = True
            self._ask_the_machine(self._audio_available)

        moved = (
            clock != self._clock
            or date != self._date
            or battery != self._battery
            or volume != self._volume
            or name != self._network_name
            or kind != self._network_kind
            or hardware != self._has_network_hardware
        )
        self._clock = clock
        self._date = date
        self._battery = battery
        self._volume = volume
        self._network_name = name
        self._network_kind = kind
        self._has_network_hardware = hardware

        if moved:
            self.systemChanged.emit()
            # the overlay's quick settings draw the volume, so its rows changed too when it did
            if volume != self._volume_at_last_actions:
                self.overlayActionsChanged.emit()
            self._volume_at_last_actions = volume

    # --- the starting screen ---------------------------------------------------

    def _begin_launch(self, name: str, icon: str = "") -> None:
        """show the application's name until it has a window of its own."""
        self._launching = True
        self._launching_name = name
        self._launching_icon = icon
        self._launch_deadline = time.monotonic() + LAUNCH_GIVE_UP_SECONDS
        self._xprop_failures = 0
        if self._launch_watcher is None:
            self._launch_watcher = QTimer(self)
            self._launch_watcher.setInterval(LAUNCH_WATCH_MS)
            self._launch_watcher.timeout.connect(self._watch_for_application_window)
        self._launch_watcher.start()
        self.launchingChanged.emit()
        log.info("showing a starting screen for '%s' until its window appears", name)

    def _end_launch(self, hide_window: bool) -> None:
        """the starting screen is over. Hide the window too, if that is what this moment means."""
        if self._launch_watcher is not None:
            self._launch_watcher.stop()
        was = self._launching
        self._launching = False
        self._launching_name = ""
        self._launching_icon = ""
        if was:
            self.launchingChanged.emit()
        if hide_window and self._window is not None and not self._windowed:
            self._window.hide()

    def _watch_for_application_window(self) -> None:
        """look for the application's window, and yield the screen to it when it appears.

        The alternative shapes are both worse. Hiding at once gives a black screen for as long
        as the application takes to draw, which is what this was designed to end. Waiting for
        the process to say something does not work, because most programs say nothing. So the
        X server is asked the one question that has an answer: whether there is a window that
        is not this one (ADR-0034).
        """
        if not self._launching:
            if self._launch_watcher is not None:
                self._launch_watcher.stop()
            return

        if time.monotonic() > self._launch_deadline:
            log.warning(
                "'%s' has shown no window after %d seconds, so the dashboard gets out of the "
                "way anyway",
                self._launching_name,
                LAUNCH_GIVE_UP_SECONDS,
            )
            self._end_launch(hide_window=self._should_yield_screen())
            return

        found, answered = self._application_window_present()
        if not answered:
            self._xprop_failures += 1
            if self._xprop_failures >= 3:
                log.warning(
                    "windows cannot be listed on this machine, so the dashboard gets out of "
                    "the way as soon as an application starts, as it did before"
                )
                self._end_launch(hide_window=self._should_yield_screen())
            return

        if not found:
            return
        log.info("'%s' has a window of its own now", self._launching_name)
        self._end_launch(hide_window=self._should_yield_screen())

    def _should_yield_screen(self) -> bool:
        """is the application the thing that should be on screen, rather than the dashboard.

        False when the user has since asked for the dashboard or the overlay: the starting
        screen then quietly stops being a starting screen instead of hiding a window the user
        is looking at.
        """
        return self._application_in_front and not self._overlay

    def _application_window_present(self) -> tuple[bool, bool]:
        """is there a window that is not this one. (found, the question could be asked)."""
        if XPROP is None:
            return (False, False)
        try:
            result = subprocess.run(
                [XPROP, "-root", "_NET_CLIENT_LIST"],
                capture_output=True,
                text=True,
                timeout=2,
            )
        except (OSError, subprocess.SubprocessError):
            return (False, False)
        if result.returncode != 0 or "not found" in result.stdout:
            # no window manager, or one that does not publish the list. either way the
            # question cannot be answered here, and the caller falls back
            return (False, False)

        own = self._own_window_id()
        for identifier in re.findall(r"0x[0-9a-fA-F]+", result.stdout):
            try:
                value = int(identifier, 16) & 0xFFFFFFFF
            except ValueError:
                continue
            if own is None or value != own:
                return (True, True)
        return (False, True)

    def _own_window_id(self) -> int | None:
        """this window's X identifier, so that it is not counted as somebody else's window."""
        if self._window is None:
            return None
        try:
            return int(self._window.winId()) & 0xFFFFFFFF
        except (RuntimeError, TypeError, ValueError):
            return None

    def _front_application(self) -> RunningApplication | None:
        """the application the dashboard is hidden for, or None when nothing is running.

        The front application is the last of the list. It used to be the one started most recently
        and this said that nothing could bring an older application forward; the list is ordered
        rather than write-once now, and `_switch_to` moves an application to the end, which is the
        whole of bringing one forward. Everything here reads the order and nothing keeps a number
        of its own, so when the front one exits the one before it becomes the front one without any
        bookkeeping to get wrong.
        """
        return self._running[-1] if self._running else None

    def _set_status(self, text: str) -> None:
        if text != self._status:
            self._status = text
            self.statusChanged.emit()

    # --- the pieces QML cannot reach on its own ------------------------------

    def attach_window(self, window) -> None:
        self._window = window

    def attach_overlay_window(self, window) -> None:
        """the small window the overlay is drawn in over a running application (ADR-0035)."""
        self._overlay_window = window

    def start_gamepad(self) -> None:
        self._gamepad = gamepad_input.Gamepad(self)
        self._gamepad.keyPressed.connect(self._on_gamepad_key)
        if not self._gamepad.start():
            log.info("continuing without a gamepad, which is a supported machine")

    def start_hotkeys(self) -> None:
        """begin listening for the guide key.

        Called once the interface is up rather than before it, so that a socket which
        cannot be created costs a line in the log instead of a screen that never appears.
        The dashboard is worth having without a hotkey, and a black screen is not.
        """
        self._hotkeys = hotkey_input.HotkeyServer(parent=self)
        self._hotkeys.pressed.connect(self._on_guide)
        self._hotkeys.start()

    @Slot(int)
    def _on_gamepad_key(self, key: int) -> None:
        """turn a controller button into a key press and give it to the window in front.

        This is the whole of the gamepad support as far as the interface is
        concerned. The QML sees the key and cannot tell whether a controller or a
        keyboard produced it, which is what makes both work everywhere, instead of
        in the places where somebody remembered to write two handlers.
        """
        target = self._window
        if self.overlayOverApplication and self._overlay_window is not None:
            # the overlay is a window of its own at that moment, and the dashboard's window is
            # hidden behind an application: the keys belong to what is actually on screen
            target = self._overlay_window
        if target is None:
            return
        for kind in (QEvent.Type.KeyPress, QEvent.Type.KeyRelease):
            QCoreApplication.sendEvent(
                target, QKeyEvent(kind, key, Qt.KeyboardModifier.NoModifier)
            )


def run(windowed: bool = False, size: tuple[int, int] | None = None) -> int:
    """start the dashboard. returns the process exit code."""
    application = QGuiApplication(sys.argv)
    application.setApplicationName("couchbox-shell")
    application.setDesktopFileName("couchbox-shell")

    shell = Shell(windowed=windowed, size=size)
    # a singleton rather than a context property, so that the QML declares what it
    # uses rather than picking a name out of the air
    qmlRegisterSingletonInstance(Shell, "Couchbox", 1, 0, "Shell", shell)

    engine = QQmlApplicationEngine()
    engine.addImportPath(str(HERE / "qml"))

    qml_file = HERE / "qml" / "dashboard.qml"
    engine.load(QUrl.fromLocalFile(str(qml_file)))
    if not engine.rootObjects():
        log.error("the dashboard did not load. the QML error above is the reason")
        return 1

    # the overlay's own window, loaded into the same engine so that it can see the same
    # `Shell` singleton the dashboard uses. A second engine cannot: Qt allows a registered
    # singleton instance to be read by one engine only, which was measured rather than assumed.
    # It is a window of its own so that opening the overlay over an application does not raise
    # the dashboard over it (ADR-0035)
    overlay_file = HERE / "qml" / "overlay.qml"
    engine.load(QUrl.fromLocalFile(str(overlay_file)))
    if len(engine.rootObjects()) < 2:
        # the overlay is worth having, but a dashboard without it is still a dashboard
        log.error("the overlay did not load, so the overlay over an application is unavailable")

    roots = engine.rootObjects()
    shell.attach_window(roots[0])
    if len(roots) > 1:
        shell.attach_overlay_window(roots[1])
    shell.start_gamepad()
    shell.start_hotkeys()
    shell.start_installs()
    shell.start_system_info()
    # the input threads are stopped on the way out, whenever the way out is Qt's rather than
    # a signal: an abort at exit would look like the dashboard crashing on every quit
    application.aboutToQuit.connect(shell.shutdown)

    return application.exec()
