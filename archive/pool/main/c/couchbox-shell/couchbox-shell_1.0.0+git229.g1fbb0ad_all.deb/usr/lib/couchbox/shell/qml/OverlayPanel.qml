import QtQuick
import Couchbox 1.0

// the overlay, drawn once and worn by both places it appears: over the dashboard, and in a small
// window of its own over a running application (ADR-0035).
//
// It has two regions, and the split between them is the whole design.
//
// The top is a row of tiles: where the overlay can take somebody. The dashboard is always the
// first, and every running application follows. Choosing one goes there, which makes this a
// switcher rather than a picture of what is open.
//
// The bottom is a list: what can be done from here. Closing an application, playing something
// again, the volume, and the three ways to stop the machine.
//
// Destination above, action below. An earlier version had one list holding both, and every
// destination in it was a verb - "Resume", "Dashboard" - sitting in the same column as "Close
// Kodi" and "Sleep", which is why it read as a menu of everything the machine could do rather
// than as a guide. The two verbs were deleted the moment the two tiles that meant the same thing
// were drawn.
//
// The list is inside a Flickable and the selection follows the view rather than the other way
// round. The panel's height is what decides whether every row is reachable on a 720 high screen,
// so a row that falls below the fold has to be reachable by moving, and a list that silently
// became un-scrollable the next time a row was added is exactly the fault that only shows up on
// the smallest screen this project supports.
Item {
    id: panel

    // a name for the checks, so one can ask this panel how tall it is rather than asking a
    // photograph whether it thinks something was drawn
    objectName: "overlayPanel"

    // the header, the switcher when there is one, the list, the padding, and the gaps the column
    // puts between them.
    //
    // This is what the hosts fit the panel to, and it was left out of the rebuild: `Item` has an
    // implicit height of nothing, so the panel became a zero-height box and the overlay drew its
    // dim over a dashboard with no panel in it. Nothing caught it, because the check that asks
    // whether the overlay was drawn compared a picture with the starting screen, and the starting
    // screen gives itself up on a machine that cannot list windows, so the two pictures differed
    // whether or not the panel was in either of them. The dim is a sibling of the panel and was
    // drawn the whole time, which is why the corner of the screen was measurably darker and the
    // middle of it was a dashboard.
    readonly property int gaps: (tiles.length > 0 ? 2 : 1) * unit * 0.8
    // `rows.implicitHeight` and not the clamped height the scroller uses: the clamp reads
    // `panel.height`, which is what the host sets from this, and asking for the clamped height
    // here is a binding loop. What the panel wants to be is the height of everything it holds;
    // the scroller is what gives way when the host cannot give it that much
    implicitHeight: header.implicitHeight + padding * 2
                    + (tiles.length > 0 ? tileHeight : 0)
                    + rows.implicitHeight
                    + gaps

    // the switcher: where the overlay can take somebody. Every entry is `{title, kind, index,
    // icon, front}`, built by the shell so that both hosts draw the same thing
    property var tiles: []
    property int tileSelection: 0

    // what can be done from here, built by the shell for the same reason
    property var actions: []
    property int selection: 0

    // What is chosen, by the name of the row rather than by its place in the list.
    //
    // The rows are rebuilt whenever anything about them changes, and a position means a different
    // row afterwards: the cursor was on "Close Kodi", a background application exited, and the
    // cursor was on the recent row that slid up into that place, with nothing pressed. The shell
    // gives every row a key that does not move, and this is what the panel remembers between
    // rebuilds.
    property string selectedKey: ""
    property string tileKey: ""

    // which of the two regions has the keyboard. The tiles come first, because arriving on the
    // thing you came to switch to is what a guide is for, and the actions are one press down
    property bool tilesHaveFocus: true

    property int unit: 10

    // how far in the panel has come: 0 before it is on screen, 1 when it has settled. The two
    // hosts animate it, because they arrive differently. Over the dashboard the whole layer fades
    // and this is what makes the panel settle a moment after the dim behind it; over a running
    // application the window cannot fade at all - an X server with no compositor ignores a
    // window's opacity - so this is the only part of that appearance that can be animated, and
    // without it the panel appears in one frame.
    property real revealAmount: 1

    // what the header says about the machine. Empty strings are dropped rather than drawn, so a
    // machine with no network shows no network rather than an empty space
    property string machineLine: ""
    property string versionLine: ""
    property string clockLine: ""

    // Choosing a tile goes there and is the shell's business; choosing a row does what the row
    // says. Two signals rather than one, because they are two different lists and the shell has a
    // different entry point for each.
    //
    // The tile is named by what it is rather than by where it sits: the list is rebuilt whenever
    // what is running changes, so a position can name something else by the time it is pressed.
    signal tileChosen(string kind, string launcher)
    signal rowChosen(int index)

    // the panel is deliberately compact: its height is what decides whether every row it holds is
    // reachable on a 720 high screen, so the padding and the per-row room are the smallest that
    // still read from a couch
    readonly property int padding: unit * 1.4
    readonly property int itemHeight: unit * 3.6
    readonly property int headerRowHeight: unit * 2.0

    // a tile is an icon with its name under it, and it is wider than it is tall so that several
    // fit across the panel the window is given
    readonly property int tileWidth: unit * 7.6
    readonly property int tileIconSize: unit * 4.2
    readonly property int tileHeight: unit * 7.2
    readonly property int tileSpacing: unit * 1.0

    ConsolePalette {
        id: colors
    }

    // --- moving around ---------------------------------------------------------

    // the selection only ever lands on something that can be chosen: a heading is not a
    // destination, and landing on one would mean a press that did nothing
    function firstRow() {
        for (let i = 0; i < panel.actions.length; ++i) {
            if (panel.actions[i].kind !== "header") {
                return i;
            }
        }
        return 0;
    }

    function hasRows() {
        for (let i = 0; i < panel.actions.length; ++i) {
            if (panel.actions[i].kind !== "header") {
                return true;
            }
        }
        return false;
    }

    // where the overlay starts: on the switcher, and on the thing that is already in front when
    // there is one, because the first press of a guide usually means "take me back"
    function resetSelection() {
        panel.tilesHaveFocus = panel.tiles.length > 0;
        if (!panel.tilesHaveFocus) {
            panel.selection = panel.firstRow();
            return;
        }
        let landing = 0;
        for (let i = 0; i < panel.tiles.length; ++i) {
            if (panel.tiles[i].front) {
                landing = i;
                break;
            }
        }
        panel.tileSelection = landing;
        panel.revealTile();
    }

    function moveVertically(step) {
        if (panel.tilesHaveFocus) {
            // down off the tiles and into the actions, which is the only way out of the top
            // region. Up from the top row is the way back, and the two are the same edge
            if (step > 0 && panel.hasRows()) {
                panel.tilesHaveFocus = false;
                panel.selection = panel.firstRow();
                panel.reveal();
            }
            return;
        }
        if (step < 0 && panel.selection === panel.firstRow()) {
            // leaving the top of the list returns to the switcher rather than wrapping to the
            // bottom of it: the tiles are above the rows on screen, so moving up and arriving at
            // the last row would be a jump across the panel
            if (panel.tiles.length > 0) {
                panel.tilesHaveFocus = true;
                panel.revealTile();
            }
            return;
        }
        panel.moveInList(step);
    }

    function moveInList(step) {
        if (panel.actions.length === 0) {
            return;
        }
        let next = panel.selection;
        for (let tried = 0; tried < panel.actions.length; ++tried) {
            next = (next + step + panel.actions.length) % panel.actions.length;
            if (panel.actions[next].kind !== "header") {
                panel.selection = next;
                panel.selectedKey = panel.keyAt(next);
                panel.reveal();
                return;
            }
        }
    }

    function moveSideways(step) {
        if (panel.tilesHaveFocus) {
            if (panel.tiles.length === 0) {
                return;
            }
            panel.tileSelection =
                (panel.tileSelection + step + panel.tiles.length) % panel.tiles.length;
            panel.revealTile();
            return;
        }
        // in the list, left and right do what up and down do. A row that does nothing when a
        // direction is pressed reads as a broken row, and this is the list of things to do rather
        // than a row of things to choose between
        panel.moveInList(step);
    }

    function on_a_control() {
        // whether the chosen row is something a direction changes rather than something a
        // direction moves past. The callers ask before deciding what left and right mean
        if (panel.tilesHaveFocus) {
            return false;
        }
        const item = panel.actions[panel.selection];
        return !!item && item.kind === "volume";
    }

    function activate() {
        if (panel.tilesHaveFocus) {
            panel.chooseTile(panel.tileSelection);
            return;
        }
        const item = panel.actions[panel.selection];
        if (!item || item.kind === "header") {
            return;
        }
        panel.rowChosen(panel.selection);
    }

    // hand back what a tile is rather than where it sits, so that a list rebuilt under the
    // interface cannot make a press mean something else
    function chooseTile(index) {
        if (index < 0 || index >= panel.tiles.length) {
            return;
        }
        const tile = panel.tiles[index];
        panel.tileChosen(tile.kind === undefined ? "" : String(tile.kind),
                         tile.launcher === undefined ? "" : String(tile.launcher));
    }

    // what a row is called, which is what survives a rebuild and a position does not
    function keyAt(index) {
        const item = panel.actions[index];
        if (!item) {
            return "";
        }
        return item.key === undefined ? "" : String(item.key);
    }

    // and the same for a tile: its kind and its launcher, which is what the shell acts on
    function tileKeyAt(index) {
        const tile = panel.tiles[index];
        if (!tile) {
            return "";
        }
        const kind = tile.kind === undefined ? "" : String(tile.kind);
        const launcher = tile.launcher === undefined ? "" : String(tile.launcher);
        return kind + ":" + launcher;
    }

    // keep the selection on a row that exists and can be chosen.
    //
    // The rows are rebuilt from the shell whenever anything about them changes, which includes an
    // application finishing while the overlay is open. The selection is a number, so a list that
    // got shorter left it past the end and a list that lost a heading left it on one. The hosts
    // call this whenever the shell says the rows have changed, and it is not the same thing as
    // naming a row by its identity: that would be the better fix and is not what this is. What
    // this guarantees is that the cursor is always somewhere a press does something.
    // and the same for the tiles, which nothing clamped at all.
    //
    // They are rebuilt whenever what is running changes, which includes a background application
    // exiting while the overlay is open: three tiles become two, the selection stays at 2, no tile
    // is drawn as chosen, and A does nothing because there is no tile at that position. A dead
    // press and a lost ring, recoverable by pressing a direction, which is exactly the kind of
    // fault nobody reports and everybody notices.
    onTilesChanged: {
        let landed = -1;
        if (panel.tileKey !== "") {
            for (let i = 0; i < panel.tiles.length; ++i) {
                if (panel.tileKeyAt(i) === panel.tileKey) {
                    landed = i;
                    break;
                }
            }
        }
        if (landed >= 0) {
            panel.tileSelection = landed;
        } else if (panel.tileSelection >= panel.tiles.length) {
            panel.tileSelection = Math.max(0, panel.tiles.length - 1);
        }
        if (panel.tileSelection < 0) {
            panel.tileSelection = 0;
        }
        panel.tileKey = panel.tileKeyAt(panel.tileSelection);
        panel.revealTile();
    }

    function clampSelection() {
        if (!panel.hasRows()) {
            panel.tilesHaveFocus = panel.tiles.length > 0;
            return;
        }
        // the row that was chosen, wherever it has moved to. A row that is gone falls back to the
        // first that can be chosen, which is what this did for every rebuild before
        let landed = -1;
        if (panel.selectedKey !== "") {
            for (let i = 0; i < panel.actions.length; ++i) {
                if (panel.keyAt(i) === panel.selectedKey
                        && panel.actions[i].kind !== "header") {
                    landed = i;
                    break;
                }
            }
        }
        panel.selection = landed >= 0 ? landed : panel.firstRow();
        panel.selectedKey = panel.keyAt(panel.selection);
        if (panel.tiles.length === 0) {
            panel.tilesHaveFocus = false;
        }
        panel.reveal();
    }

    // --- keeping the choice where it can be seen -------------------------------

    // keep the chosen row inside the panel, moving the view as little as it takes. This is what
    // makes the panel safe to grow: without it, a row added below the fold is a row nobody can
    // reach, and it fails on the smallest screen rather than the largest
    function reveal() {
        const row = rows.children[panel.selection];
        if (!row) {
            return;
        }
        const top = row.y;
        const bottom = row.y + row.height;
        if (top < scroller.contentY) {
            scroller.contentY = top;
        } else if (bottom > scroller.contentY + scroller.height) {
            scroller.contentY = bottom - scroller.height;
        }
    }

    // and the same for the tiles across, which matters as soon as there are more applications
    // running than the panel is wide
    function revealTile() {
        const tile = tileRow.children[panel.tileSelection];
        if (!tile) {
            return;
        }
        const left = tile.x;
        const right = tile.x + tile.width;
        if (left < tileScroller.contentX) {
            tileScroller.contentX = left;
        } else if (right > tileScroller.contentX + tileScroller.width) {
            tileScroller.contentX = right - tileScroller.width;
        }
    }

    // The key is read from the selection whenever the selection moves, so there is one place that
    // decides what "chosen" means and the re-anchoring above only ever reads it. The scattered
    // version of this set the key at each site that moved the cursor, which is four sites and four
    // chances to forget one.
    onSelectionChanged: {
        panel.selectedKey = panel.keyAt(panel.selection);
        panel.reveal();
    }
    onTileSelectionChanged: {
        panel.tileKey = panel.tileKeyAt(panel.tileSelection);
        panel.revealTile();
    }
    onTilesHaveFocusChanged: {
        if (!panel.tilesHaveFocus) {
            panel.reveal();
        }
    }

    // how tall the list may be: the panel is given a height by its host and this is what is left
    // of it after the header, the switcher and the padding. Not being able to ask the host
    // directly is why this is a function on the panel rather than a number computed by the caller
    function maximumListHeight() {
        const available = panel.height - panel.padding * 2 - header.implicitHeight
                          - (panel.tiles.length > 0 ? panel.tileHeight + panel.unit * 0.8 : 0)
                          - panel.unit * 0.8;
        return Math.max(panel.itemHeight, available);
    }

    Rectangle {
        anchors.fill: parent
        // the roundness of everything else on this machine. It was unit * 0.8, which on a forty
        // unit panel is a corner of eight pixels on a four hundred pixel box: near enough to
        // square to read as a rectangle with the corners knocked off, which is what made the
        // panel look like it came from somewhere else
        radius: panel.unit * 1.6
        color: colors.surface
        border.color: colors.border
        border.width: 1
        opacity: panel.revealAmount

        Column {
            anchors.fill: parent
            anchors.margins: panel.padding
            spacing: panel.unit * 0.8
            opacity: panel.revealAmount

            // Nothing may be drawn outside the panel. Adding the row of running applications made
            // the column taller than the panel it is anchored to, and an Item does not clip what
            // it holds, so the last two power rows were drawn below the panel's own bottom edge:
            // a list that runs out of a rounded card and into the application behind it
            clip: true

            // a few pixels of settle, from below, so that the rows arrive rather than being
            // switched on. A transform rather than a margin, because a margin would move the
            // layout and make the rows re-measure while the animation runs
            transform: Translate {
                y: (1 - panel.revealAmount) * panel.unit * 1.2
            }

            // --- the header: whose machine this is, and what it is doing ---------

            Item {
                id: header

                width: parent.width
                implicitHeight: Math.max(left.implicitHeight, right.implicitHeight)

                Column {
                    id: left

                    anchors.left: parent.left
                    anchors.top: parent.top
                    spacing: panel.unit * 0.1

                    Text {
                        text: "Couchbox"
                        color: colors.dim
                        font.pixelSize: Math.round(panel.unit * 1.15)
                        font.capitalization: Font.AllUppercase
                        font.letterSpacing: panel.unit * 0.12
                    }

                    Text {
                        visible: panel.versionLine !== ""
                        text: panel.versionLine === "" ? "" : "version " + panel.versionLine
                        color: colors.faint
                        font.pixelSize: Math.round(panel.unit * 1.0)
                    }
                }

                Column {
                    id: right

                    anchors.right: parent.right
                    anchors.top: parent.top
                    spacing: panel.unit * 0.1

                    Text {
                        anchors.right: parent.right
                        visible: panel.clockLine !== ""
                        text: panel.clockLine
                        color: colors.text
                        font.pixelSize: Math.round(panel.unit * 1.5)
                        font.bold: true
                    }

                    Text {
                        anchors.right: parent.right
                        visible: panel.machineLine !== ""
                        text: panel.machineLine
                        color: colors.dim
                        font.pixelSize: Math.round(panel.unit * 1.05)
                        elide: Text.ElideRight
                        width: Math.min(implicitWidth, panel.width * 0.5)
                        horizontalAlignment: Text.AlignRight
                    }
                }
            }

            // --- the switcher: where the overlay can take somebody ----------------

            Flickable {
                id: tileScroller

                width: parent.width
                // the selected tile is ringed, and the ring is drawn inside the tile rather than
                // around it, so the scroller is as tall as a tile and nothing more
                height: panel.tiles.length > 0 ? panel.tileHeight : 0
                contentWidth: tileRow.implicitWidth
                contentHeight: height
                interactive: false
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                visible: panel.tiles.length > 0

                Row {
                    id: tileRow

                    spacing: panel.tileSpacing

                    Repeater {
                        model: panel.tiles

                        delegate: Item {
                            id: overlayTile

                            required property var modelData
                            required property int index

                            readonly property bool chosen:
                                panel.tilesHaveFocus && index === panel.tileSelection

                            width: panel.tileWidth
                            height: panel.tileHeight

                            // the ring, which is the same shape language the dashboard's tiles
                            // use: a rounded box behind the icon that lights up when it is
                            // chosen, so the choice is readable from a couch without reading
                            Rectangle {
                                id: art

                                anchors.horizontalCenter: parent.horizontalCenter
                                anchors.top: parent.top
                                width: panel.tileIconSize + panel.unit * 1.2
                                height: width
                                radius: panel.unit * 1.1
                                color: overlayTile.chosen ? colors.surfaceFocused
                                                          : colors.surfaceRaised
                                border.width: overlayTile.chosen
                                              ? Math.max(2, Math.round(panel.unit * 0.16))
                                              : 1
                                border.color: overlayTile.chosen ? colors.accent : colors.border

                                Behavior on color {
                                    ColorAnimation { duration: 120 }
                                }

                                Image {
                                    anchors.centerIn: parent
                                    width: panel.tileIconSize
                                    height: width
                                    source: overlayTile.modelData.icon
                                            ? overlayTile.modelData.icon
                                            : ""
                                    fillMode: Image.PreserveAspectFit
                                    asynchronous: true
                                    visible: source !== "" && status !== Image.Error
                                }

                                // an application with no icon of its own gets its first letter on
                                // the raised box, so the row keeps its shape and the tile still
                                // says which one it is
                                Text {
                                    anchors.centerIn: parent
                                    visible: !(overlayTile.modelData.icon
                                               && overlayTile.modelData.icon !== "")
                                    text: overlayTile.modelData.title
                                          ? overlayTile.modelData.title.charAt(0).toUpperCase()
                                          : "?"
                                    color: overlayTile.chosen ? colors.accent : colors.dim
                                    font.pixelSize: Math.round(panel.unit * 2.2)
                                    font.bold: true
                                }
                            }

                            Text {
                                anchors.horizontalCenter: parent.horizontalCenter
                                anchors.top: art.bottom
                                anchors.topMargin: panel.unit * 0.5
                                width: parent.width
                                text: overlayTile.modelData.title || ""
                                // the thing already in front is written the same as the chosen
                                // tile, because "this is where you are" and "this is what you
                                // chose" are the same piece of information when they agree
                                color: overlayTile.chosen || overlayTile.modelData.front
                                       ? colors.text
                                       : colors.dim
                                font.pixelSize: Math.round(panel.unit * 1.05)
                                font.bold: overlayTile.chosen || overlayTile.modelData.front
                                horizontalAlignment: Text.AlignHCenter
                                elide: Text.ElideRight
                            }

                            // a mouse can choose a tile, which costs one handler and is never the
                            // only way to do anything
                            MouseArea {
                                anchors.fill: parent
                                onClicked: {
                                    panel.tilesHaveFocus = true;
                                    panel.tileSelection = overlayTile.index;
                                    panel.chooseTile(overlayTile.index);
                                }
                            }
                        }
                    }
                }
            }

            // --- what can be done ------------------------------------------------

            Flickable {
                id: scroller

                width: parent.width
                height: Math.min(rows.implicitHeight, panel.maximumListHeight())
                contentWidth: width
                contentHeight: rows.implicitHeight
                interactive: false
                clip: true
                boundsBehavior: Flickable.StopAtBounds

                Column {
                    id: rows

                    width: scroller.width
                    spacing: panel.unit * 0.35

                    Repeater {
                        model: panel.actions

                        delegate: Rectangle {
                            id: overlayRow

                            required property var modelData
                            required property int index

                            readonly property bool chosen:
                                !panel.tilesHaveFocus && index === panel.selection
                            readonly property bool heading: modelData.kind === "header"

                            // most rows are title-only, and a detail that is absent rather than
                            // empty must not become a line of text. when one is present it is
                            // drawn here as the single elided line the row gives it
                            readonly property string detailText: {
                                const given = overlayRow.modelData.detail;
                                return given === undefined || given === null ? "" : String(given);
                            }

                            width: rows.width
                            height: heading ? panel.headerRowHeight : panel.itemHeight
                            radius: panel.unit * 1.0
                            color: overlayRow.heading || !overlayRow.chosen
                                    ? "transparent"
                                    : colors.surfaceFocused
                            border.width: !overlayRow.heading && overlayRow.chosen
                                    ? Math.max(1, Math.round(panel.unit * 0.12))
                                    : 0
                            border.color: colors.accent

                            // the row fills in rather than switching, so moving down the list is
                            // something the eye follows
                            Behavior on color {
                                ColorAnimation {
                                    duration: 120
                                }
                            }

                            // the accent bar down the left of the chosen row, which is what makes
                            // the choice readable from a couch even when the row itself is dim
                            Rectangle {
                                anchors.left: parent.left
                                anchors.top: parent.top
                                anchors.bottom: parent.bottom
                                anchors.leftMargin: panel.unit * 0.35
                                anchors.topMargin: panel.unit * 0.5
                                anchors.bottomMargin: panel.unit * 0.5
                                width: Math.max(2, Math.round(panel.unit * 0.28))
                                radius: width / 2
                                color: colors.accent
                                opacity: !overlayRow.heading && overlayRow.chosen ? 1 : 0

                                Behavior on opacity {
                                    NumberAnimation { duration: 120 }
                                }
                            }

                            // the artwork for a row that has some, which is what the recent rows
                            // are: a name is a word about a game and a picture is the game. Sized
                            // to the row so that the list keeps its rhythm rather than growing a
                            // taller row wherever something has been played
                            Image {
                                id: rowArt

                                anchors.left: parent.left
                                anchors.leftMargin: panel.unit * 1.1
                                anchors.verticalCenter: parent.verticalCenter
                                width: Math.round(panel.itemHeight * 0.74)
                                height: width
                                source: overlayRow.modelData.artwork
                                        ? overlayRow.modelData.artwork
                                        : ""
                                fillMode: Image.PreserveAspectFit
                                asynchronous: true
                                visible: !overlayRow.heading && source !== ""
                                         && status !== Image.Error
                            }

                            Text {
                                id: rowTitle

                                anchors.left: parent.left
                                anchors.right: rowDetail.left
                                anchors.leftMargin: rowArt.visible
                                                  ? panel.unit * 1.1 + rowArt.width + panel.unit * 0.9
                                                  : panel.unit * 1.3
                                anchors.rightMargin: panel.unit * 1.2
                                anchors.verticalCenter: parent.verticalCenter
                                text: overlayRow.modelData.title === undefined
                                    ? ""
                                    : overlayRow.modelData.title
                                color: overlayRow.heading ? colors.faint : colors.text
                                font.pixelSize: Math.round(
                                    panel.unit * (overlayRow.heading ? 0.95 : 1.5))
                                font.bold: !overlayRow.heading && overlayRow.chosen
                                font.capitalization: overlayRow.heading
                                    ? Font.AllUppercase
                                    : Font.MixedCase
                                elide: Text.ElideRight
                            }

                            Text {
                                id: rowDetail

                                anchors.right: parent.right
                                anchors.rightMargin: panel.unit * 1.3
                                anchors.verticalCenter: parent.verticalCenter
                                visible: !overlayRow.heading && overlayRow.detailText !== ""
                                text: overlayRow.detailText
                                color: colors.accent
                                font.pixelSize: Math.round(panel.unit * 1.2)
                                elide: Text.ElideRight
                                width: Math.min(implicitWidth, panel.width * 0.35)
                                horizontalAlignment: Text.AlignRight
                            }

                            // The volume row is a control, so it is drawn as one: the level is a
                            // bar somebody can see from a couch rather than a number they have to
                            // read. It sits between the name and the value, and it is the only
                            // thing in this panel that a direction changes rather than moves past.
                            Rectangle {
                                anchors.left: parent.left
                                // clear of the longest word a control row has, which is
                                // "Volume" at the row's own type size
                                // Clear of the longest label a control row has, which is
                                // "Volume". Three attempts went into this: 7.4 units and 9.0 both
                                // left the bar sitting on the last letter, and following
                                // `rowTitle.contentWidth` did too, because a Text that is being
                                // elided reports the width of what it is drawing rather than of
                                // what it was given. A fixed inset wide enough for the word is
                                // honest about what it is and cannot be wrong in a new way
                                anchors.leftMargin: panel.unit * 12.0
                                anchors.right: rowDetail.left
                                anchors.rightMargin: panel.unit * 1.2
                                anchors.verticalCenter: parent.verticalCenter
                                height: Math.max(6, Math.round(panel.unit * 0.7))
                                radius: height / 2
                                color: colors.surfaceRaised
                                border.width: 1
                                border.color: colors.border
                                visible: overlayRow.modelData.kind === "volume"

                                Rectangle {
                                    width: parent.width
                                           * Math.max(0, Math.min(100, overlayRow.modelData.level || 0))
                                           / 100
                                    height: parent.height
                                    radius: parent.radius
                                    // a muted machine says so in the bar rather than only in the
                                    // number, because a bar at 40% with no sound is the thing that
                                    // looks broken
                                    color: overlayRow.modelData.muted ? colors.faint : colors.accent

                                    Behavior on width {
                                        NumberAnimation {
                                            duration: 120
                                            easing.type: Easing.OutCubic
                                        }
                                    }
                                }
                            }

                            // a mouse can click a row, which costs one handler and is never the
                            // only way to do anything
                            MouseArea {
                                anchors.fill: parent
                                enabled: !overlayRow.heading
                                onClicked: {
                                    panel.tilesHaveFocus = false;
                                    panel.selection = overlayRow.index;
                                    panel.rowChosen(overlayRow.index);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
