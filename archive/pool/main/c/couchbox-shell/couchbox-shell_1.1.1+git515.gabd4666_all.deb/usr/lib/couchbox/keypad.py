"""a keyboard a controller can drive, in one place.

It was written twice inside the settings app, where it is how somebody types a wi-fi password, and
it is needed again for the store's search: a search field that only a hardware keyboard can fill
is a search field a controller cannot use, which on this machine is most of them.

The alternative was a second copy of ninety lines of grid arithmetic that has to agree with itself
about how the D-pad wraps at the end of a row, and the two copies would drift in the way copies
do: somebody fixes the wrap in one and not the other, and the machine behaves differently
depending on which window is open.

Imported the way `theme` is, by name, because the image puts the Couchbox library directory on the
path for every application it starts.
"""

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QDialog,
    QGridLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
)

import theme


class Keypad(QDialog):
    """a keyboard a controller can drive, which the Qt one cannot be.

    Qt Virtual Keyboard draws a touch keyboard: its keys answer a mouse or a finger, and a
    D-pad moves nothing on it, so it cannot be how somebody with a controller types a wi-fi
    password (ADR-0032). This is a grid of ordinary buttons instead. The D-pad moves between
    them and wraps at the ends of a row, A presses the focused key because A arrives as
    Return, Start (Menu) finishes, B (Escape) cancels, and a hardware keyboard types straight
    in because those keys arrive as text.

    The secret is shown with everything but its last character masked, which is what a
    password field does everywhere else, and is enough to notice a keypress that did not land.
    """

    LETTERS = (
        "1234567890",
        "qwertyuiop",
        "asdfghjkl",
        "zxcvbnm",
    )
    SYMBOLS = (
        "!@#$%^&*()",
        "-+=[]{}:;",
        "\"'<>,.?/",
        "\\|~`",
    )

    def __init__(self, parent, prompt: str, masked: bool = False):
        super().__init__(parent)
        self.setWindowTitle("Type")
        self.setModal(True)
        # no title bar and no frame. It is a keyboard for a text field, not a window with an
        # application inside it, and a window manager's decoration around it made it read as the
        # second: a small program somebody had opened rather than part of what they were doing.
        # The prompt above the field says what is being typed, which a title bar was doing badly.
        # and on top of whatever asked for it, which is not decoration. The installer takes the
        # whole screen, and a window manager is free to keep a fullscreen window above an ordinary
        # dialog: whether it does is a race, and losing it means the keypad opens *behind* the
        # installer. A person sees a click that did nothing, clicks again, and that click lands on
        # whatever button is underneath, which looks like the installer going somewhere at random
        # and like there being no way to type a name at all.
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.Dialog
            | Qt.WindowType.WindowStaysOnTopHint
        )
        self._masked = masked
        self._symbols = False
        self._shift = False
        self._text = ""
        self._rows: list[list[QPushButton]] = []
        self._letters: list[QPushButton] = []

        top = QLabel(prompt)
        top.setFont(theme.font(16))

        self.display = QLabel("")
        self.display.setFont(theme.font(26))
        self.display.setMinimumHeight(52)
        self.display.setStyleSheet(
            f"background: {theme.SURFACE}; border: 1px solid {theme.BORDER};"
            f" padding: 8px; color: {theme.ACCENT};"
        )

        self.grid = QGridLayout()
        self.grid.setSpacing(6)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 28, 28, 28)
        layout.setSpacing(12)
        layout.addWidget(top)
        layout.addWidget(self.display)
        layout.addLayout(self.grid)

        # the cursor blinks, which is the whole of how somebody knows where their typing is going
        # and that the thing is listening. A still underscore is punctuation at the end of a word
        self._cursor_on = True
        self._blink = QTimer(self)
        self._blink.setInterval(500)
        self._blink.timeout.connect(self._toggle_cursor)

        self._build()
        self._update_display()
        self._blink.start()

    def showEvent(self, event) -> None:
        """come to the front when shown, and take the focus with it.

        The flag above is the guarantee; this is the part that works on a window manager that
        ignores the flag. Both are cheap and neither is enough on its own.
        """
        super().showEvent(event)
        self.raise_()
        self.activateWindow()

    def text(self) -> str:
        return self._text

    def set_text(self, text: str) -> None:
        """start from something rather than from nothing.

        The store's search opens this with whatever is already being searched for, so that a
        second look is an edit rather than a retype. The settings opens it empty, because a
        password is typed once and is not shown back.
        """
        self._text = text
        self._update_display()

    # --- building ---------------------------------------------------------

    def _key(self, label: str, action, letter: bool = False) -> QPushButton:
        button = QPushButton(label)
        button.setAutoDefault(False)
        button.setDefault(False)
        button.setMinimumSize(64, 54)
        button.setFont(theme.font(20 if len(label) == 1 else 14))
        button.clicked.connect(lambda _checked=False: action())
        if letter:
            self._letters.append(button)
        return button

    def _build(self) -> None:
        while self.grid.count():
            item = self.grid.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self._rows = []
        self._letters = []

        keys = self.SYMBOLS if self._symbols else self.LETTERS
        for row_index, row in enumerate(keys):
            buttons: list[QPushButton] = []
            for column, character in enumerate(row):
                label = character.upper() if (self._shift and character.isalpha()) else character
                button = self._key(
                    label,
                    lambda ch=character: self._press(ch),
                    letter=character.isalpha(),
                )
                self.grid.addWidget(button, row_index, column)
                buttons.append(button)
            self._rows.append(buttons)

        specials: list[tuple[QPushButton, int]] = []
        specials.append((self._key("?123" if not self._symbols else "abc", self._toggle_page), 2))
        if not self._symbols:
            specials.append((self._key("shift", self._toggle_shift), 2))
        specials.append((self._key("space", lambda: self._append(" ")), 4 if not self._symbols else 5))
        specials.append((self._key("backspace", self._backspace), 2 if not self._symbols else 3))

        last: list[tuple[QPushButton, int]] = [
            (self._key("cancel", self.reject), 5),
            (self._key("done", self.accept), 5),
        ]

        base = len(keys)
        for row_index, row in enumerate((specials, last), start=base):
            column = 0
            buttons = []
            for button, span in row:
                self.grid.addWidget(button, row_index, column, 1, span)
                column += span
                buttons.append(button)
            self._rows.append(buttons)

        if self._rows:
            self._rows[0][0].setFocus()

    # --- what a key does --------------------------------------------------

    def _press(self, character: str) -> None:
        if not self._symbols and self._shift and character.isalpha():
            character = character.upper()
        self._append(character)

    def _toggle_cursor(self) -> None:
        self._cursor_on = not self._cursor_on
        self._update_display()

    def _wake_the_cursor(self) -> None:
        """show the cursor again and restart the blink, so that a keypress is visibly a keypress.

        Without this, a key pressed during the dark half of the blink leaves the cursor dark for up
        to half a second after the character appeared, which reads as the press not having landed.
        """
        self._cursor_on = True
        if self._blink.isActive():
            self._blink.start()

    def _append(self, character: str) -> None:
        self._text += character
        self._wake_the_cursor()
        self._update_display()

    def _backspace(self) -> None:
        self._text = self._text[:-1]
        self._wake_the_cursor()
        self._update_display()

    def _toggle_shift(self) -> None:
        self._shift = not self._shift
        for button in self._letters:
            button.setText(button.text().upper() if self._shift else button.text().lower())

    def _toggle_page(self) -> None:
        self._symbols = not self._symbols
        self._build()

    def _update_display(self) -> None:
        if self._masked and len(self._text) > 1:
            shown = "*" * (len(self._text) - 1) + self._text[-1]
        else:
            shown = self._text
        self.display.setText(shown + ("_" if self._cursor_on else ""))

    # --- moving and typing ------------------------------------------------

    def _move(self, key) -> None:
        if not self._rows:
            return
        focused = self.focusWidget()
        row = column = 0
        for r, buttons in enumerate(self._rows):
            if focused in buttons:
                row, column = r, buttons.index(focused)
                break
        last_row = len(self._rows) - 1
        if key == Qt.Key.Key_Left:
            if column == 0:
                row = last_row if row == 0 else row - 1
                column = len(self._rows[row]) - 1
            else:
                column -= 1
        elif key == Qt.Key.Key_Right:
            if column >= len(self._rows[row]) - 1:
                row = 0 if row == last_row else row + 1
                column = 0
            else:
                column += 1
        elif key == Qt.Key.Key_Up:
            row = last_row if row == 0 else row - 1
            column = min(column, len(self._rows[row]) - 1)
        else:
            row = 0 if row == last_row else row + 1
            column = min(column, len(self._rows[row]) - 1)
        self._rows[row][column].setFocus()

    def keyPressEvent(self, event) -> None:  # noqa: N802 - Qt's name
        key = event.key()
        if key == Qt.Key.Key_Space:
            # Space presses the focused key, and that is the controller's button rather than the
            # keyboard's. gamepad.py translates a controller's A to Space when it is handed to a
            # button, because a QPushButton answers Space and not Return; so Space is A here, the
            # D-pad moves between the keys, and the two of them type.
            focused = self.focusWidget()
            if isinstance(focused, QPushButton):
                focused.click()
            return
        if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            # and Return finishes, which is the keyboard's way. It used to press the focused key,
            # which left a keyboard with no way to say it was done: Return pressed "1" because a key
            # is always focused, and Escape only cancels. Two ways in and neither could finish was
            # the whole of "there is no way to input usernames". Start (Menu) still finishes too.
            self.accept()
            return
        if key == Qt.Key.Key_Menu:
            self.accept()
            return
        if key in (Qt.Key.Key_Escape, Qt.Key.Key_Back):
            self.reject()
            return
        if key == Qt.Key.Key_Backspace:
            self._backspace()
            return
        if key in (Qt.Key.Key_Left, Qt.Key.Key_Right, Qt.Key.Key_Up, Qt.Key.Key_Down):
            self._move(key)
            return
        text = event.text()
        if text and len(text) == 1 and text.isprintable():
            self._append(text)
            return
        super().keyPressEvent(event)



class TypedField(QLineEdit):
    """a field that opens the keypad, and looks like somewhere a name goes.

    It replaces a button that said "Not set yet" and did the same thing, which was the mistake: a
    button is a verb and this is a place to put a value, and nothing about it said "type here". A
    person reported that there was no way to input a username at all, which is what that looks like
    from the outside.

    So it is a real line edit, which is to say a box with a caret in it, holding what has been typed
    and the words "Not set yet" when nothing has. It is read only, because the typing happens on the
    keypad and a controller cannot type into a field: this catches the click, and the Return a
    controller's A arrives as, and opens the keypad for both.

    Escape is deliberately not handled here, so that it falls through to whatever the application
    means by back (ADR-0036).
    """

    def __init__(self, prompt: str, on_change=None):
        super().__init__()
        self._prompt = prompt
        self._on_change = on_change
        self.setReadOnly(True)
        self.setPlaceholderText("Not set yet")
        # focusable, so that a D-pad can reach it the way it reaches anything else on the page
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        # and big enough to read as somewhere to type rather than as a label. A line edit sizes
        # itself to its contents, and its contents here are the four words "Not set yet" in eleven
        # point grey, which came out as a small chip with nothing on it: a photograph of the page
        # is what said so.
        self.setFont(theme.font(20))
        self.setMinimumWidth(theme.GAP * 26)
        self.setMinimumHeight(theme.GAP * 5)

    def setText(self, value: str) -> None:
        super().setText(value or "")
        self.setCursorPosition(len(value or ""))

    def ask(self, seed: str = "") -> None:
        """open the keypad, starting from what is already there and whatever was just typed."""
        keypad = Keypad(self.window(), self._prompt)
        keypad.set_text(super().text() + seed)
        if keypad.exec() == QDialog.DialogCode.Accepted:
            self.setText(keypad.text().strip())
            if self._on_change is not None:
                self._on_change(super().text())

    def mousePressEvent(self, event) -> None:
        self.ask()
        super().mousePressEvent(event)

    def keyPressEvent(self, event) -> None:
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter, Qt.Key.Key_Space):
            self.ask()
            return
        # and a keyboard, because there is one on the machine and this is a read-only field: a
        # character typed into it went nowhere at all, which is the same as there being no way to
        # type a name. Typing opens the keypad with that character already in it, so a person with a
        # keyboard types as they expect and a person with a controller never notices.
        text = event.text()
        if text and len(text) == 1 and text.isprintable():
            self.ask(seed=text)
            return
        super().keyPressEvent(event)
