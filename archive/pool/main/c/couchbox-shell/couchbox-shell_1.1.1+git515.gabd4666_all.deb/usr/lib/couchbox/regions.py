"""where in the world this machine is, and how it writes the time.

Two programs ask these questions. The installer asks them once, when it writes a machine to a
disk, and the settings ask them again a year later. They read the same tables and they must agree,
which is why this is a module rather than a function in each of them: the installer's time zone
list was typed out by hand once and had no New Zealand in it.

Nothing here imports a toolkit. It reads two files that every Debian machine has - the zone table
and the country names that go with it - and it can be exercised without a display.
"""

from __future__ import annotations

from pathlib import Path

ZONE_TAB = Path("/usr/share/zoneinfo/zone.tab")
ISO3166_TAB = Path("/usr/share/zoneinfo/iso3166.tab")


def time_zones() -> list[tuple[str, str]]:
    """every zone this machine knows, as (zone, something to show).

    A person picks "Auckland, New Zealand", not "Pacific/Auckland". The database carries the
    country code and the zone, and both are read here rather than remembered.
    """
    countries: dict[str, str] = {}
    try:
        for line in ISO3166_TAB.read_text().splitlines():
            if line and not line.startswith("#"):
                fields = line.split("\t")
                if len(fields) > 1:
                    countries[fields[0]] = fields[1]
    except OSError:
        pass

    zones = [("UTC", "UTC")]
    try:
        for line in ZONE_TAB.read_text().splitlines():
            if not line or line.startswith("#"):
                continue
            fields = line.split("\t")
            if len(fields) < 3:
                continue
            country, zone = fields[0], fields[2]
            if zone == "UTC":
                continue
            city = zone.split("/")[-1].replace("_", " ")
            zones.append((zone, f"{city}, {countries.get(country, country)}"))
    except OSError:
        pass
    return zones


def this_machine_time_zone() -> str:
    """what the machine is set to now, which is what a page should open showing."""
    try:
        name = Path("/etc/timezone").read_text().strip()
    except OSError:
        name = ""
    if name and Path("/usr/share/zoneinfo", name).exists():
        return name
    return "UTC"


def this_machine_language() -> str:
    """the locale the machine is set to show dates and numbers in."""
    try:
        for line in Path("/etc/default/locale").read_text().splitlines():
            if line.startswith("LANG="):
                return line.split("=", 1)[1].strip().strip('"')
    except OSError:
        pass
    return "en_US.UTF-8"


def languages() -> list[str]:
    """the locales this machine can be set to.

    Read from the machine rather than from a list, for the same reason as the zones: a list
    somebody typed has whatever they happened to think of in it.
    """
    try:
        import subprocess

        result = subprocess.run(
            ["localectl", "list-locales"], capture_output=True, text=True, timeout=10, check=False
        )
        found = [line.strip() for line in result.stdout.splitlines() if line.strip()]
        if found:
            return found
    except Exception:
        pass
    return ["en_GB.UTF-8", "en_US.UTF-8"]


# --- how the machine writes the time ----------------------------------------------------------
#
# The time zone and the language are the system's business and are set with timedatectl and
# localectl. Whether the clock reads 19:20 or 7:20 pm is the dashboard's own, so it lives in a file
# in the person's configuration directory, written by the settings and read by the shell, in the
# same shape as the controller's preferences and for the same reason: everything here that survives
# a reboot is a file somebody can read, edit or delete.

FORMAT_FILE = Path.home() / ".config" / "couchbox" / "format.conf"

CLOCK_FORMATS = {"24": "%H:%M", "12": "%I:%M %p"}
DATE_FORMATS = {
    "day-first": "%a %-d %b",
    "month-first": "%a %b %-d",
    "long": "%A %-d %B",
}


def _read_format() -> dict[str, str]:
    values = {"clock": "24", "date": "day-first"}
    try:
        for line in FORMAT_FILE.read_text().splitlines():
            if "=" in line and not line.startswith("#"):
                key, _, value = line.partition("=")
                if key.strip() in values:
                    values[key.strip()] = value.strip()
    except OSError:
        pass
    return values


def chosen_format() -> dict[str, str]:
    """what the machine is set to show, for a page that has to draw the choice."""
    return _read_format()


def clock_pattern() -> str:
    """the strftime pattern the dashboard's clock uses."""
    return CLOCK_FORMATS.get(_read_format()["clock"], CLOCK_FORMATS["24"])


def date_pattern() -> str:
    """and the one under it. Day first is the default because more of the world writes it that
    way, and because this project's own text says "the 7th of October" rather than the reverse."""
    return DATE_FORMATS.get(_read_format()["date"], DATE_FORMATS["day-first"])


def write_format(clock: str | None = None, date: str | None = None) -> None:
    """change one or both, keeping the other as it was."""
    values = _read_format()
    if clock in CLOCK_FORMATS:
        values["clock"] = clock
    if date in DATE_FORMATS:
        values["date"] = date
    FORMAT_FILE.parent.mkdir(parents=True, exist_ok=True)
    FORMAT_FILE.write_text(
        "# how Couchbox writes the time and the date. See usr/lib/couchbox/regions.py.\n"
        f"clock={values['clock']}\n"
        f"date={values['date']}\n"
    )


# --- by country rather than by zone -----------------------------------------------------------
#
# Four hundred zones in one list is not a choice, it is a wall. The zone database already knows
# which country each zone belongs to, and a person knows which country they are in, so the first
# question is the country and the second is the zone - and for most countries there is only one
# zone, so there is no second question at all.
#
# The first part of a zone's name is the continent it is filed under: Europe/London, Pacific/
# Auckland, America/Sao_Paulo. That is the filter, and it is why there is no search box: a
# controller cannot type into one, and a list of fifty is a list somebody can read.


def countries() -> list[tuple[str, str, int]]:
    """(code, country, how many zones it has), alphabetically, with UTC last."""
    counts: dict[str, int] = {}
    for line in ZONE_TAB.read_text().splitlines() if ZONE_TAB.exists() else []:
        if not line or line.startswith("#"):
            continue
        fields = line.split("\t")
        if len(fields) >= 3:
            counts[fields[0]] = counts.get(fields[0], 0) + 1

    names: dict[str, str] = {}
    try:
        for line in ISO3166_TAB.read_text().splitlines():
            if line and not line.startswith("#"):
                fields = line.split("\t")
                if len(fields) > 1:
                    names[fields[0]] = fields[1]
    except OSError:
        pass

    found = [
        (code, names.get(code, code), count)
        for code, count in counts.items()
        if count
    ]
    found.sort(key=lambda row: row[1].casefold())
    return found


def zones_in(code: str) -> list[tuple[str, str]]:
    """every zone in one country, as (zone, something to show), best first."""
    found = []
    for line in ZONE_TAB.read_text().splitlines() if ZONE_TAB.exists() else []:
        if not line or line.startswith("#"):
            continue
        fields = line.split("\t")
        if len(fields) >= 3 and fields[0] == code:
            city = fields[2].split("/")[-1].replace("_", " ")
            found.append((fields[2], city))
    found.sort(key=lambda row: row[1].casefold())
    return found


def region_of(zone: str) -> str:
    """which part of the world a zone is filed under, for the filter."""
    return zone.split("/")[0] if "/" in zone else "UTC"
