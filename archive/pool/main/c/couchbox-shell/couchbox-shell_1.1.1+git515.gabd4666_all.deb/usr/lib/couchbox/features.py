"""what this machine is made of, what taking an addition would copy, and what the channel offers.

The image ships a manifest at `/usr/share/couchbox/features` naming every addition with a version of
its own, so that a new one can arrive without the version of the whole operating system moving
(ADR-0069). The update channel publishes a newer copy of that same file at the root of the archive, and
this is the reader for both.

Nothing here writes anything, and that is the decision rather than a limitation. Whether an addition
has been taken is whether its launcher is in the directory the shell searches, and putting it there
belongs to root; so what this returns is the *list of copies* that would be made, and whoever is
allowed to make them makes them. It means the interface, the checks, and the program that actually
takes something all agree about what taking it means, and it means the whole question can be asked by
somebody who cannot write to `/usr`.

A name is a name. The launcher's name is the identity here, as it is everywhere else in this project,
because an entry names a launcher and never a path or a command line. Every name that arrives from a
manifest is checked against that shape before it is ever used as one, so a manifest cannot ask for a
copy to somewhere it should not go. The manifest comes from the network, so it is a text file somebody
else can write, and this is the first place that has to behave as though it is.
"""

from __future__ import annotations

import os
import re
from pathlib import Path

# where the image keeps the manifest, where an addition that has not been taken waits, and where a
# taken one goes. Absolute, because this is read by a program that runs as root as well as by the
# interface, and those two do not agree about the current directory
MANIFEST = Path("/usr/share/couchbox/features")
PRELOADED = Path("/usr/share/couchbox/preloaded")
LAUNCHERS = Path("/usr/lib/couchbox/launchers")
APPS = Path("/usr/lib/couchbox/apps")

# a launcher's name: lower case, and nothing that could be a path. The dot is allowed for the names
# this project already has, and a name may not start with one, which is what stops ".." and a hidden
# file from being one
NAME_SHAPE = re.compile(r"^[a-z0-9][a-z0-9._-]*$")


class NotAName(ValueError):
    """something that is not a feature name, refused before it is used as one."""


def is_a_name(value: object) -> bool:
    """is this a name a feature could have."""
    return isinstance(value, str) and bool(NAME_SHAPE.match(value))


def parse(text: str) -> list[dict]:
    """the additions a manifest's text describes, in the order it lists them.

    Separate from `read` because the manifest that matters most is the one the channel publishes, which
    arrives as text over the network rather than as a file on this machine. Nothing here trusts the
    text: an entry with no name, or with a name that is not a name, is dropped along with the rest of
    its fields, because a nameless addition is one nothing could ever refer to and a name is the only
    handle anything else here has.
    """
    entries: list[dict] = []
    current: dict | None = None

    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or ":" not in stripped:
            continue
        key, _, value = stripped.partition(":")
        key = key.strip()
        value = value.strip()
        if key == "feature":
            current = {"name": value}
            entries.append(current)
        elif current is not None:
            current[key] = value

    return [entry for entry in entries if is_a_name(entry.get("name"))]


def read(manifest: Path | None = None) -> list[dict]:
    """this machine's own manifest.

    Missing or unreadable is an empty list rather than an exception: a machine with no manifest has no
    additions it knows about, which is a state this has to be able to describe rather than crash on.
    """
    path = MANIFEST if manifest is None else manifest
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return []
    return parse(text)


def version_of(entry: dict) -> int:
    """an addition's version, as a number.

    Whole numbers, because that is what this project publishes for an addition and what the manifest
    says: these versions are not the operating system's and there is no reason for them to look like
    Debian's. Anything that is not a whole number counts as nothing, so a comparison answers "not
    newer" rather than raising, and a manifest with nonsense in it cannot stop a machine updating.
    """
    try:
        return int(str(entry.get("version", "")).strip())
    except (TypeError, ValueError):
        return 0


def compare(theirs: list[dict], mine: list[dict] | None = None) -> list[dict]:
    """what to do about each addition another manifest names, in the order it names them.

    This is the whole of deciding, and it is deliberately a pure function of two lists: getting the
    other manifest here is somebody else's job, so a check can ask this question without a network.

    Each answer is a dict with a `name`, an `action`, and the `version` the other side offers:

      take                the image already has it and has not taken it, so it is a copy
      already             it is taken and the version offered is the one this machine has
      newer               it is taken and a higher version is offered, and it arrived in the image:
                          taking it again would change nothing, so what has to move is the thing that
                          carries the files, which is the operating system's package
      not-in-this-image   the other side says it is preloaded and this image does not have it, so the
                          manifest and the disk disagree, and saying so is the only honest answer
      fetch               the image does not have it, so it comes as a package of its own: the one
                          named after this addition, at the version the other side offers (ADR-0071)
    """
    if mine is None:
        mine = read()

    here = {entry["name"]: entry for entry in mine}
    answers: list[dict] = []

    for entry in theirs:
        name = entry.get("name")
        if not is_a_name(name):
            continue
        offered = version_of(entry)
        known = here.get(name)

        if is_taken(name):
            if known is not None and offered > version_of(known):
                # A newer version of something already here. Which way it moves depends on how it
                # arrived, and that is the difference the manifest exists to make: one that comes as
                # a package of its own is installed again at the version offered, and one the image
                # already carries cannot be changed by fetching anything, because the image is where
                # its files are
                action = "fetch" if entry.get("preloaded") != "yes" else "newer"
            else:
                action = "already"
        elif is_waiting(name):
            action = "take"
        elif entry.get("preloaded") == "yes":
            action = "not-in-this-image"
        else:
            action = "fetch"

        answers.append({"name": name, "action": action, "version": offered})

    return answers


def find(name: str, manifest: Path | None = None) -> dict | None:
    """the entry for one addition, or None when the manifest does not name it."""
    for entry in read(manifest):
        if entry["name"] == name:
            return entry
    return None


def is_taken(name: str) -> bool:
    """has this addition been taken, which is whether the shell would find it.

    The same question the shell asks and the same answer, which means the file has to be there *and*
    be executable. The shell refuses a wrapper that is not, deliberately: a wrapper that is present but
    not executable is a packaging mistake, and a dashboard that offers it anyway turns that mistake
    into a tile that does nothing when pressed. If this said taken for a file the shell would not
    accept, then a machine would be told it has something it has not, which is the fault this whole
    file exists to avoid.
    """
    if not is_a_name(name):
        return False
    path = LAUNCHERS / name
    return path.is_file() and os.access(path, os.X_OK)


def is_waiting(name: str) -> bool:
    """is this addition in the image, waiting to be taken."""
    return is_a_name(name) and (PRELOADED / name / "launcher").is_file()


def state(name: str, manifest: Path | None = None) -> str:
    """one of "taken", "waiting", "not-in-the-manifest", "not-here", or "not-a-name"."""
    if not is_a_name(name):
        return "not-a-name"
    if find(name, manifest) is None:
        return "not-in-the-manifest"
    if is_taken(name):
        return "taken"
    if is_waiting(name):
        return "waiting"
    return "not-here"


def taking(name: str, manifest: Path | None = None) -> list[tuple[Path, Path]]:
    """what taking this addition would copy, as (source, destination) pairs.

    Empty when there is nothing to do, which is the answer for an addition that is already taken, for
    one the manifest does not name, and for one whose files are not in the image. The caller can treat
    all three the same way and never has to ask which it was.

    Raises NotAName for anything that is not a name, because that is the one case where the request
    itself is wrong rather than simply having no work in it, and a caller that would go on to copy
    something needs to hear about it.
    """
    if not is_a_name(name):
        raise NotAName(f"{name!r} is not a feature name")

    if find(name, manifest) is None:
        return []

    if is_taken(name):
        # the shell can already find it, which is the whole of what taking it means. Checked once for
        # both files rather than per file: re-copying the program of an addition that is already there
        # would make "nothing to do" and "something to do" the same answer, and every caller here
        # treats the first as done
        return []

    where = PRELOADED / name
    copies: list[tuple[Path, Path]] = []

    launcher = where / "launcher"
    if launcher.is_file():
        copies.append((launcher, LAUNCHERS / name))

    # the program itself, if it has one. A feature can be a launcher alone, which is what an addition
    # that changes how something else is started looks like
    program = where / "app"
    if program.is_file():
        copies.append((program, APPS / name))

    return copies
