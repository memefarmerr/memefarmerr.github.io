"""who shares this machine.

The installer makes one account per player and sets the machine to log in as the first one, so
the account the session runs as is the first player rather than the only one. Everything else
here exists so the dashboard can ask, and so the answer is a name on the screen rather than a
login.

An ordinary account is one with a real login shell and an id at or above a thousand, which is
the line Debian draws between people and daemons. The name comes from the account's own field,
and the gamertag from the account name, because that is where the installer put them.

Nothing here writes anything. Choosing a player lasts for the session, which is what a console
does: it asks when it is switched on.
"""

from __future__ import annotations

import pwd
from pathlib import Path

FIRST_HUMAN = 1000
LAST_HUMAN = 65533
NOLOGIN = "/usr/sbin/nologin"


def all_players() -> list[dict[str, str]]:
    """every account a person could be, in the order the machine lists them."""
    found: list[dict[str, str]] = []
    try:
        accounts = sorted(pwd.getpwall(), key=lambda account: account.pw_uid)
    except OSError:
        return found

    for account in accounts:
        if not FIRST_HUMAN <= account.pw_uid <= LAST_HUMAN:
            continue
        if account.pw_shell.endswith(("nologin", "false")):
            continue
        try:
            if not Path(account.pw_dir).exists():
                continue
        except OSError:
            continue
        name = (account.pw_gecos or "").split(",")[0].strip()
        found.append({"tag": account.pw_name, "name": name or account.pw_name})
    return found


def the_account_this_session_is() -> str:
    """the account the dashboard is running as, which is the one that was logged in."""
    try:
        import os

        return pwd.getpwuid(os.getuid()).pw_name
    except (KeyError, OSError):
        return ""
