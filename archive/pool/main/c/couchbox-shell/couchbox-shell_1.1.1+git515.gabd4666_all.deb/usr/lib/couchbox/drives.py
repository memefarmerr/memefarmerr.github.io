"""what is plugged into this machine, and what it would take to look inside it.

A console that says nothing when somebody plugs a stick in is a console whose owner cannot tell whether
it noticed. That is the whole reason the file browser exists, and until now it could only answer the
question for a stick that something else had already mounted: a disk sitting there with a filesystem on
it and no mount point was not mentioned at all, which is exactly the state a stick is in when it is
plugged into a machine with no desktop managing it.

The listing comes from `lsblk`, which is in `util-linux` and therefore on every machine this project
builds. Its `-P` output is the one that is a list of pairs rather than a table, and the shapes below were
read off a real machine rather than from documentation:

    NAME="sda1" LABEL="" FSTYPE="ext4" SIZE="37.9G" RM="0" TYPE="part" MOUNTPOINT="/"
    NAME="sr0"  LABEL="COUCHBOX_OS" FSTYPE="iso9660" SIZE="1.1G" RM="1" TYPE="rom" MOUNTPOINT=""
    NAME="sda5" LABEL="" FSTYPE="swap" SIZE="2.1G" RM="0" TYPE="part" MOUNTPOINT="[SWAP]"

Nothing here mounts anything. Mounting is root's job and lives in `couchbox-files-helper`; this decides
what is worth offering and where it would go, so that the interface and the checks can ask the same
question as the program that does it, and somebody who cannot mount anything can still see the answer.

A device name is a name. It arrives from a caller, it becomes an argument to `mount`, and the only reason
it is safe to pass on is that it cannot be anything but one: lower case letters and digits, no slash, no
dot, nothing that could be a path or an option.
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path

LSBLK = "/usr/bin/lsblk"
LSBLK_TIMEOUT = 10

# where a stick is mounted when nothing else has claimed it. Under /media, which is one of the places
# the file browser already looks, so a stick mounted by this appears beside one mounted by anything else
MOUNT_ROOT = Path("/media")

# The shape of a kernel block device name: sda, sda1, nvme0n1p2, mmcblk0p1. Lower case letters and
# digits, starting with a letter, and nothing else at all.
#
# The first version of this was an attempt at the grammar of the names - letters, then digits, then
# letters, then digits - and it refused nvme0n1p2, which is what a laptop from the years this project is
# for has in it. A shape that is too clever to be right is worse than one that is too plain to be
# elegant, and what this has to be is impossible to confuse with a path, an option, or a command
DEVICE_SHAPE = re.compile(r"^[a-z][a-z0-9]*$")

# what can be mounted. A rom is a disc rather than a stick and is not offered, and anything without a
# filesystem has nothing to mount yet
MOUNTABLE_TYPES = ("part", "disk")

# a label is written on the outside of a thing by whoever made it, so it can say anything at all. What
# survives is lower case letters, digits, dot, dash and underscore, and anything else becomes a dash
LABEL_SHAPE = re.compile(r"[^A-Za-z0-9._-]")


def is_a_device(name: object) -> bool:
    """is this the name of a block device rather than a path somebody hoped for."""
    return isinstance(name, str) and bool(DEVICE_SHAPE.match(name))


def parse(text: str) -> list[dict]:
    """`lsblk -P` output as one dict per device, in the order it printed them.

    Values are unquoted and an empty one is an empty string rather than a missing key, because that is
    what the tool means by `LABEL=""` and code that has to ask whether a key is there as well as whether
    it is empty is code with two ways to be wrong.
    """
    found: list[dict] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        entry: dict = {}
        # two groups, so this returns pairs. It was written as three and every call raised, which the
        # first run of it said plainly
        for key, value in re.findall(r'([A-Z]+)="([^"]*)"', stripped):
            entry[key.lower()] = value
        if is_a_device(entry.get("name")):
            found.append(entry)
    return found


def listing() -> list[dict]:
    """what is plugged in, asked of the machine. Empty when the question cannot be asked at all."""
    if not Path(LSBLK).exists():
        return []
    try:
        done = subprocess.run(
            [
                LSBLK,
                "-P",
                "-o",
                "NAME,LABEL,FSTYPE,SIZE,RM,TYPE,MOUNTPOINT",
            ],
            capture_output=True,
            text=True,
            timeout=LSBLK_TIMEOUT,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return []
    if done.returncode != 0:
        return []
    return parse(done.stdout)


def is_removable(entry: dict) -> bool:
    """is this something somebody can pull out, rather than the disk the machine runs from."""
    return entry.get("rm") == "1" and entry.get("type") in MOUNTABLE_TYPES


def where_it_is(entry: dict) -> Path | None:
    """where this is mounted, or None when it is not.

    `[SWAP]` is what lsblk prints for a swap partition, and it is not a path: a thing in that state is
    in use as memory and must not be offered as somewhere to look.
    """
    place = entry.get("mountpoint", "")
    if not place or place.startswith("["):
        return None
    return Path(place)


def where_it_would_go(entry: dict) -> Path:
    """where this would be mounted if somebody asked.

    Its label when it has one, because that is what is written on the outside of the thing and what a
    person recognises; its kernel name otherwise, which is at least something to tell two sticks apart
    by. The label is sanitised rather than trusted: it is written by whoever made the disk.
    """
    name = entry["name"]
    label = LABEL_SHAPE.sub("-", str(entry.get("label", "")).strip()).strip("-.")
    return MOUNT_ROOT / (label or name)


def offers(entries: list[dict] | None = None) -> list[dict]:
    """the removable things, each with what is known about it, mounted ones first.

    What the interface shows and what the helper mounts, so that the list somebody presses and the list
    something acts on cannot disagree.
    """
    if entries is None:
        entries = listing()
    found = []
    for entry in entries:
        if not is_removable(entry):
            continue
        found.append(
            {
                "device": entry["name"],
                "label": entry.get("label", ""),
                "fstype": entry.get("fstype", ""),
                "size": entry.get("size", ""),
                "mountpoint": where_it_is(entry),
                "belongs_at": where_it_would_go(entry),
                "has_a_filesystem": bool(entry.get("fstype")),
            }
        )
    return sorted(found, key=lambda drive: (drive["mountpoint"] is None, drive["device"]))
