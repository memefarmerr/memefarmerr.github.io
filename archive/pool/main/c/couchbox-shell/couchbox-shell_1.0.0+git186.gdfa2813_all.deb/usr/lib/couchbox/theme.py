"""the look the Couchbox applications share.

The store and the settings are separate programs (ADR-0030) drawn by the same toolkit, and a
person moves between them and the dashboard without a transition to tell them the surface
changed. So the palette, the shapes and the focus treatment live here once, and an application
that wants a new kind of control adds it here rather than inventing a second look.

The design rules, and all of them come from the couch:

  * one dark surface, one warm accent, and a focus treatment loud enough to read from three
    metres. The focused control is the only bright-edged thing on the screen, so "where am I" is
    answered without reading anything.
  * nothing is operated by a keyboard shortcut that is not written down (ADR-0034). Controls are
    buttons and rows, and every one of them works with the D-pad, the Tab and arrow keys, the
    mouse, and Enter or Space. The styling says what is clickable by making it look clickable.
  * nothing is reachable only with a keyboard. A text field that needs typing is a text field a
    person on a couch cannot use, which is why the two applications avoid them: the store filters
    by categories rather than by a search box, and the one place that genuinely needs typing, a
    wi-fi password, has an on-screen keypad of its own (ADR-0032).

The numbers are the same as the dashboard's, on purpose: `theme.GAP` is the dashboard's `unit`
times one, the radii match, and an application that opened with a different rhythm from the shell
it was launched from would read as a different machine.

Importing this module does not import a toolkit; the functions that build widgets do their
imports inside themselves, so a program can use the colour constants without Qt.
"""

from __future__ import annotations

BACKGROUND = "#101014"
SURFACE = "#1b1b22"
SURFACE_RAISED = "#23232d"
SURFACE_FOCUSED = "#2b2b39"
BORDER = "#34343f"
BORDER_STRONG = "#4a4a5a"
TEXT = "#f4f4f7"
DIM = "#9a9aa8"
FAINT = "#6b6b7a"
ACCENT = "#e0a13c"
ACCENT_BRIGHT = "#f4c069"
GOOD = "#63c07a"
BAD = "#e06c5a"

# how far apart things sit, in the one scale every screen uses
GAP = 12
MARGIN = 40
RADIUS = 10

# the size a list row's icon is drawn at. Big enough to be recognised from a couch, small enough
# that a row is still a row rather than a picture with a caption
ICON = 56


def font(size: int, bold: bool = False):
    """the application font, at a point size, in the family the whole project draws with.

    The family is copied from the running application's own font, which is the font the dashboard's
    text is drawn with, so the three programs cannot drift apart. Do not build a QFont with an empty
    family instead: on the installed system an empty family resolves to Bitstream Charter, a serif,
    while the application font resolves to DejaVu Sans. The store and the settings used to be drawn
    in a different face from the rest of the system for exactly that reason. This is measured, not
    guessed: run the font probe in the built image's chroot before changing the line below.

    What this also prevents is an application picking a *second* face of its own: the volume readout
    and the About values used to be monospace, which read as a screen from a different program.
    """
    from PySide6.QtGui import QFont, QGuiApplication

    result = QFont(QGuiApplication.font())
    result.setPointSize(size)
    if bold:
        result.setWeight(QFont.Weight.Bold)
    return result


def palette():
    """the application palette. Everything that is not set here is deliberately default."""
    from PySide6.QtGui import QColor, QPalette

    result = QPalette()
    result.setColor(QPalette.ColorRole.Window, QColor(BACKGROUND))
    result.setColor(QPalette.ColorRole.Base, QColor(SURFACE))
    result.setColor(QPalette.ColorRole.AlternateBase, QColor(BACKGROUND))
    result.setColor(QPalette.ColorRole.Text, QColor(TEXT))
    result.setColor(QPalette.ColorRole.WindowText, QColor(TEXT))
    result.setColor(QPalette.ColorRole.ButtonText, QColor(TEXT))
    result.setColor(QPalette.ColorRole.Button, QColor(SURFACE))
    result.setColor(QPalette.ColorRole.Highlight, QColor(ACCENT))
    result.setColor(QPalette.ColorRole.HighlightedText, QColor(BACKGROUND))
    result.setColor(QPalette.ColorRole.PlaceholderText, QColor(FAINT))
    result.setColor(QPalette.ColorRole.ToolTipBase, QColor(SURFACE_RAISED))
    result.setColor(QPalette.ColorRole.ToolTipText, QColor(TEXT))
    return result


def stylesheet() -> str:
    """the application stylesheet. Rows, buttons and chips are what it mostly describes."""
    return f"""
        QWidget {{
            background: {BACKGROUND};
            color: {TEXT};
        }}
        QLabel {{
            background: transparent;
        }}
        QLabel#title {{
            color: {TEXT};
        }}
        QLabel#heading {{
            color: {DIM};
            text-transform: uppercase;
        }}
        QFrame#card {{
            background: {SURFACE};
            border: 1px solid {BORDER};
            border-radius: {RADIUS}px;
        }}
        QFrame#chip {{
            background: {SURFACE_RAISED};
            border: 1px solid {BORDER};
            border-radius: 11px;
        }}
        QPushButton {{
            background: {SURFACE};
            color: {TEXT};
            border: 1px solid {BORDER};
            border-radius: {RADIUS}px;
            padding: 12px 20px;
        }}
        QPushButton:hover {{
            background: {SURFACE_FOCUSED};
        }}
        QPushButton:focus {{
            background: {SURFACE_FOCUSED};
            border: 2px solid {ACCENT};
        }}
        QPushButton:disabled {{
            color: {FAINT};
            border-color: {BORDER};
        }}
        QPushButton#primary {{
            background: {ACCENT};
            color: #140f04;
            border: 1px solid {ACCENT};
            font-weight: bold;
        }}
        QPushButton#primary:hover {{
            background: {ACCENT_BRIGHT};
        }}
        QPushButton#primary:focus {{
            border: 2px solid {TEXT};
        }}
        QPushButton#primary:disabled {{
            background: {SURFACE};
            color: {FAINT};
            border-color: {BORDER};
        }}
        QPushButton#danger {{
            border: 1px solid {BAD};
            color: {BAD};
        }}
        QPushButton#danger:focus {{
            border: 2px solid {BAD};
            background: {SURFACE_FOCUSED};
        }}
        QListWidget {{
            background: transparent;
            border: none;
            outline: none;
        }}
        QListWidget::item {{
            padding: 10px 12px;
            border-left: 4px solid transparent;
            border-radius: 6px;
        }}
        QListWidget::item:selected {{
            background: {SURFACE_FOCUSED};
            border-left: 4px solid {ACCENT};
            color: {TEXT};
        }}
        QListWidget::item:hover {{
            background: {SURFACE_RAISED};
        }}
        /* a list row is a widget of its own so that it can hold a picture and two lines. It has to
           be transparent or it paints over the selection the view draws underneath it, which is
           how a list with rich rows ends up with no visible focus at all */
        QWidget#row {{
            background: transparent;
        }}
        /* a page inside the settings' card has to be transparent, or it paints its own
           background over the surface the card drew and the card becomes a border around nothing */
        QStackedWidget {{
            background: transparent;
        }}
        QStackedWidget > QWidget {{
            background: transparent;
        }}
        QScrollArea {{
            background: transparent;
            border: none;
        }}
        QScrollArea > QWidget > QWidget {{
            background: transparent;
        }}
        QPushButton#filter {{
            background: transparent;
            color: {DIM};
            border: 1px solid {BORDER};
            border-radius: 19px;
            padding: 4px 18px;
        }}
        QPushButton#filter:hover {{
            background: {SURFACE_FOCUSED};
            color: {TEXT};
        }}
        QPushButton#filter:focus {{
            border: 2px solid {ACCENT};
            color: {TEXT};
        }}
        QPushButton#filter:checked {{
            background: {SURFACE_RAISED};
            color: {TEXT};
            border: 1px solid {ACCENT};
        }}

        QComboBox {{
            background: {SURFACE};
            color: {TEXT};
            border: 1px solid {BORDER};
            border-radius: {RADIUS}px;
            padding: 6px 14px;
        }}
        QComboBox:hover {{
            background: {SURFACE_FOCUSED};
        }}
        QComboBox:focus {{
            border: 2px solid {ACCENT};
        }}
        QComboBox::drop-down {{
            border: none;
            width: 28px;
        }}
        QComboBox QAbstractItemView {{
            background: {SURFACE_RAISED};
            color: {TEXT};
            border: 1px solid {BORDER};
            selection-background-color: {SURFACE_FOCUSED};
            selection-color: {TEXT};
            outline: none;
        }}

        QPushButton:checked {{
            background: {SURFACE_FOCUSED};
            border: 2px solid {ACCENT};
            color: {TEXT};
        }}
        QLineEdit {{
            background: {SURFACE};
            border: 1px solid {BORDER};
            border-radius: {RADIUS}px;
            padding: 10px 14px;
            selection-background-color: {ACCENT};
            selection-color: #140f04;
        }}
        QLineEdit:focus {{
            border: 2px solid {ACCENT};
        }}
        QProgressBar {{
            background: {SURFACE};
            border: 1px solid {BORDER};
            border-radius: {RADIUS}px;
            text-align: center;
            color: {TEXT};
        }}
        QProgressBar::chunk {{
            background: {ACCENT};
            border-radius: 5px;
        }}
        QSlider::groove:horizontal {{
            height: 12px;
            background: {SURFACE};
            border: 1px solid {BORDER};
            border-radius: 6px;
        }}
        QSlider::sub-page:horizontal {{
            background: {ACCENT};
            border-radius: 6px;
        }}
        QSlider::handle:horizontal {{
            width: 26px;
            margin: -8px 0;
            background: {TEXT};
            border-radius: 13px;
        }}
        QSlider:focus {{
            border: none;
        }}
        QScrollBar:vertical {{
            background: transparent;
            width: 10px;
            margin: 0;
        }}
        QScrollBar::handle:vertical {{
            background: {BORDER};
            border-radius: 5px;
            min-height: 30px;
        }}
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
            height: 0;
        }}
        QCheckBox {{
            spacing: 10px;
        }}
        QToolTip {{
            background: {SURFACE_RAISED};
            color: {TEXT};
            border: 1px solid {BORDER};
        }}
    """


def title(text: str):
    """the name of the screen, top left, as big as the dashboard's headings are."""
    from PySide6.QtWidgets import QLabel

    label = QLabel(text)
    label.setObjectName("title")
    label.setFont(font(30, bold=True))
    return label


def heading(text: str):
    """the name of a region inside a screen: a list, a detail pane, a queue."""
    from PySide6.QtWidgets import QLabel

    label = QLabel(text)
    label.setObjectName("heading")
    label.setFont(font(13, bold=True))
    return label


def dim(text: str, size: int = 14):
    """a line that explains rather than names, so it is quieter than everything else."""
    from PySide6.QtWidgets import QLabel

    label = QLabel(text)
    label.setFont(font(size))
    label.setStyleSheet(f"color: {DIM};")
    label.setWordWrap(True)
    return label


def faint(text: str, size: int = 13):
    """the quietest kind of line: a source, a count, a version."""
    from PySide6.QtWidgets import QLabel

    label = QLabel(text)
    label.setFont(font(size))
    label.setStyleSheet(f"color: {FAINT};")
    return label


def hint(text: str, size: int = 13):
    """a strip or a footnote: what is happening, never which key to press (ADR-0036)."""
    from PySide6.QtWidgets import QLabel

    label = QLabel(text)
    label.setFont(font(size))
    label.setStyleSheet(f"color: {DIM};")
    label.setWordWrap(True)
    return label


def card(padding: int = GAP * 1.5):
    """a raised surface: the shape a detail pane or a queue row is drawn as.

    Returned as a plain QFrame so the caller fills it with whatever layout it wants. The object
    name is what the stylesheet above matches on, which is why this cannot simply be a QWidget
    with a border set here: an application that restyles itself should look like the rest.
    """
    from PySide6.QtWidgets import QFrame

    frame = QFrame()
    frame.setObjectName("card")
    frame.setContentsMargins(padding, padding, padding, padding)
    return frame


def chip(text: str, tone: str = DIM, size: int = 12):
    """a small rounded label: who supplies something, whether it is installed, how far along.

    It is a QLabel rather than a layout, because a chip is one line of text and a background, and
    an application that wants one should not have to assemble three widgets to get it.
    """
    from PySide6.QtWidgets import QLabel

    label = QLabel(text)
    label.setObjectName("chip")
    label.setFont(font(size, bold=True))
    label.setStyleSheet(
        f"color: {tone}; background: {SURFACE_RAISED}; border: 1px solid {BORDER};"
        f" border-radius: 11px; padding: 3px 12px;"
    )
    return label


def icon_label(path: str, size: int = ICON):
    """a picture of an application, at the size a list row or a detail pane draws one.

    Empty paths and missing files come back as an empty label rather than a broken image, because
    an application whose artwork has not been installed yet is an ordinary machine and not an
    error. The caller puts it in a layout either way, so the row's shape does not change.
    """
    from PySide6.QtCore import QSize, Qt
    from PySide6.QtGui import QPixmap
    from PySide6.QtWidgets import QLabel

    label = QLabel()
    label.setFixedSize(size, size)
    label.setAlignment(Qt.AlignmentFlag.AlignCenter)
    if not path:
        return label
    pixmap = QPixmap(path)
    if pixmap.isNull():
        return label
    label.setPixmap(
        pixmap.scaled(
            QSize(size, size),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
    )
    return label


class ElidedLabel:
    """a label that shortens its own text instead of being cut off by its container.

    Qt has no eliding label. The alternative is a QLabel whose text simply runs past the edge of
    the row it is in, which looks like a fault rather than like a long description, and there is
    no width at which that stops being true: the window is a television at whatever resolution it
    has. So the text is shortened in `paintEvent`, which is the one place that knows the width it
    is actually being drawn at.
    """

    def __new__(cls, text: str = "", size: int = 13, tone: str = DIM, bold: bool = False):
        from PySide6.QtCore import Qt
        from PySide6.QtGui import QPainter
        from PySide6.QtWidgets import QLabel, QSizePolicy

        class _Elided(QLabel):
            def __init__(self) -> None:
                super().__init__()
                self._full = text
                self.setFont(font(size, bold=bold))
                self.setStyleSheet(f"color: {tone}; background: transparent;")
                self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
                self.setText(text)

            def minimumSizeHint(self):  # noqa: N802 - Qt's name
                from PySide6.QtCore import QSize

                # without this the label demands the width of its whole text, which pushes the
                # badges beside it off the row. An elided label can always be narrower
                return QSize(1, super().minimumSizeHint().height())

            def paintEvent(self, event) -> None:  # noqa: N802 - Qt's name
                from PySide6.QtGui import QFontMetrics

                painter = QPainter(self)
                painter.setPen(self.palette().color(self.foregroundRole()))
                metrics = QFontMetrics(self.font())
                shortened = metrics.elidedText(
                    self._full, Qt.TextElideMode.ElideRight, self.width()
                )
                painter.drawText(
                    self.rect(),
                    int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                    shortened,
                )

        return _Elided()


def icon_pixmap(path: str, size: int = ICON):
    """the artwork for an application at a size, or a null pixmap when there is none.

    A null pixmap is a supported answer: an application whose artwork has not been generated or
    installed draws an empty space rather than a broken picture, and the caller puts it in the
    same place either way.
    """
    from PySide6.QtCore import QSize, Qt
    from PySide6.QtGui import QPixmap

    if not path:
        return QPixmap()
    pixmap = QPixmap(path)
    if pixmap.isNull():
        return pixmap
    return pixmap.scaled(
        QSize(size, size),
        Qt.AspectRatioMode.KeepAspectRatio,
        Qt.TransformationMode.SmoothTransformation,
    )


def icon_path(name: str) -> str:
    """where the artwork for a launcher or an interface glyph is, or "".

    The same two directories the dashboard reads, in the same order, so a store row and a
    dashboard tile cannot end up showing different pictures for the same application.
    """
    import os
    from pathlib import Path

    # The application's own icon first, then the generated tile. The store draws one picture per
    # row at a size a real icon is made for, and a person looking for Steam should see Steam rather
    # than a green card with a joystick on it.
    roots = (
        (os.environ.get("COUCHBOX_APPICON_DIR") or "/usr/share/couchbox/appicons", (".png", ".svg")),
        (os.environ.get("COUCHBOX_ICON_DIR") or "/usr/share/couchbox/icons", (".svg", ".png")),
    )
    for root, suffixes in roots:
        for suffix in suffixes:
            candidate = Path(root) / f"{name}{suffix}"
            if candidate.is_file():
                return str(candidate)
    return ""
