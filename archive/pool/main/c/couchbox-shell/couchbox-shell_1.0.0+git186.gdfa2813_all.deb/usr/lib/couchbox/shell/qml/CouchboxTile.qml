import QtQuick

// one tile on the shelf, and the same tile again in the grid of everything.
//
// It is a component of its own rather than a block copied into the two places it appears, because
// the two places differ only in how they arrange tiles: what a tile is - its shape, its focus
// ring, the shade over the artwork that is not focused, the name underneath - is one decision and
// lives here once.
//
// The shape is a game's box. 2:3 is the proportion of a boxed game and of the artwork that goes
// on one, and a shelf of tall tiles reads as a shelf from across a room in a way a row of squares
// does not. The artwork the image ships is generated at exactly this proportion
// (`scripts/generate-artwork.py`), so the image fills the tile with no letterboxing and nothing
// is ever cropped.
//
// The focus treatment is three things at once, because any one of them alone is easy to miss from
// a couch: the tile grows, a ring is drawn around it in the accent, and the tiles beside it are
// shaded down. All three are animated over the same short duration, so the eye follows the focus
// along the row rather than seeing it jump.
//
// The name is drawn under the tile and is *not* scaled with it. Scaling the artwork says where
// the focus is; scaling the text would make it wobble, and the text is the part somebody is
// reading.
Item {
    id: root

    // what this tile is. An object with `name`, `description` and `icon`, which is what
    // `shell/entries.py` hands the interface and all this needs to know about it
    property var entry: null

    property bool focused: false
    property int unit: 10
    property bool showLabel: true

    // the geometry, passed in rather than derived here, so that the shelf and the grid can be
    // different sizes without either of them owning a second copy of the arithmetic. The defaults
    // are the shelf's, which is the size the design is drawn at
    property real tileWidth: unit * 16
    property real tileHeight: Math.round(tileWidth * 4 / 3)
    property real ringWidth: Math.max(3, Math.round(unit * 0.5))
    // the room reserved under the artwork for the name. It is more than the text needs, which is
    // the point: the tile's focus ring is drawn at the frame's edge and the name was sitting close
    // enough to it that a focused tile's label read as part of the ring rather than as a caption
    property real labelHeight: unit * 3.4

    // the rounding of the artwork itself, as a fraction of the tile's width. The tile behind the
    // artwork has to use the same one: the art has its corners cut out, so a tile that is less
    // round than the picture shows the dark surface through every corner. See `artworkRadius`
    // below, and `ConsolePalette.artworkRadiusFraction` for where the number comes from
    property real artworkRadiusFraction: 56 / 384

    // the palette, passed in rather than imported, so that every window draws the same colours
    // without a second copy of them living here
    property color colorAccent: "#e0a13c"
    property color colorAccentBright: "#f4c069"
    property color colorSurface: "#20202a"
    property color colorSurfaceFocused: "#2b2b39"
    property color colorBorder: "#34343f"
    property color colorText: "#f4f4f7"
    property color colorDim: "#9a9aa8"
    property color colorShade: "#000000"
    property real shadeOpacity: 0.38

    property int motionFast: 120
    property int motionBase: 180
    property real focusScale: 1.07

    // the box the focus lifts: the tile and its ring together
    readonly property real boxWidth: tileWidth + ringWidth * 2
    readonly property real boxHeight: tileHeight + ringWidth * 2

    // a tile with no label still reserves the room, because the frame is what the shelf scrolls
    // by and a shelf whose tiles change size when a label is hidden is a shelf that reflows
    readonly property real reservedLabelHeight: showLabel ? labelHeight : 0

    // the frame a tile lives in. It is larger than the lifted box, because scaling an item whose
    // frame exactly fits it pushes the ring at its edge outside the shelf's clip region. Measured
    // on the old layout, where the ring came out two pixels thick at the top and five at the sides
    readonly property real frameWidth: Math.ceil(boxWidth * focusScale) + 2
    readonly property real frameHeight: Math.ceil(boxHeight * focusScale) + reservedLabelHeight + 2

    // the corner of the picture. It is a proportion rather than a length because the shelf and
    // the grid draw the same tile at different sizes and a fixed radius would be right in one of
    // them and wrong in the other
    readonly property real artworkRadius: Math.round(tileWidth * artworkRadiusFraction)

    readonly property bool hasArtwork: entry !== null && entry.icon !== undefined && entry.icon !== ""

    // the application's own mark, when `scripts/fetch-icons.py` found one. Drawn over the card
    // rather than instead of it: the card is what gives a shelf of tiles their colours and what
    // makes an application with no icon of its own still look like something
    readonly property bool hasAppIcon: entry !== null && entry.appicon !== undefined && entry.appicon !== ""

    width: frameWidth
    height: frameHeight

    // --- the artwork, lifted as one box -------------------------------------

    Item {
        id: artArea

        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top
        anchors.topMargin: Math.max(0, (root.height - root.reservedLabelHeight - root.boxHeight) / 2)

        width: root.boxWidth
        height: root.boxHeight

        scale: root.focused ? root.focusScale : 1.0

        Behavior on scale {
            NumberAnimation {
                duration: root.motionBase
                easing.type: Easing.OutCubic
            }
        }

        // the ring. It hugs the tile so it never lands on the artwork, and it fades in and out
        // rather than being drawn and not drawn, so the difference between focused and not is
        // something the eye follows rather than two frames
        Rectangle {
            anchors.fill: parent
            color: "transparent"
            // the tile's radius plus the ring's own width, which is what makes the ring concentric
            // with the picture rather than merely concentric with itself. At the tile's radius
            // instead, the ring turns a corner faster than the tile does and the two curves cross
            radius: root.artworkRadius + root.ringWidth
            border.width: root.ringWidth
            border.color: root.focused ? root.colorAccentBright : root.colorAccent
            opacity: root.focused ? 1 : 0

            Behavior on opacity {
                NumberAnimation { duration: root.motionFast }
            }
        }

        Rectangle {
            id: art

            anchors.centerIn: parent
            width: root.tileWidth
            height: root.tileHeight
            radius: root.artworkRadius
            clip: true
            border.width: 1
            border.color: root.colorBorder

            // slightly lighter at the top than the bottom, which is what makes a flat rectangle
            // read as a surface instead of as a hole in the screen. It is behind the artwork, so
            // it only shows for an entry that has none
            gradient: Gradient {
                GradientStop { position: 0.0; color: root.colorSurfaceFocused }
                GradientStop { position: 1.0; color: root.colorSurface }
            }

            Image {
                anchors.fill: parent
                source: root.hasArtwork ? root.entry.icon : ""
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
                // the artwork has its own rounded corners and its own border, so drawing it over
                // the whole tile means an entry with art is one clean picture and an entry
                // without is a readable word
                visible: root.hasArtwork && status !== Image.Error
            }

            // the application's own icon, centred on the card and covering the category glyph
            // underneath it. Sized as a fraction of the tile so that the shelf and the grid get
            // the same picture at the two sizes they draw, and kept inside the tile's clip so a
            // wide logo cannot escape its card
            Image {
                anchors.centerIn: parent
                width: Math.round(root.tileWidth * 0.54)
                height: width
                source: root.hasAppIcon ? root.entry.appicon : ""
                fillMode: Image.PreserveAspectFit
                asynchronous: true
                visible: root.hasAppIcon && status !== Image.Error
                smooth: true
                mipmap: true
            }

            // every entry shows a name, so an entry without artwork is a readable tile rather
            // than an empty rectangle
            Text {
                anchors.centerIn: parent
                anchors.margins: root.unit
                width: parent.width - root.unit * 2
                visible: !root.hasArtwork
                text: root.entry !== null && root.entry.name !== undefined ? root.entry.name : ""
                color: root.colorText
                font.pixelSize: Math.round(root.unit * 1.3)
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
                wrapMode: Text.WordWrap
            }

            // the unfocused tiles are shaded rather than made translucent, so that the background
            // does not show through them, and the shade is animated so that the eye follows the
            // focus along the row
            Rectangle {
                anchors.fill: parent
                radius: art.radius
                color: root.colorShade
                opacity: root.focused ? 0 : root.shadeOpacity

                Behavior on opacity {
                    NumberAnimation { duration: root.motionBase }
                }
            }
        }
    }

    // --- the name, under the artwork ----------------------------------------

    Text {
        id: label

        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: artArea.bottom
        // and the name starts clear of the ring rather than against it
        anchors.topMargin: root.unit * 1.0
        width: root.width - root.unit
        visible: root.showLabel
        text: root.entry !== null && root.entry.name !== undefined ? root.entry.name : ""
        color: root.focused ? root.colorText : root.colorDim
        font.pixelSize: Math.round(root.unit * 1.15)
        font.bold: root.focused
        horizontalAlignment: Text.AlignHCenter
        elide: Text.ElideRight
        maximumLineCount: 1

        Behavior on color {
            ColorAnimation { duration: root.motionFast }
        }
    }
}
