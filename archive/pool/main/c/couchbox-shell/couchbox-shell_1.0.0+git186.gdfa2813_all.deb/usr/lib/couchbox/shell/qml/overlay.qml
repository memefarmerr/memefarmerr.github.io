import QtQuick
import QtQuick.Window
import Couchbox 1.0

// the overlay when it is over a running application (ADR-0035).
//
// The dashboard's window is hidden while an application is in front. Raising it to draw the panel
// on it, which is what used to happen, replaced whatever the person was looking at with the
// dashboard: a screen change wearing the word overlay. This is a window of its own, the size of
// the panel and nothing else, sitting on top of the application, which stays exactly where it was.
//
// It is opaque on purpose. A full-screen transparent window would need a compositor to composite
// it, and on the machines this targets the compositor is the first thing that becomes a question.
// The application is visible around the panel because the panel is small, which asks nothing of
// anybody, and the application is stopped while this is up, so what surrounds the panel is a still
// picture rather than something moving underneath it.
//
// The window is exactly as tall as the panel, and the panel is compact because most of the rows
// it is handed now carry a title and nothing else. A window taller than its contents would be an
// opaque rectangle covering part of the application for no reason.
Window {
    id: panelWindow

    // the dashboard's own scale, taken from the screen it will be centred on, so that the panel
    // over a game is the same size as the panel over the shelf
    readonly property int unit: Math.max(10, Math.round(Shell.windowHeight / 72))
    readonly property int motionBase: 200

    flags: Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
    color: colors.surface

    width: Math.min(Shell.windowWidth - unit * 6, unit * 40)
    height: Math.min(panel.implicitHeight, Shell.windowHeight - unit * 2)

    // The height above depends on the rows, and the rows arrive a frame after the shell decides to
    // show this. So the window used to be mapped at one size and grow a moment later, and the
    // strip that growth exposed was never painted: what showed there was whatever the server had,
    // which is a light rectangle across the bottom of the panel. That is the white square.
    //
    // So the window is not shown until its height has stopped changing. A timer restarted by every
    // change to the height means the window is mapped once the layout has settled, at the size it
    // will keep, and the millisecond it costs is not something anybody can see. The height stays
    // content-sized rather than fixed, because a panel with room for rows it does not have is a
    // panel with an empty bottom third.
    property bool settled: false
    visible: Shell.overlayOverApplication && settled
    x: Math.round((Shell.windowWidth - width) / 2)
    y: Math.round((Shell.windowHeight - height) / 2)

    // the press that opened this is the press that means "I want out", so the first row that can
    // be chosen is where the selection starts. The window also has to be given the keyboard: a
    // window that is drawn but not activated receives no key events at all, and the keys
    // themselves are handled by the item inside, because a Window is not an Item and cannot hold
    // them
    // every change restarts it, so it fires only when nothing has changed for a millisecond
    onHeightChanged: settle.restart()

    Timer {
        id: settle

        interval: 1
        repeat: false
        onTriggered: panelWindow.settled = true
    }

    onVisibleChanged: {
        if (!visible) {
            settled = false
        }
        if (visible) {
            panel.selection = panel.firstSelectable();
            panelWindow.requestActivate();
            keyCatcher.forceActiveFocus();
            panelReveal.restart();
        }
    }

    // the panel settles in over a fifth of a second. Nothing here can fade the window itself, so
    // this is the whole of the animation over an application, and it is the difference between the
    // panel arriving and the panel being switched on
    NumberAnimation {
        id: panelReveal

        target: panel
        property: "revealAmount"
        from: 0
        to: 1
        duration: panelWindow.motionBase
        easing.type: Easing.OutCubic
    }

    ConsolePalette {
        id: colors
    }

    // The window's own colour is set above, and this is drawn on top of it anyway. That is belt
    // and braces on purpose: a frameless window whose surface is not painted where the scene graph
    // has not reached shows whatever the server had there, which is a light rectangle, and it
    // turns up at the bottom of the panel where the row count changed the window's height. Four
    // lines of rectangle is cheaper than a fault that shows up on somebody else's machine and not
    // on this one.
    Rectangle {
        anchors.fill: parent
        color: colors.surface
    }

    Item {
        id: keyCatcher

        anchors.fill: parent
        focus: true

        OverlayPanel {
            id: panel

            anchors.fill: parent
            unit: panelWindow.unit
            actions: Shell.overlayActions
            machineLine: Shell.networkOnline ? Shell.networkName : ""
            versionLine: Shell.osVersion
            clockLine: Shell.clock
        }

        // up and down rather than left and right, because this is a list and not a shelf
        Keys.onPressed: (event) => {
            switch (event.key) {
            case Qt.Key_Up:
                panel.move(-1);
                event.accepted = true;
                break;
            case Qt.Key_Down:
                panel.move(1);
                event.accepted = true;
                break;
            case Qt.Key_Return:
            case Qt.Key_Enter:
            case Qt.Key_Space:
                panel.activate(panel.selection);
                event.accepted = true;
                break;
            case Qt.Key_Escape:
            case Qt.Key_Back:
            case Qt.Key_Menu:
            case Qt.Key_Meta:
            case Qt.Key_Super_L:
            case Qt.Key_Super_R:
                // back, and the key that opened it. closing hands the application back
                // running, exactly where the person was before the panel appeared: the
                // key opens an overlay and never takes anybody anywhere (ADR-0042)
                Shell.closeOverlay();
                event.accepted = true;
                break;
            }
        }
    }
}
