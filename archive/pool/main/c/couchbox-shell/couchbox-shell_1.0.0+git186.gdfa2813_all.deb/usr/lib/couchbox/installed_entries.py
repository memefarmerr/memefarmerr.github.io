#!/usr/bin/env python3
"""the dashboard entries that installing an application creates.

The dashboard shows what is on the machine. An application that is not installed is therefore not
on the dashboard at all, which means an entry has to appear when the application arrives and go away
when it leaves. This is where that happens.

It writes into the user's own collection directory rather than into `/usr/share/couchbox/collections`,
which belongs to the image and to the packages that make it: a file there would be replaced by the
next image or package, and it would make installing an application a root-owned act rather than the
person's own. The directory is the third one `shell/entries.py` reads, and it is the documented
place for a person to arrange their own entries (ADR-0027).

The file is named after the collection the catalogue puts the application in, so installing Kodi and
installing Steam both write `media.collection` and `games.collection` respectively, and the
dashboard's rail does not grow a section per application.

Rewriting is deliberate rather than appending. A collection file is a person's, they may edit it,
and an upside-down or duplicated block is the kind of thing that only shows up on a television.
So the file is read, the one entry is replaced or added, and the result is written to a temporary
file and renamed over the old one, which is the only way to replace a file without a moment where
it does not exist.
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path

log = logging.getLogger("couchbox.installed_entries")

# where each collection sits in the dashboard's rail, for the header of a file this module
# creates. It is written here rather than read from anywhere because a collection file's `sort`
# is a property of the file: once it exists it belongs to the person, and rewriting their header
# to move a section would be this module editing a choice that is theirs. So this only decides
# what a *new* file gets, and it is what makes a machine where somebody installed Kodi land on
# Media rather than on a section called Other.
#
# Anything not named here gets LAST_SORT, which is where a person's own collection belongs: after
# everything the project has an opinion about and before the power actions.
COLLECTION_SORT = {
    "games": 10,
    "emulation": 20,
    "media": 30,
    "streaming": 40,
    "apps": 45,
    "tools": 46,
}
LAST_SORT = 60


def sort_for(collection: str) -> int:
    """the rail position a new collection file for this collection starts at."""
    return COLLECTION_SORT.get(collection.strip().lower(), LAST_SORT)


# the same directory the shell reads third, spelled here for the same reason the shell spells it:
# neither program can import the other's idea of where it is, and a wrong path is a collection the
# dashboard never sees
def directory() -> Path:
    """the same directory the shell reads, spelled the same way.

    `shell/entries.py` names this path as `Path.home()/.local/share/couchbox/collections` and does
    not consult XDG_DATA_HOME, so this must not either. Two programs disagreeing about where a file
    lives is a store that installs something the dashboard never shows, and it would only show up on
    a machine that sets the variable.
    """
    return Path.home() / ".local" / "share" / "couchbox" / "collections"


def file_for(collection: str) -> Path:
    """the collection file that holds this collection's entries.

    The name is not a decision, it is the collection's own name written in the one form a filename
    can take: the catalogue says which collection an application belongs in (ADR-0026) and this is
    what that means on disk.
    """
    slug = re.sub(r"[^a-z0-9]+", "-", collection.strip().lower()).strip("-")
    return directory() / f"{slug or 'other'}.collection"


def _blocks(text: str) -> list[str]:
    """split a collection file into its header and one string per entry.

    Deliberately tolerant: this edits a file a person may have written, so a line that does not
    parse is carried through rather than refused, and only the block being written or removed is
    touched.
    """
    lines = text.splitlines()
    header: list[str] = []
    blocks: list[str] = []
    current: list[str] | None = None

    for line in lines:
        if line.strip().lower().startswith("entry:"):
            if current is not None:
                blocks.append("\n".join(current))
            current = [line]
            continue
        if current is None:
            header.append(line)
        else:
            current.append(line)
    if current is not None:
        blocks.append("\n".join(current))
    return ["\n".join(header)] + blocks


def _name_of(block: str) -> str:
    for line in block.splitlines():
        stripped = line.strip()
        if stripped.lower().startswith("entry:"):
            return stripped.split(":", 1)[1].strip()
    return ""


def _render(parts: list[str]) -> str:
    text = "\n".join(part.rstrip() for part in parts if part.strip())
    return text.rstrip() + "\n"


def write(collection: str, name: str, launcher: str, description: str, catalogue_id: str) -> Path:
    """add this entry, or replace it if it is already there."""
    path = file_for(collection)
    path.parent.mkdir(parents=True, exist_ok=True)

    parts = _blocks(path.read_text(encoding="utf-8")) if path.exists() else []
    header = parts[0] if parts else ""
    if not header.strip():
        # a new file needs a header, and so does one a person has stripped the header from. The
        # entries already in it are kept either way: this is their file, and taking a header as an
        # excuse to discard what it contained would be the worst bug this module could have
        header = (
            "# written by the store. this file is yours: edit it, or delete it.\n"
            f"collection: {collection}\nsort: {sort_for(collection)}"
        )
    parts = [header, *parts[1:]]

    entry = "\n".join(
        [
            f"entry: {name}",
            f"launcher: {launcher}",
            f"description: {description}",
            f"catalogue: {catalogue_id}",
        ]
    )
    wanted = _name_of(entry)

    for index, block in enumerate(parts[1:], start=1):
        if _name_of(block) == wanted:
            parts[index] = entry
            break
    else:
        parts.append(entry)

    _replace(path, _render(parts))
    log.info("wrote %s into %s", wanted, path)
    return path


def remove(collection: str, name: str) -> Path | None:
    """take this entry out, and the file with it if it was the last one."""
    path = file_for(collection)
    if not path.exists():
        return None

    parts = _blocks(path.read_text(encoding="utf-8"))
    kept = [part for part in parts[1:] if _name_of(part) != name]

    if not kept:
        # nothing left, so the file goes. An empty collection is not shown by the dashboard, but a
        # file that exists and says nothing is still something a person has to read later to find
        # out why
        path.unlink()
        log.info("removed %s and deleted %s", name, path)
        return None

    _replace(path, _render([parts[0]] + kept))
    log.info("removed %s from %s", name, path)
    return path


def _replace(path: Path, text: str) -> None:
    temporary = path.with_name(path.name + ".new")
    temporary.write_text(text, encoding="utf-8")
    os.replace(temporary, path)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(prog="installed_entries", description=__doc__.splitlines()[0])
    parser.add_argument("--list", action="store_true", help="show where entries are written")
    arguments = parser.parse_args()
    if arguments.list:
        print(directory())
        for file in sorted(directory().glob("*.collection")) if directory().is_dir() else []:
            print(f"  {file.name}")
