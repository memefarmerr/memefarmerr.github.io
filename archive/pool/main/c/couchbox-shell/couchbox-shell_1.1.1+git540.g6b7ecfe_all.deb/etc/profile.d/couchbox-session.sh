# start the Couchbox session on the first virtual console.
#
# this is sourced by every login shell, so it has to be cheap, and it has to stay
# out of the way everywhere else. a session only starts on /dev/tty1, only when
# no display is already in use, and only once per login.
#
# why a login shell hook rather than a display manager: Couchbox OS has neither a
# display manager nor a desktop environment, and the console login is what gives
# the session a real systemd login session for PipeWire to attach to.
#
# this relies on the login shell reading /etc/profile, which bash does. see
# docs/architecture.md for the session flow.

# every decision this script makes goes to the journal. the failure it is most
# likely to have is "the session never started", and on a black screen that is
# impossible to tell apart from "the session started and the dashboard failed".
# read it back with: journalctl -b -t couchbox-session
# Both destinations, and the console is not a belt-and-braces addition.
#
# `logger` needs the journal socket to be up, and a login shell runs early enough that it may
# not be. That is not hypothetical: the diagnostic line added below to prove this script was
# being run at all used `logger` and never appeared, while the session program's own lines,
# written a second later through the same function, arrived. A diagnostic that can fail
# silently is the same fault it was written to find, so this writes to the console as well,
# which needs nothing to be ready.
couchbox_log() {
	logger -t couchbox-session "$*" 2>/dev/null || true
	printf 'couchbox-session: %s\n' "$*" >/dev/console 2>/dev/null || true
}

# And the first thing it does is say what it was given, before it decides anything.
#
# The failure this script is most likely to have is "the session never started", and the two
# ways that happens are silent: `tty` answering something other than /dev/tty1, or DISPLAY
# being set by something else, and in both cases every test below is skipped without a word.
# That is exactly what a boot did after the autologin was moved into the image: the getty
# logged the person in and restarted every sixty seconds, and this file appears nowhere in the
# journal, so it either did not run or did not reach the line that says it started. Two builds
# went on guessing which. This line answers it either way, and it is worth keeping for the same
# reason the rest of this file logs: a black screen says nothing about why it is black.
couchbox_log "a login shell started: tty=$(tty 2>/dev/null || echo none) DISPLAY=${DISPLAY:-unset} started=${COUCHBOX_SESSION_STARTED:-unset}"

case "$(tty 2>/dev/null)" in
	/dev/tty1)
		if [ -z "${DISPLAY:-}" ] && [ -z "${COUCHBOX_SESSION_STARTED:-}" ]; then
			COUCHBOX_SESSION_STARTED=1
			export COUCHBOX_SESSION_STARTED

			couchbox_log "tty1 login with no display in use: starting the session"

			# deliberately not exec: when the session ends, the user lands at a
			# normal shell prompt on this console, and that prompt is the
			# recovery path
			/usr/lib/couchbox/couchbox-session || true

			couchbox_log "the session returned, so this console is the way back in"
		else
			couchbox_log "tty1 login but not starting: DISPLAY=${DISPLAY:-unset} COUCHBOX_SESSION_STARTED=${COUCHBOX_SESSION_STARTED:-unset}"
		fi
		;;
	*)
		couchbox_log "login on $(tty 2>/dev/null || echo 'an unknown terminal'), which is not tty1, so no session was started"
		;;
esac
