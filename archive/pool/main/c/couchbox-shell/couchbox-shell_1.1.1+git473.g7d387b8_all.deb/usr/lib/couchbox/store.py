"""what the store's applications need to know about the machine.

The catalogue says what *could* be installed; this says what is on the machine, and it is the half
of the store that runs as a person rather than as root. Nothing here changes anything: installing is
the helper's job (ADR-0026), and this is what the interface asks before it draws a row.

It lives beside `catalog.py` rather than inside the dashboard, because three programs ask it the same
question: the store application, the store command line, and the dashboard itself, which uses it to
decide whether an entry's application is on the machine at all.

Two questions, and both of them are asked of the system rather than remembered:

  * is the application behind this entry installed, which is `dpkg-query` for a Debian package
    and `flatpak list` for a Flathub application
  * which entries are in the catalogue at all, which is `catalog.load`, the same module the
    installer and the helper read

It also owns the two names the install engine and its frontends share (ADR-0033): the unix
socket the engine listens on, and the state file it writes. They are defined once, here, because
every one of those programs already imports this module, and a name defined in one place cannot
drift.

The state file is the engine's snapshot, and its shape is part of this module's contract:

    {"engine": "running", "updated": <seconds>, "items": [
        {"id": "kodi", "name": "Kodi", "verb": "install",
         "state": "queued|working|done|failed|cancelled",
         "phase": "Downloading", "percent": 42.5 or null, "text": "...",
         "message": "", "queued_at": <seconds>, "finished_at": <seconds or 0>,
         "restart": "<the Couchbox package version this job brought in, or empty>"}]}

Nothing here starts the engine or speaks to its socket beyond `engine_command`; deciding what to
install is the engine's business and the interface only relays what a person pressed (ADR-0033).
"""

from __future__ import annotations

import json
import logging
import os
import socket
import re
import subprocess
import tempfile
import time
from pathlib import Path

import catalog

log = logging.getLogger("couchbox.store")

# how long a tool on this machine is given to answer a question about this machine. dpkg-query and
# flatpak list are both fast, and neither is worth blocking an interface for: the store and the
# settings read this on a background thread and draw what they have.
TOOL_TIMEOUT = 10

DPKG_QUERY = "/usr/bin/dpkg-query"
FLATPAK = "/usr/bin/flatpak"

# the two names the engine and everything that reads it share. The runtime directory is read when
# a path is asked for, not when this module is imported, so a test can move it with an environment
# variable and the engine can be exercised without touching a real session.
SOCKET_NAME = "couchbox-store.sock"
# the one job that is the machine's rather than the person's. The shell needs to know it is
# this one, because an update of Couchbox itself takes the whole screen and an application
# somebody asked for gets a strip along the bottom. It lives here rather than in the engine
# because the engine is a program and the shell cannot import a program (ADR-0033).
SYSTEM_UPDATE_VERB = "system-update"
SYSTEM_UPDATE_ID = "system-update"
SYSTEM_UPDATE_NAME = "System update"

STATE_NAME = "state.json"
ENGINE_PROGRAM = "/usr/lib/couchbox/store-engine"


def runtime_directory() -> Path:
    """where the engine's socket and state live: the session's runtime directory, never /tmp
    unless there is no session, which only happens in a test or a rescue shell."""
    return Path(os.environ.get("XDG_RUNTIME_DIR") or tempfile.gettempdir()) / "couchbox-store"


def socket_path() -> Path:
    return runtime_directory() / SOCKET_NAME


def state_path() -> Path:
    return runtime_directory() / STATE_NAME


def read_state() -> dict:
    """the engine's snapshot, or an empty dictionary when there is not one.

    Tolerant by design: this is read by the dashboard on a timer, and a state file that is being
    replaced as it is read, or that a crashed engine left half written, must never produce a
traceback in a shell drawing a television.
    """
    try:
        text = state_path().read_text(encoding="utf-8")
        parsed = json.loads(text)
        return parsed if isinstance(parsed, dict) else {}
    except FileNotFoundError:
        return {}
    except (OSError, ValueError) as error:
        log.info("could not read the engine's state: %s", error)
        return {}


def engine_running() -> bool:
    """is something listening on the engine's socket, without disturbing it."""
    path = socket_path()
    if not path.exists():
        return False
    try:
        probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        probe.settimeout(1.0)
        probe.connect(str(path))
        probe.close()
        return True
    except OSError:
        return False


def engine_command(command: dict, timeout: float = 5.0) -> dict:
    """one request to the engine, one reply, or a dictionary explaining why there is none."""
    try:
        client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        client.settimeout(timeout)
        client.connect(str(socket_path()))
        client.sendall((json.dumps(command) + "\n").encode("utf-8"))
        data = b""
        while not data.endswith(b"\n"):
            chunk = client.recv(4096)
            if not chunk:
                break
            data += chunk
        client.close()
        reply = json.loads(data.decode("utf-8").strip() or "{}")
        return reply if isinstance(reply, dict) else {"ok": False, "message": "the engine answered nothing"}
    except (OSError, ValueError) as error:
        return {"ok": False, "message": str(error)}


def start_engine() -> bool:
    """start the engine if it is not running, and say whether one is there afterwards.

    Started detached (its own session) deliberately: the window that asked for an install can be
    closed a second later, and the whole point of the engine is that the install does not care
    (ADR-0033). Its output goes to a log beside the state file, because there is no terminal for
    a background process to write to.
    """
    if engine_running():
        return True
    directory = runtime_directory()
    try:
        directory.mkdir(parents=True, exist_ok=True)
        log_file = (directory / "engine.log").open("ab")
    except OSError as error:
        log.warning("could not prepare the engine's directory (%s)", error)
        return False
    try:
        subprocess.Popen(
            [ENGINE_PROGRAM],
            stdin=subprocess.DEVNULL,
            stdout=log_file,
            stderr=log_file,
            start_new_session=True,
            close_fds=True,
        )
    except OSError as error:
        log.warning("could not start the install engine (%s)", error)
        return False
    finally:
        log_file.close()

    # give it a moment to bind; a wait that ends in "no" is still a truthful answer
    for _ in range(20):
        if engine_running():
            return True
        time.sleep(0.1)
    return False


# what dpkg says about a package that is properly installed, and the only line worth matching. A
# package that was removed but not purged reports "deinstall ok config-files", and a package that
# failed half way says something else again: neither is installed, and both would be a lie to offer
# as such
INSTALLED_STATUS = "install ok installed"

# how long the flatpak answer is kept. Asking flatpak is a subprocess, and the dashboard asks this
# of every entry on every reload, which is a burst of identical questions. Two seconds answers the
# burst without making the answer stale: an install that finishes is noticed on the next reload,
# which is the reload the store triggers itself
FLATPAK_CACHE_SECONDS = 2.0

_flatpak_cache: tuple[float, frozenset[str]] | None = None


def flatpak_apps() -> frozenset[str]:
    """the flatpak applications installed for this user or for the machine.

    A flatpak can be installed system-wide or per user, and the person running the store is the
    one who needs to see it, so the plain `flatpak list` is asked rather than `--system`: it
    reports both, which is the question the interface is actually asking ("would pressing start
    work for me").

    A machine without flatpak, which is every machine until the store installs one from the
    catalogue, answers with an empty set rather than an error: the entries that need it show as
    not installed, which is true.
    """
    global _flatpak_cache
    now = time.monotonic()
    if _flatpak_cache is not None and now - _flatpak_cache[0] < FLATPAK_CACHE_SECONDS:
        return _flatpak_cache[1]

    apps: frozenset[str] = frozenset()
    try:
        result = subprocess.run(
            [FLATPAK, "list", "--app", "--columns=application"],
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
        if result.returncode == 0:
            # flatpak prints a column heading when it is talking to a terminal and prints nothing
            # but the values when it is not, so every non-empty line is read. A heading, when it
            # is there, is a line that can never equal an application id, which is the only thing
            # this set is asked about
            apps = frozenset(
                line.strip() for line in result.stdout.splitlines() if line.strip()
            )
        else:
            log.info("flatpak list answered with code %d: %s", result.returncode, result.stderr.strip())
    except (OSError, subprocess.TimeoutExpired) as error:
        log.info("could not ask flatpak what is installed: %s", error)

    _flatpak_cache = (now, apps)
    return apps


def installed(entry: catalog.CatalogEntry) -> bool:
    """is the application behind this entry on the machine."""
    if entry.flatpak:
        return entry.flatpak in flatpak_apps()
    if not entry.apt:
        # the catalogue refuses an entry with no source at all, so this is unreachable from a
        # valid file. Answering "no" is still better than a traceback in a log on every redraw
        return False
    try:
        result = subprocess.run(
            [DPKG_QUERY, "-W", "-f=${Status}", entry.apt],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as error:
        # a machine without dpkg-query is not a machine this can answer for, and saying "not
        # installed" is better than a traceback in a log on every redraw
        log.warning("could not ask dpkg about %s (%s)", entry.apt, error)
        return False
    return result.returncode == 0 and INSTALLED_STATUS in result.stdout


def installed_ids() -> set[str]:
    """the catalogue ids whose application is on this machine, asked once.

    The dashboard wants exactly this set on every reload, and asking entry by entry would run
    `flatpak list` once per flatpak entry. Both questions are asked at most once here, so the
    cost of a reload does not grow with the catalogue.
    """
    entries = catalog.load()
    apps: frozenset[str] | None = None
    found: set[str] = set()
    for entry in entries:
        if entry.flatpak:
            if apps is None:
                apps = flatpak_apps()
            if entry.flatpak in apps:
                found.add(entry.id)
        elif entry.apt and installed(entry):
            found.add(entry.id)
    return found


# A size a tool printed for a person, like "462.4 MB" or "18.6 MB". Both dpkg and flatpak are asked
# for sizes in the units they like to print them in, because neither offers a machine-readable count:
# dpkg's Installed-Size is kibibytes with nothing saying so, and flatpak has a column of text.
_SIZE = re.compile(r"([0-9]+(?:\.[0-9]+)?)\s*([kKmMgGtT]?i?[bB])\Z")

_SIZE_FACTORS = {
    "b": 1,
    "kb": 1000,
    "kib": 1024,
    "mb": 1000**2,
    "mib": 1024**2,
    "gb": 1000**3,
    "gib": 1024**3,
    "tb": 1000**4,
    "tib": 1024**4,
}


def parse_size(text: str) -> int | None:
    """bytes from a size a tool printed, or None if it is not one."""
    match = _SIZE.match(text.strip())
    if match is None:
        return None
    factor = _SIZE_FACTORS.get(match.group(2).lower())
    if factor is None:
        return None
    return int(float(match.group(1)) * factor)


def apt_sizes() -> dict[str, int]:
    """bytes per installed package, keyed by package name, in one call to dpkg.

    `Installed-Size` is in kibibytes. Nothing in dpkg's output says so, and the first version of this
    read it as bytes and reported a two gigabyte game as two megabytes.
    """
    try:
        result = subprocess.run(
            [DPKG_QUERY, "-W", "-f=${Package}\t${Installed-Size}\n"],
            capture_output=True,
            text=True,
            timeout=TOOL_TIMEOUT,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return {}
    if result.returncode != 0:
        return {}
    sizes: dict[str, int] = {}
    for line in result.stdout.splitlines():
        name, _, kibibytes = line.partition("\t")
        name = name.strip()
        kibibytes = kibibytes.strip()
        if name and kibibytes.isdigit():
            sizes[name] = int(kibibytes) * 1024
    return sizes


def flatpak_sizes() -> dict[str, int]:
    """bytes per installed flatpak application, keyed by application id.

    The largest of the rows a name appears in, because flatpak lists one row per branch and one
    application can have more than one installed.
    """
    try:
        result = subprocess.run(
            [FLATPAK, "list", "--app", "--columns=application,size"],
            capture_output=True,
            text=True,
            timeout=TOOL_TIMEOUT,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return {}
    if result.returncode != 0:
        return {}
    sizes: dict[str, int] = {}
    for line in result.stdout.splitlines():
        name, _, printed = line.partition("\t")
        name = name.strip()
        counted = parse_size(printed)
        if name and counted is not None and counted > sizes.get(name, 0):
            sizes[name] = counted
    return sizes


def installed_sizes() -> dict[str, int]:
    """bytes per installed catalogue entry, keyed by catalogue id.

    Only what came from the catalogue, which is the question the interface is asking: the system's own
    packages are not in it and cannot be reported as if they were. Nothing installed is a valid answer
    and an empty dictionary is what it looks like.
    """
    from_apt = apt_sizes()
    from_flatpak = flatpak_sizes()
    sizes: dict[str, int] = {}
    try:
        entries = catalog.load()
    except catalog.CatalogError:
        return {}
    for entry in entries:
        if not installed(entry):
            continue
        if entry.flatpak:
            counted = from_flatpak.get(entry.source_name)
        else:
            counted = from_apt.get(entry.source_name)
        if counted:
            sizes[entry.id] = counted
    return sizes


def listing() -> list[dict]:
    """the catalogue, each entry with whether it is installed.

    Returns what an interface draws, and raises CatalogError rather than returning a short list: a
    catalogue that half loads would put a store on screen that is quietly missing something.
    """
    return [
        {**entry.as_dict(), "installed": installed(entry)}
        for entry in catalog.load()
    ]
