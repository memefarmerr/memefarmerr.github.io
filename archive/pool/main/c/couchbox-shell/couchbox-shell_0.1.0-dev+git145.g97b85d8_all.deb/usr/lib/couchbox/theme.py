"""the look the Couchbox applications share.

The store and the settings are separate programs (ADR-0030) drawn by the same toolkit, and a
person moves between them and the dashboard without a transition to tell them the surface
changed. So the palette, the shapes and the focus treatment live here once, and an application
that wants a new kind of control adds it here rather than inventing a second look.

The design rules, and both of them come from the couch:

  * one dark surface, one accent, and a focus treatment loud enough to read from three metres.
    The focused control is the only bright-edged thing on the screen, so "where am I" is answered
    without reading anything.
  * nothing is operated by a keyboard shortcut that is not written down (ADR-0034). Controls are
    buttons and rows, and every one of them works with the D-pad, the Tab and arrow keys, the
    mouse, and Enter or Space. The styling says what is clickable by making it look clickable.

Importing this module does not import a toolkit; the functions that build widgets do their
imports inside themselves, so a program can use the colour constants without Qt.
"""

from __future__ import annotations

BACKGROUND = "#101014"
SURFACE = "#1b1b22"
SURFACE_FOCUSED = "#2b2b39"
BORDER = "#34343f"
TEXT = "#f4f4f7"
DIM = "#9a9aa8"
ACCENT = "#e0a13c"

# how far apart things sit, in the one scale every screen uses
GAP = 12
MARGIN = 40
RADIUS = 6


def font(size: int, bold: bool = False):
    """the application font, at a point size, in the family the whole project draws with.

    The family is copied from the running application's own font, which is the font the dashboard's
    text is drawn with, so the three programs cannot drift apart. Do not build a QFont with an empty
    family instead: on the installed system an empty family resolves to Bitstream Charter, a serif,
    while the application font resolves to DejaVu Sans. The store and the settings used to be drawn
    in a different face from the rest of the system for exactly that reason. This is measured, not
    guessed: run the font probe in the built image's chroot before changing the line below.

    What this also prevents is an application picking a *second* face of its own: the volume readout
    and the About values used to be monospace, which read as a screen from a different program.
    """
    from PySide6.QtGui import QFont, QGuiApplication

    result = QFont(QGuiApplication.font())
    result.setPointSize(size)
    if bold:
        result.setWeight(QFont.Weight.Bold)
    return result


def palette():
    """the application palette. Everything that is not set here is deliberately default."""
    from PySide6.QtGui import QColor, QPalette

    result = QPalette()
    result.setColor(QPalette.ColorRole.Window, QColor(BACKGROUND))
    result.setColor(QPalette.ColorRole.Base, QColor(SURFACE))
    result.setColor(QPalette.ColorRole.AlternateBase, QColor(BACKGROUND))
    result.setColor(QPalette.ColorRole.Text, QColor(TEXT))
    result.setColor(QPalette.ColorRole.WindowText, QColor(TEXT))
    result.setColor(QPalette.ColorRole.ButtonText, QColor(TEXT))
    result.setColor(QPalette.ColorRole.Button, QColor(SURFACE))
    result.setColor(QPalette.ColorRole.Highlight, QColor(ACCENT))
    result.setColor(QPalette.ColorRole.HighlightedText, QColor(BACKGROUND))
    result.setColor(QPalette.ColorRole.PlaceholderText, QColor(DIM))
    return result


def stylesheet() -> str:
    """the application stylesheet. Buttons and rows are the two things it mostly describes."""
    return f"""
        QWidget {{
            background: {BACKGROUND};
            color: {TEXT};
        }}
        QLabel {{
            background: transparent;
        }}
        QPushButton {{
            background: {SURFACE};
            color: {TEXT};
            border: 1px solid {BORDER};
            border-radius: {RADIUS}px;
            padding: 10px 18px;
        }}
        QPushButton:hover {{
            background: {SURFACE_FOCUSED};
        }}
        QPushButton:focus {{
            background: {SURFACE_FOCUSED};
            border: 2px solid {ACCENT};
        }}
        QPushButton:disabled {{
            color: {DIM};
            border-color: {BORDER};
        }}
        QListWidget {{
            background: transparent;
            border: none;
            outline: none;
        }}
        QListWidget::item {{
            padding: 14px 12px;
            border-left: 4px solid transparent;
            border-radius: 2px;
        }}
        QListWidget::item:selected {{
            background: {SURFACE_FOCUSED};
            border-left: 4px solid {ACCENT};
            color: {TEXT};
        }}
        QProgressBar {{
            background: {SURFACE};
            border: 1px solid {BORDER};
            border-radius: {RADIUS}px;
            text-align: center;
            color: {TEXT};
        }}
        QProgressBar::chunk {{
            background: {ACCENT};
            border-radius: 5px;
        }}
        QSlider::groove:horizontal {{
            height: 12px;
            background: {SURFACE};
            border: 1px solid {BORDER};
            border-radius: 6px;
        }}
        QSlider::sub-page:horizontal {{
            background: {ACCENT};
            border-radius: 6px;
        }}
        QSlider::handle:horizontal {{
            width: 26px;
            margin: -8px 0;
            background: {TEXT};
            border-radius: 13px;
        }}
        QScrollBar:vertical {{
            background: transparent;
            width: 10px;
            margin: 0;
        }}
        QScrollBar::handle:vertical {{
            background: {BORDER};
            border-radius: 5px;
            min-height: 30px;
        }}
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
            height: 0;
        }}
    """


def title(text: str):
    """the name of the screen, top left, as big as the dashboard's headings are."""
    from PySide6.QtWidgets import QLabel

    label = QLabel(text)
    label.setFont(font(30, bold=True))
    return label


def heading(text: str):
    """the name of a region inside a screen: a list, a detail pane, a queue."""
    from PySide6.QtWidgets import QLabel

    label = QLabel(text)
    label.setFont(font(18, bold=True))
    return label


def dim(text: str, size: int = 14):
    """a line that explains rather than names, so it is quieter than everything else."""
    from PySide6.QtWidgets import QLabel

    label = QLabel(text)
    label.setFont(font(size))
    label.setStyleSheet(f"color: {DIM};")
    label.setWordWrap(True)
    return label


def hint(text: str, size: int = 13):
    """the strip at the bottom: which button does what. Always about focus, never a shortcut."""
    from PySide6.QtWidgets import QLabel

    label = QLabel(text)
    label.setFont(font(size))
    label.setStyleSheet(f"color: {DIM};")
    label.setWordWrap(True)
    return label
