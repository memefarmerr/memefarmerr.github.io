import QtQuick

// the colours of the console, in one place.
//
// The dashboard and the overlay window are separate windows and both draw with these, and the
// overlay is now drawn in two of them: over the dashboard itself, and over a running application
// (ADR-0035). Three copies of a palette is three chances for the panel over a game to come out a
// slightly different colour from the panel over the shelf, which is exactly the kind of thing
// nobody reports and everybody sees.
//
// It is instantiated rather than used as a singleton: `ConsolePalette { id: colors }`, once per
// window. A singleton needed a qmldir and a pragma and still resolved to nothing in the offscreen
// check, and a component that is constructed where it is used has no such step to get wrong.
//
// The name is deliberate: `Palette` is a value type Qt Quick itself provides, so a file called
// Palette.qml is shadowed by it, and the symptoms are memorable and quiet: every colour in the
// interface resolves to a Qt default instead, which draws a dashboard that is black except for
// blue outlines. Measured, after wondering why the palette "worked" and nothing else did.
QtObject {
    readonly property color backgroundTop: "#191922"
    readonly property color background: "#08080b"
    readonly property color surface: "#20202a"
    readonly property color surfaceFocused: "#2b2b39"
    readonly property color border: "#34343f"
    readonly property color text: "#f4f4f7"
    readonly property color dim: "#9a9aa8"
    readonly property color accent: "#e0a13c"
    // the shade the dashboard dims itself with when the overlay is open over it. The overlay over
    // an application has no dim: what it is covering is the thing the person wants to see
    readonly property color shade: "#000000"
}
