"""the catalogue of what Couchbox OS can install.

One list, read at three moments: what the installer offers, what first-boot setup installs, and
what the store shows a year later. Three lists of the same thing would drift, and the drift would
be invisible until somebody who installed an application one way could not find it the other.
ADR-0026 is the decision; this is the file it is about.

This module lives one directory above the shell rather than inside it, because the privileged
helper that does the installing has to read the same file and is not part of the dashboard. The
shell reaches it by adding its parent to the import path, which is one line and worth it: two
copies of a parser is two ways for the two ends to disagree about what a catalogue says.

The shape is deliberately the same as a collection's, and the rules are the same, including the
one that matters most: an unknown key is an error. A misspelled key that silently does nothing
leaves a file that looks correct and behaves differently, and this file is written by a person.

What is *not* here is any decision about how a package is installed. This module reads what the
catalogue says and refuses anything it does not understand; turning an entry into an apt or
flatpak invocation, and doing it as root, is the engine's job and not the parser's.
"""

from __future__ import annotations

import dataclasses
import logging
import os
from pathlib import Path

log = logging.getLogger("couchbox.catalog")

CATALOG_SUFFIX = ".catalog"

# where catalogues are read from, in this order, so that a user's own additions are seen after
# the image's. overridable so that a checkout can be tested without installing anything.
def _dirs_from_env(variable: str, default: tuple[str, ...]) -> tuple[str, ...]:
    raw = os.environ.get(variable)
    if not raw:
        return default
    return tuple(part for part in raw.split(os.pathsep) if part)


CATALOG_DIRS = _dirs_from_env(
    "COUCHBOX_CATALOG_DIRS",
    (
        "/usr/share/couchbox/catalog",
        "/usr/local/share/couchbox/catalog",
        str(Path.home() / ".local/share/couchbox/catalog"),
    ),
)

# the sources, in the project's order of preference: a Debian package, then flatpak where Debian
# has nothing, then a download from upstream where neither exists. The last is not implemented,
# so an entry cannot claim it yet, which is deliberate: a source this project cannot install is
# a promise it should not make in a file.
SOURCE_APT = "apt"
SOURCE_FLATPAK = "flatpak"
SOURCE_KEYS = (SOURCE_APT, SOURCE_FLATPAK)

ENTRY_KEYS = frozenset(
    {
        "entry",
        "name",
        "description",
        "apt",
        "flatpak",
        "collection",
        "launcher",
        "multiarch",
    }
)
REQUIRED_KEYS = ("name", "description", "collection", "launcher")


class CatalogError(Exception):
    """a catalogue file that cannot be trusted.

    Raised rather than worked around, for the reason collections raise: a catalogue that half
    loads is worse than one that refuses, because the store then shows a list that is quietly
    missing something and the person looking at it has no reason to suspect the file.
    """

    def __init__(self, path: Path, line_number: int, message: str):
        self.path = path
        self.line_number = line_number
        self.message = message
        super().__init__(f"{path}:{line_number}: {message}")


@dataclasses.dataclass(frozen=True, slots=True)
class CatalogEntry:
    """one thing that can be installed.

    `id` is what the interface passes and what the helper looks up, so nothing about how the
    installation happens travels from the interface to the machine that performs it.
    """

    id: str
    name: str
    description: str
    collection: str
    launcher: str
    apt: str = ""
    flatpak: str = ""
    multiarch: tuple[str, ...] = ()

    @property
    def source(self) -> str:
        """which of the two sources this entry uses."""
        if self.apt:
            return SOURCE_APT
        if self.flatpak:
            return SOURCE_FLATPAK
        return ""

    @property
    def source_name(self) -> str:
        """the package or application name, whichever the source uses."""
        return self.apt or self.flatpak

    def as_dict(self) -> dict:
        """what the interface reads. The source name is included because the store shows it,
        and it is not what the store passes back: that is the id."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "collection": self.collection,
            "launcher": self.launcher,
            "source": self.source,
            "sourceName": self.source_name,
            "multiarch": list(self.multiarch),
        }


def _split(line: str) -> tuple[str, str] | None:
    """split a `key: value` line, or return None for a line to ignore."""
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return None
    if ":" not in stripped:
        return "", ""
    key, _, value = stripped.partition(":")
    return key.strip().lower(), value.strip()


def parse(path: Path, text: str) -> list[CatalogEntry]:
    """parse one catalogue file, or raise CatalogError explaining why not."""
    entries: list[CatalogEntry] = []
    current: dict[str, str] | None = None

    def finish(where: int) -> None:
        if current is None:
            return
        entry_id = current.get("entry", "")
        if not entry_id:
            raise CatalogError(path, where, "an entry needs an id")
        if not entry_id.islower() or " " in entry_id:
            raise CatalogError(
                path,
                where,
                f"the id '{entry_id}' must be lowercase with no spaces, because it is passed "
                "around and compared rather than read",
            )
        for key in REQUIRED_KEYS:
            if not current.get(key):
                raise CatalogError(path, where, f"entry '{entry_id}' has no '{key}'")
        sources = [key for key in SOURCE_KEYS if current.get(key)]
        if len(sources) != 1:
            raise CatalogError(
                path,
                where,
                f"entry '{entry_id}' needs exactly one of "
                f"{' or '.join(SOURCE_KEYS)}, and has {len(sources)}",
            )
        multiarch = tuple(
            part.strip() for part in current.get("multiarch", "").split(",") if part.strip()
        )
        entries.append(
            CatalogEntry(
                id=entry_id,
                name=current["name"],
                description=current["description"],
                collection=current["collection"],
                launcher=current["launcher"],
                apt=current.get("apt", ""),
                flatpak=current.get("flatpak", ""),
                multiarch=multiarch,
            )
        )

    for number, line in enumerate(text.splitlines(), start=1):
        pair = _split(line)
        if pair is None:
            continue
        key, value = pair
        if key == "":
            raise CatalogError(path, number, "expected 'key: value', found neither")
        if key not in ENTRY_KEYS:
            raise CatalogError(path, number, f"unknown key '{key}'")
        if key == "entry":
            finish(number)
            current = {"entry": value}
            if not value:
                raise CatalogError(path, number, "an entry needs an id")
            continue
        if current is None:
            raise CatalogError(path, number, f"'{key}' came before any 'entry'")
        if key in current:
            raise CatalogError(path, number, f"'{key}' is set twice in this entry")
        current[key] = value

    finish(len(text.splitlines()))
    return entries


def load(directory: Path | None = None) -> list[CatalogEntry]:
    """read every catalogue file, or raise CatalogError on the first one that is wrong."""
    folders = [directory] if directory is not None else [Path(d) for d in CATALOG_DIRS]
    entries: list[CatalogEntry] = []
    seen: set[str] = set()

    for folder in folders:
        if not folder.is_dir():
            continue
        for path in sorted(folder.glob(f"*{CATALOG_SUFFIX}")):
            try:
                text = path.read_text(encoding="utf-8")
            except OSError as error:
                log.warning("could not read %s (%s)", path, error)
                continue
            for entry in parse(path, text):
                if entry.id in seen:
                    # two files claiming the same id is a packaging mistake, and the second one
                    # would silently win, which is the kind of thing found much later
                    raise CatalogError(path, 1, f"the id '{entry.id}' is already defined earlier")
                seen.add(entry.id)
                entries.append(entry)
    return entries


def main(argv: list[str] | None = None) -> int:
    """the entry point a check or a person uses.

    It exists so that the file that decides what the catalogue means is also the only thing that
    says whether one is valid. A check that parsed the file separately would be a second parser,
    and a second parser disagrees with the first one eventually, in the direction that matters:
    saying a file is fine when the thing that reads it refuses.
    """
    import argparse

    parser = argparse.ArgumentParser(
        prog="catalog",
        description="read the catalogue of what Couchbox OS can install",
    )
    parser.add_argument(
        "directory",
        nargs="?",
        help="read one directory instead of the configured ones",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="say nothing when it is valid, and explain when it is not",
    )
    parser.add_argument(
        "--list-launchers",
        action="store_true",
        help="print one 'id launcher' pair per entry, for a caller that needs to check them",
    )
    parser.add_argument(
        "--list-packages",
        action="store_true",
        help=(
            "print one 'id package' pair per entry that comes from apt, so that a build can ask "
            "an archive whether the names are real"
        ),
    )
    parser.add_argument(
        "--list-flatpaks",
        action="store_true",
        help=(
            "print one 'id application' pair per entry that comes from flatpak, so that a build "
            "can check that the image carries the flatpak command those entries need"
        ),
    )
    arguments = parser.parse_args(argv)

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    try:
        entries = load(Path(arguments.directory) if arguments.directory else None)
    except CatalogError as error:
        print(error, file=sys.stderr)
        return 1

    if arguments.list_launchers:
        for entry in entries:
            print(f"{entry.id}\t{entry.launcher}")
        return 0

    if arguments.list_packages:
        for entry in entries:
            if entry.apt:
                print(f"{entry.id}\t{entry.apt}")
        return 0

    if arguments.list_flatpaks:
        for entry in entries:
            if entry.flatpak:
                print(f"{entry.id}\t{entry.flatpak}")
        return 0

    if arguments.check:
        if not entries:
            print("the catalogue is empty, so there is nothing anybody could install", file=sys.stderr)
            return 1
        counts: dict[str, int] = {}
        for entry in entries:
            counts[entry.source] = counts.get(entry.source, 0) + 1
        summary = ", ".join(f"{count} from {source}" for source, count in sorted(counts.items()))
        print(f"{len(entries)} entr{'y' if len(entries) == 1 else 'ies'}: {summary}")
        return 0

    for entry in entries:
        print(f"{entry.id}: {entry.name} ({entry.source} {entry.source_name})")
    return 0


if __name__ == "__main__":
    import sys

    raise SystemExit(main())
