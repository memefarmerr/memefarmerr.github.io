import QtQuick
import Couchbox 1.0

// the overlay's list, drawn once and worn by both places it appears: the dashboard, when the
// overlay opens over the dashboard, and a small window of its own, when it opens over a running
// application (ADR-0035).
//
// The rows come from the shell (`Shell.overlayActions`) and choosing one goes back to the shell
// (`Shell.overlayActivate`), so the two hosts cannot disagree about what a row does. What lives
// here is only how it looks and how the selection moves.
//
// Most rows arrive with a title and nothing else now; a detail is still drawn when one comes
// with a row, as one elided line, but the panel no longer leaves room for a line that is not
// there, which is most of what makes it compact.
Item {
    id: panel

    property var actions: []
    property int selection: 0
    property int unit: 10

    // the panel is deliberately compact: its height is what decides whether every row it holds
    // is reachable on a 720 high screen, so the padding and the per-row room are the smallest
    // that still read from a couch
    readonly property int padding: unit * 1.6

    implicitHeight: column.implicitHeight + padding * 2

    ConsolePalette {
        id: colors
    }

    // the selection only ever lands on something that can be chosen: a heading is not a
    // destination, and landing on one would mean a press that did nothing
    function firstSelectable() {
        for (let i = 0; i < panel.actions.length; ++i) {
            if (panel.actions[i].kind !== "header") {
                return i;
            }
        }
        return 0;
    }

    function move(step) {
        if (panel.actions.length === 0) {
            return;
        }
        let next = panel.selection;
        for (let tried = 0; tried < panel.actions.length; ++tried) {
            next = (next + step + panel.actions.length) % panel.actions.length;
            if (panel.actions[next].kind !== "header") {
                panel.selection = next;
                return;
            }
        }
    }

    function activate(index) {
        const item = panel.actions[index];
        if (!item || item.kind === "header") {
            return;
        }
        Shell.overlayActivate(index);
    }

    Rectangle {
        anchors.fill: parent
        radius: panel.unit * 0.8
        color: colors.surface
        border.color: colors.border
        border.width: 1

        Column {
            id: column

            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: panel.padding
            spacing: panel.unit * 0.35

            Text {
                text: "Couchbox"
                color: colors.dim
                font.pixelSize: Math.round(panel.unit * 1.1)
                font.capitalization: Font.AllUppercase
                font.letterSpacing: panel.unit * 0.12
            }

            Repeater {
                model: panel.actions

                delegate: Rectangle {
                    id: overlayRow

                    required property var modelData
                    required property int index

                    readonly property bool chosen: index === panel.selection
                    readonly property bool heading: modelData.kind === "header"

                    // most rows are title-only, and a detail that is absent rather than empty
                    // must not become a line of text. when one is present it is drawn here as
                    // the single elided line the row gives it
                    readonly property string detailText: {
                        const given = overlayRow.modelData.detail;
                        return given === undefined || given === null ? "" : String(given);
                    }

                    width: column.width
                    height: heading
                            ? rowTitle.implicitHeight + panel.unit * 0.7
                            : rowText.implicitHeight + panel.unit * 1.2
                    radius: panel.unit * 0.5
                    color: overlayRow.heading || !overlayRow.chosen
                            ? "transparent"
                            : colors.surfaceFocused
                    border.width: !overlayRow.heading && overlayRow.chosen
                            ? Math.max(1, Math.round(panel.unit * 0.12))
                            : 0
                    border.color: colors.accent

                    // the row fills in rather than switching, so moving down the list is
                    // something the eye follows
                    Behavior on color {
                        ColorAnimation {
                            duration: 120
                        }
                    }

                    Column {
                        id: rowText

                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.verticalCenter: parent.verticalCenter
                        anchors.leftMargin: panel.unit * 1.2
                        anchors.rightMargin: panel.unit * 1.2
                        spacing: panel.unit * 0.2

                        Text {
                            id: rowTitle

                            width: rowText.width
                            text: overlayRow.modelData.title === undefined
                                ? ""
                                : overlayRow.modelData.title
                            color: overlayRow.heading ? colors.dim : colors.text
                            font.pixelSize: Math.round(
                                panel.unit * (overlayRow.heading ? 0.95 : 1.5))
                            font.bold: !overlayRow.heading && overlayRow.chosen
                            font.capitalization: overlayRow.heading
                                ? Font.AllUppercase
                                : Font.MixedCase
                            elide: Text.ElideRight
                        }

                        Text {
                            width: rowText.width
                            visible: !overlayRow.heading && overlayRow.detailText !== ""
                            text: overlayRow.detailText
                            color: colors.dim
                            font.pixelSize: Math.round(panel.unit * 1.0)
                            // one line, because the panel's height is what decides whether
                            // everything in it is reachable on a 720 high screen
                            maximumLineCount: 1
                            elide: Text.ElideRight
                        }
                    }

                    // a mouse can click a row, which costs one handler and is never the
                    // only way to do anything
                    MouseArea {
                        anchors.fill: parent
                        enabled: !overlayRow.heading
                        onClicked: {
                            panel.selection = overlayRow.index;
                            panel.activate(overlayRow.index);
                        }
                    }
                }
            }
        }
    }
}
