import QtQuick
import QtQuick.Window
import Couchbox 1.0

// the overlay when it is over a running application (ADR-0035).
//
// The dashboard's window is hidden while an application is in front. Raising it to draw the panel
// on it, which is what used to happen, replaced whatever the person was looking at with the
// dashboard: a screen change wearing the word overlay. This is a window of its own, the size of
// the panel and nothing else, sitting on top of the application, which stays exactly where it was.
//
// It is opaque on purpose. A full-screen transparent window would need a compositor to composite
// it, and on the machines this targets the compositor is the first thing that becomes a question.
// The application is visible around the panel because the panel is small, which asks nothing of
// anybody, and the application is stopped while this is up, so what surrounds the panel is a still
// picture rather than something moving underneath it.
//
// The window is exactly as tall as the panel, and the panel is compact because most of the rows
// it is handed now carry a title and nothing else. A window taller than its contents would be an
// opaque rectangle covering part of the application for no reason.
Window {
    id: panelWindow

    // the dashboard's own scale, taken from the screen it will be centred on, so that the panel
    // over a game is the same size as the panel over the shelf
    readonly property int unit: Math.max(10, Math.round(Shell.windowHeight / 72))

    visible: Shell.overlayOverApplication
    flags: Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
    color: colors.surface

    width: Math.min(Shell.windowWidth - unit * 6, unit * 38)
    height: Math.min(panel.implicitHeight, Shell.windowHeight - unit * 2)
    x: Math.round((Shell.windowWidth - width) / 2)
    y: Math.round((Shell.windowHeight - height) / 2)

    // the press that opened this is the press that means "I want out", so the first row that can
    // be chosen is where the selection starts. The window also has to be given the keyboard: a
    // window that is drawn but not activated receives no key events at all, and the keys
    // themselves are handled by the item inside, because a Window is not an Item and cannot hold
    // them
    onVisibleChanged: {
        if (visible) {
            panel.selection = panel.firstSelectable();
            panelWindow.requestActivate();
            keyCatcher.forceActiveFocus();
        }
    }

    ConsolePalette {
        id: colors
    }

    Item {
        id: keyCatcher

        anchors.fill: parent
        focus: true

        OverlayPanel {
            id: panel

            anchors.fill: parent
            unit: panelWindow.unit
            actions: Shell.overlayActions
        }

        // up and down rather than left and right, because this is a list and not a shelf
        Keys.onPressed: (event) => {
            switch (event.key) {
            case Qt.Key_Up:
                panel.move(-1);
                event.accepted = true;
                break;
            case Qt.Key_Down:
                panel.move(1);
                event.accepted = true;
                break;
            case Qt.Key_Return:
            case Qt.Key_Enter:
            case Qt.Key_Space:
                panel.activate(panel.selection);
                event.accepted = true;
                break;
            case Qt.Key_Escape:
            case Qt.Key_Back:
            case Qt.Key_Menu:
            case Qt.Key_Meta:
            case Qt.Key_Super_L:
            case Qt.Key_Super_R:
                // back, and the key that opened it. closing hands the application back
                // running, exactly where the person was before the panel appeared: the
                // key opens an overlay and never takes anybody anywhere (ADR-0042)
                Shell.closeOverlay();
                event.accepted = true;
                break;
            }
        }
    }
}
