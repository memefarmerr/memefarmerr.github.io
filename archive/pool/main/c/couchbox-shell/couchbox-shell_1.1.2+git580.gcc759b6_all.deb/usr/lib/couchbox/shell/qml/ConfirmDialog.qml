// A question with two answers, drawn over whatever is on screen.
//
// This exists because the power actions confirmed by being pressed twice. Restart and Shut Down are the
// two things on this machine that cannot be undone, and "press it again to be sure" is not a confirmation:
// it is the same press, in the same place, with nothing said in between, and a person who meant to press
// Resume and missed by one row has already done it by the time the second press arrives. What was asked
// for is a dialog box, and this is one.
//
// A dialog rather than a row in the overlay panel, which would have been the smaller change. The panel is
// a list of things a person chose to look at; a question is not one of those, and answering it should not
// be a matter of finding it in a list. It is also the only thing on this machine that is drawn over the
// overlay rather than inside it, because the overlay is where the question came from.
//
// It is written in QML rather than as a Qt dialog for one reason: the shell's own controller reading feeds
// the QML, so a dialog drawn here is reachable with a D-pad, and a Qt widget window is not. That is the
// same reason the shell is QML at all, and it is why this is a component rather than a message box.
//
// Escape and B mean cancel, everywhere on this machine. That is the safe answer here and it is the one a
// person reaches for when they have changed their mind.

import QtQuick
import Couchbox 1.0

Item {
    id: dialog
    objectName: "confirmDialog"

    // the host's scale, so this matches the panel it is drawn over
    property int unit: 10
    property bool showing: false
    property string question: ""
    property string yes: ""
    property string no: "Cancel"

    // which of the two has the highlight. It starts on the way out, so that a press arriving from
    // somewhere else cannot carry on into the thing that cannot be undone
    property int chosen: 1

    signal answered(bool yes)

    readonly property int padding: unit * 1.4
    readonly property int rowHeight: unit * 3.6
    readonly property int widthWanted: Math.min(unit * 34, 720)

    visible: showing
    focus: showing

    ConsolePalette { id: colors }

    // Everything underneath stops taking keys while this is up. Without it the panel behind would keep
    // its own highlight and the D-pad would move two selections at once.
    Keys.onPressed: (event) => {
        if (!showing) {
            return;
        }
        switch (event.key) {
        case Qt.Key_Up:
        case Qt.Key_Down:
            chosen = chosen === 0 ? 1 : 0;
            event.accepted = true;
            break;
        case Qt.Key_Return:
        case Qt.Key_Enter:
            dialog.answered(chosen === 0);
            event.accepted = true;
            break;
        case Qt.Key_Escape:
        case Qt.Key_Back:
            dialog.answered(false);
            event.accepted = true;
            break;
        default:
            break;
        }
    }

    // the screen goes dark behind the question, which is what makes it a dialog rather than another row
    Rectangle {
        anchors.fill: parent
        color: colors.background
        opacity: 0.72
    }

    Rectangle {
        anchors.centerIn: parent
        width: dialog.widthWanted
        height: dialog.implicitHeight + dialog.padding * 2
        color: colors.surfaceRaised
        border.color: colors.borderStrong
        border.width: 1
        radius: dialog.unit * 0.8

        Column {
            id: body
            anchors.centerIn: parent
            width: parent.width - dialog.padding * 2
            spacing: dialog.unit * 1.0

            Text {
                width: parent.width
                text: dialog.question
                color: colors.text
                font.pixelSize: Math.round(dialog.unit * 1.9)
                font.bold: true
                wrapMode: Text.WordWrap
                horizontalAlignment: Text.AlignHCenter
            }

            Item { width: 1; height: dialog.unit * 0.6 }

            Repeater {
                model: [dialog.yes, dialog.no]

                Rectangle {
                    width: body.width
                    height: dialog.rowHeight
                    radius: dialog.unit * 0.4
                    color: dialog.chosen === index ? colors.surfaceFocused : colors.surface
                    border.color: dialog.chosen === index ? colors.accent : colors.border
                    border.width: dialog.chosen === index ? 2 : 1

                    Text {
                        anchors.centerIn: parent
                        text: modelData
                        color: dialog.chosen === index ? colors.accent : colors.dim
                        font.pixelSize: Math.round(dialog.unit * 1.6)
                        font.bold: dialog.chosen === index
                    }

                    MouseArea {
                        anchors.fill: parent
                        // the mouse is a bonus on this machine and it still works: choosing with it is
                        // the same answer as pressing the row
                        onClicked: dialog.answered(index === 0)
                    }
                }
            }
        }
    }
}
