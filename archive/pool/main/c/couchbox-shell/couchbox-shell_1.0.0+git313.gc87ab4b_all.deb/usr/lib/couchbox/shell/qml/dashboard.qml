import QtQuick
import QtQuick.Window
import Couchbox 1.0

// the Couchbox dashboard.
//
// written for a television at couch distance, driven by a controller or a keyboard.
// mouse input works because Qt gives it to us, but nothing here needs it and
// nothing here is reachable only with it.
//
// the shape of the screen is a console's. A quiet bar across the top holds the machine's name on
// the left and what the machine is doing on the right: the network it is on, its battery, and the
// time. Under that is the rail of sections. The middle of the screen is one wide horizontal shelf
// of large tiles, which is the thing the screen is about. A reserved band at the bottom holds the
// focused tile's name and description and whatever the machine has to say.
//
// The focused tile is larger, unshaded and ringed in the accent; the rest are smaller and shaded,
// so the eye reads the row as one shelf with one place in it. Every tile is drawn at all times,
// focused or not: a shelf where only the focused entry is visible is not a shelf, it means reading
// the entries one at a time instead of seeing them, which is the wrong thing to ask of somebody on
// a couch six feet away.
//
// There is a second screen behind the rail's last pill: every application on the machine at once,
// as a grid. A shelf is right for choosing between a handful of things and wrong for choosing
// between sixty, and a console has both for exactly that reason.
//
// Focus moves in two levels, with a third on the grid screen. Left and right move along the shelf,
// up leaves the shelf for the rail and down returns to it, and the shoulder buttons, which arrive
// as Tab and Backtab, change section from either level (ADR-0034). There is no navigation step
// that hides anything, so nothing can be behind one.
//
// The background is a gradient, one image and no shader. Nothing animates while the screen is
// idle: every animation here runs because somebody pressed something and then stops. That is not
// decoration, it is the difference between an interface that feels immediate on integrated
// graphics from 2012 and one that does not, which is also why the whole shell goes completely
// quiet while an application is running in front of it.

Window {
    id: root

    visible: true
    // fullscreen is the product. windowed exists so the shell can be run in a
    // terminal on a development machine, which is how it gets worked on, and so that
    // a screen size this machine does not have can be laid out and looked at.
    visibility: Shell.windowed ? Window.Windowed : Window.FullScreen
    width: Shell.windowWidth
    height: Shell.windowHeight
    color: "#08080b"
    title: "Couchbox"

    // the palette, taken from the shared singleton so that the overlay window over an application
    // and this window cannot come out slightly different. These are the only colours in the
    // interface, so tuning the look happens in one place: shell/qml/ConsolePalette.qml
    ConsolePalette {
        id: colors
    }

    // motion. every duration in the interface comes from here, so the whole thing can be
    // slowed down or sped up in one place, and so that nothing accidentally runs long. These are
    // deliberately short: a transition that is felt as a delay is worse than no transition at all.
    readonly property int motionFast: 110
    readonly property int motionBase: 170
    readonly property int motionSlow: 240

    // one scale factor derived from the screen height drives everything, so the layout stays
    // proportional on 1280x720 and 1920x1080, which are the two target televisions, and on the
    // 1366x768 panel of the laptops this ships to
    readonly property int unit: Math.max(10, Math.round(height / 72))

    readonly property real focusScale: 1.07

    // the tile's geometry. 3:4 is the proportion of a game's box, and the generated artwork is
    // drawn at exactly that proportion so nothing is ever cropped. There are two sets of numbers
    // and not one: the shelf draws large tiles that are the screen's subject, and the grid draws
    // smaller ones because a library is read rather than browsed. Both come from the same
    // component in the same arithmetic, so they cannot drift
    component TileMetrics: QtObject {
        id: metrics

        property int unit: 10
        property real widthUnits: 16
        property real focusScale: 1.07

        readonly property int tileWidth: Math.round(unit * widthUnits)
        readonly property int tileHeight: Math.round(tileWidth / colors.artworkAspect)
        readonly property int ringWidth: Math.max(3, Math.round(unit * 0.5))
        readonly property real labelHeight: unit * 3.4

        readonly property real boxWidth: tileWidth + ringWidth * 2
        readonly property real boxHeight: tileHeight + ringWidth * 2

        // the frame each tile gets, large enough for the lifted box with a hair to spare
        readonly property real frameWidth: Math.ceil(boxWidth * focusScale) + 2
        readonly property real frameHeight: Math.ceil(boxHeight * focusScale) + labelHeight + 2

        // how far apart two tiles sit, which is what the shelf scrolls by
        readonly property real pitch: frameWidth + unit * 2
    }

    TileMetrics {
        id: shelfMetrics
        unit: root.unit
        widthUnits: 16
        focusScale: root.focusScale
    }

    TileMetrics {
        id: gridMetrics
        unit: Math.max(8, Math.round(root.unit * 0.8))
        widthUnits: 13
        focusScale: 1.06
    }

    readonly property real tileFrameWidth: shelfMetrics.frameWidth
    readonly property real tileFrameHeight: shelfMetrics.frameHeight
    readonly property real itemPitch: shelfMetrics.pitch
    // how many tiles the shelf shows at once. Leaving it at a large number until the shelf has
    // been measured keeps the position line off the screen for the first frame rather than
    // flashing a count on a shelf that turns out to hold everything
    readonly property int shelfCapacity: shelf.width > 0 && itemPitch > 0
        ? Math.max(1, Math.floor(shelf.width / itemPitch)) : 999
    readonly property real gridItemPitch: gridMetrics.pitch
    readonly property real gridCellHeight: gridMetrics.frameHeight + gridMetrics.unit * 0.6

    // long lines are hard to read across a room, so the description is held to a
    // comfortable measure rather than the width of the screen
    readonly property int textWidth: Math.min(width - unit * 8, unit * 52)

    // the band at the bottom of the screen is reserved whether or not it has anything to
    // say, and this is its one fixed height. its contents cannot change it, so the shelf
    // above never moves when a status line or an install appears or goes away
    readonly property int statusBandHeight: unit * 9

    // the two rows of the top bar
    readonly property int topBarHeight: unit * 8.5

    // --- the model ----------------------------------------------------------

    // re-reading on every change rather than holding a copy, because a stale copy
    // is a dashboard that disagrees with its own files
    readonly property var collectionsModel: Shell.collections

    property int collectionIndex: 0

    readonly property var currentCollection:
        collectionsModel.length > 0
            ? collectionsModel[Math.min(collectionIndex, collectionsModel.length - 1)]
            : null

    readonly property var currentEntries: currentCollection ? currentCollection.entries : []

    property int entryIndex: 0

    readonly property var focusedEntry:
        currentEntries.length > 0
            ? currentEntries[Math.min(entryIndex, currentEntries.length - 1)]
            : null

    readonly property bool hasAnything: collectionsModel.length > 0 && currentEntries.length > 0

    // every application on the machine, for the grid. Built here rather than in Python because it
    // is a rearrangement of what the shell already handed over, and a second crossing of the
    // language boundary for the same data is a second thing that can disagree with the first
    readonly property var gridModel: {
        const result = [];
        const collections = Shell.collections;
        for (let c = 0; c < collections.length; c++) {
            const entries = collections[c].entries;
            for (let e = 0; e < entries.length; e++) {
                result.push(entries[e]);
            }
        }
        return result;
    }

    // a collection can arrive with fewer entries than the last one had, so the
    // cursor is brought back inside the model whenever the model changes
    onCollectionsModelChanged: {
        if (collectionIndex >= collectionsModel.length) {
            collectionIndex = 0;
        }
        entryIndex = 0;
        gridIndex = 0;
    }

    onCurrentEntriesChanged: {
        if (entryIndex >= currentEntries.length) {
            entryIndex = 0;
        }
        root.detailChanged();
    }

    // the description is replaced when the entry changes, so it is asked to arrive
    // rather than to appear
    onEntryIndexChanged: root.detailChanged()

    // --- navigation ---------------------------------------------------------

    // which level has the keys: the shelf, which is where the interface lives; the rail above it,
    // which is reached with up and left alone with down; or the grid, which is a screen of its own
    property string focusArea: "shelf"

    // where the rail is. The rail holds one pill per section and then one more, "All apps", which
    // opens the grid, so it can be one longer than the number of sections
    property int railIndex: 0

    // where the grid is
    property int gridIndex: 0

    readonly property bool gridOpen: focusArea === "grid"

    // how many tiles fit across the grid, which is what up and down move by
    readonly property int gridColumns: Math.max(1, Math.floor(grid.width / gridItemPitch))

    // how many sections the rail draws: the sections themselves, then the grid button when there
    // is enough on the machine for a grid to be worth opening
    readonly property int railLength: collectionsModel.length + (gridModel.length > 0 ? 1 : 0)

    // the chosen section, and the one place a section change happens, so clicking a tab,
    // a shoulder button and an arrow at the end of the row all land in the same state
    function selectCollection(index) {
        if (collectionsModel.length === 0) {
            return;
        }
        // wrapping, so the ends of the row of tabs are not dead ends on a controller whose
        // shoulder buttons arrive as Tab and Backtab (ADR-0034)
        collectionIndex = ((index % collectionsModel.length) + collectionsModel.length) % collectionsModel.length;
        entryIndex = 0;
        railIndex = collectionIndex;
        // a section change replaces every tile at once, so this one is not animated:
        // sliding a row of tiles that no longer exist is a slide of nothing
        root.scrollShelf(false);
    }

    function moveSection(step) {
        if (collectionsModel.length < 2) {
            return;
        }
        root.selectCollection(collectionIndex + step);
    }

    function moveEntry(step) {
        if (currentEntries.length === 0) {
            return;
        }
        entryIndex = (entryIndex + step + currentEntries.length) % currentEntries.length;
        root.scrollShelf(true);
    }

    // The shelf is scrolled here rather than with positionViewAtIndex, because that
    // jumps: the focused tile is put in view at the speed of the next redraw, which
    // reads as the whole row teleporting under the focus ring. This puts the focused
    // tile in the middle of the row when there is room for it, stays inside the row at
    // both ends, and runs the move as one short animation.
    //
    // The clamping is the part that matters. Without it the first and last tiles would
    // be centred with empty row beside them, which looks like a shelf that has come off
    // its rails.
    function scrollShelf(animated) {
        const itemWidth = tileFrameWidth;
        const maxOffset = Math.max(0, shelf.contentWidth - shelf.width);
        const centred = entryIndex * itemPitch + itemWidth / 2 - shelf.width / 2;
        const target = Math.max(0, Math.min(centred, maxOffset));

        if (!animated) {
            shelfScroll.stop();
            shelf.contentX = target;
            return;
        }

        shelfScroll.to = target;
        shelfScroll.restart();
    }

    // the grid keeps the focused tile inside the window rather than centring it: a grid that
    // re-centres on every press is a grid that moves under the person reading it
    function scrollGrid() {
        if (gridIndex >= 0 && gridIndex < gridModel.length) {
            grid.positionViewAtIndex(gridIndex, GridView.Contain);
        }
    }

    function openGrid() {
        if (gridModel.length === 0) {
            return;
        }
        focusArea = "grid";
        gridIndex = 0;
        // the grid's own items are built on the way in, so the scroll has to wait for them
        gridTimer.restart();
    }

    function closeGrid() {
        focusArea = "shelf";
        railIndex = collectionIndex;
    }

    function moveGrid(step) {
        if (gridModel.length === 0) {
            return;
        }
        gridIndex = Math.max(0, Math.min(gridModel.length - 1, gridIndex + step));
        root.scrollGrid();
    }

    // keep the focused pill inside the row. The rail is short enough to fit on the screens this
    // targets with the sections the image ships, but a person can add as many collections as they
    // like, and a rail that scrolls nowhere is a dead end for the sections at the end of it
    function scrollRail() {
        if (root.railIndex < 0 || root.railIndex >= rail.children.length) {
            return;
        }
        const pill = rail.children[root.railIndex];
        if (!pill) {
            return;
        }
        const left = pill.x;
        const right = pill.x + pill.width;
        const view = railScroll.contentX;
        if (left < view) {
            railScroll.contentX = left;
        } else if (right > view + railScroll.width) {
            railScroll.contentX = right - railScroll.width;
        }
    }

    function launchGridEntry() {
        const entry = gridModel[gridIndex];
        if (!entry) {
            return;
        }
        // looked up by launcher rather than launched by index, because the grid is a flattened
        // copy of the collections and a position in it means nothing to the shell
        Shell.launchLauncher(entry.launcher);
    }

    // The animations below are named in the interface and are started from here, and the
    // guards are not decoration: the model can change while the interface is still being
    // built, before the object that owns the animation exists, and a signal handler that
    // throws on the way up is a dashboard that does not start.
    function detailChanged() {
        if (captionSwap) {
            captionSwap.restart();
        }
    }

    function launchFocused() {
        if (focusedEntry) {
            Shell.launch(collectionIndex, entryIndex);
        }
    }

    // --- the screen ---------------------------------------------------------

    // three stops rather than two, so the light falls off towards the edges instead of
    // stepping from one colour to the other across a visible line
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: colors.backgroundTop }
            GradientStop { position: 0.45; color: colors.backgroundMid }
            GradientStop { position: 1.0; color: colors.background }
        }
    }

    // the light behind the focused tile. It is one cached image moving sideways, which is the
    // cheapest way to give the shelf a sense of place: it says where the eye should be without
    // drawing anything that has to be recomputed
    Image {
        id: glow

        visible: Shell.glowSource !== "" && root.hasAnything && root.focusArea !== "rail"
        source: Shell.glowSource
        width: root.unit * 68
        height: width
        opacity: root.focusArea === "grid" ? 0.35 : 0.7
        // behind the shelf, which is anchored through the middle of the screen, so the light sits
        // where the tiles are rather than where the window is
        y: shelfArea.y + shelfArea.height / 2 - height / 2
        x: {
            if (root.focusArea === "grid") {
                return root.width / 2 - width / 2;
            }
            const centre = root.unit * 3 + root.entryIndex * root.itemPitch
                + root.tileFrameWidth / 2 - shelf.contentX;
            return centre - width / 2;
        }
        asynchronous: true
        fillMode: Image.PreserveAspectFit

        Behavior on x {
            NumberAnimation {
                duration: root.motionBase
                easing.type: Easing.OutCubic
            }
        }
    }

    FocusScope {
        id: content
        anchors.fill: parent
        // the overlay takes the keyboard while it is up, so the shelf must not. one of the
        // two owns the keys at any moment, and it is never both
        focus: !Shell.overlayOpen

        // the interface comes up rather than switching on. It is one opacity ramp over
        // the whole screen, it runs once, and it covers the moment between the window
        // being mapped and the first frame being drawn.
        opacity: 0
        Component.onCompleted: appear.start()

        NumberAnimation {
            id: appear
            target: content
            property: "opacity"
            to: 1.0
            duration: root.motionSlow
            easing.type: Easing.OutCubic
        }

        // The fade is the one animation here whose failure would be worse than not having
        // it: an interface that fades up and never arrives is a black screen with a
        // working machine behind it. This puts the screen back unconditionally, and it is
        // harmless when the fade has worked, because by then it is setting the value the
        // fade has already reached.
        Timer {
            interval: root.motionSlow + 400
            running: true
            repeat: false
            onTriggered: content.opacity = 1
        }

        // one handler, because the gamepad arrives here as key events too. this is
        // why nothing in this file has to know whether a controller or a keyboard
        // is in use.
        Keys.onPressed: (event) => {
            switch (event.key) {
            case Qt.Key_Left:
                if (root.focusArea === "rail") {
                    root.railIndex = Math.max(0, root.railIndex - 1);
                    // and the shelf follows the highlight. Moving along the rail without
                    // changing the section left the two disagreeing: the rail said Power and
                    // the shelf still showed System, so pressing down entered a section
                    // nobody had chosen. The last pill is the grid button rather than a
                    // collection, so it is left alone here and down is what presses it.
                    if (root.railIndex < root.collectionsModel.length) {
                        root.selectCollection(root.railIndex);
                    }
                } else if (root.focusArea === "grid") {
                    root.moveGrid(-1);
                } else {
                    root.moveEntry(-1);
                }
                event.accepted = true;
                break;
            case Qt.Key_Right:
                if (root.focusArea === "rail") {
                    root.railIndex = Math.min(root.railLength - 1, root.railIndex + 1);
                    if (root.railIndex < root.collectionsModel.length) {
                        root.selectCollection(root.railIndex);
                    }
                } else if (root.focusArea === "grid") {
                    root.moveGrid(1);
                } else {
                    root.moveEntry(1);
                }
                event.accepted = true;
                break;
            case Qt.Key_Up:
                if (root.focusArea === "grid") {
                    // the grid's header is above the first row and nowhere else, so up from the
                    // first row leaves the grid and up anywhere else moves a row
                    if (root.gridIndex < root.gridColumns) {
                        root.closeGrid();
                    } else {
                        root.moveGrid(-root.gridColumns);
                    }
                } else if (root.focusArea === "shelf") {
                    // the rail is always there now, so up always has somewhere to go
                    root.railIndex = root.collectionIndex;
                    root.focusArea = "rail";
                }
                event.accepted = true;
                break;
            case Qt.Key_Down:
                if (root.focusArea === "rail" || root.focusArea === "grid") {
                    if (root.focusArea === "rail" && root.railIndex >= root.collectionsModel.length) {
                        // the last pill of the rail is the grid button, and down from a button
                        // means "press it", which is what every other button on this machine does
                        root.openGrid();
                    } else if (root.focusArea === "grid") {
                        root.moveGrid(root.gridColumns);
                    } else {
                        root.focusArea = "shelf";
                    }
                }
                event.accepted = true;
                break;
            // the shoulder buttons arrive as Tab and Backtab (ADR-0034), and this is where
            // they mean "another section", from either level, so moving between sections
            // never costs a trip back down through the shelf
            case Qt.Key_Tab:
                if (root.focusArea === "grid") {
                    root.closeGrid();
                }
                root.moveSection(1);
                event.accepted = true;
                break;
            case Qt.Key_Backtab:
                if (root.focusArea === "grid") {
                    root.closeGrid();
                }
                root.moveSection(-1);
                event.accepted = true;
                break;
            case Qt.Key_Return:
            case Qt.Key_Enter:
            case Qt.Key_Space:
                if (root.focusArea === "rail") {
                    if (root.railIndex >= root.collectionsModel.length) {
                        root.openGrid();
                    } else {
                        // the section changed as the selection moved along the row, so activating
                        // one is only the trip back down to the shelf
                        root.selectCollection(root.railIndex);
                        root.focusArea = "shelf";
                    }
                } else if (root.focusArea === "grid") {
                    root.launchGridEntry();
                } else if (root.hasAnything) {
                    root.launchFocused();
                } else {
                    // nothing is on this machine at all, so the one thing on screen is the button
                    // that opens the store. It is drawn with a mouse area like every other
                    // control, and this is what makes it reachable from a controller and a
                    // keyboard too, which is the rule the whole interface is built on
                    Shell.openStore();
                }
                event.accepted = true;
                break;
            // back. On the grid it leaves the grid, which is the only place in this window that
            // is a step away from the shelf; anywhere else it does nothing, because there is
            // nothing behind the dashboard to go back to
            case Qt.Key_Escape:
            case Qt.Key_Back:
                if (root.focusArea === "grid") {
                    root.closeGrid();
                }
                event.accepted = true;
                break;
            // a second way into the grid, for anybody who has used a console in the last decade:
            // the top face button is "the other view" everywhere
            case Qt.Key_Y:
                if (root.focusArea === "grid") {
                    root.closeGrid();
                } else {
                    root.openGrid();
                }
                event.accepted = true;
                break;
            // the overlay, from the interface rather than from the hotkey. Super is the key
            // that means "the system" on a desktop keyboard, Menu is the key that exists for
            // exactly this and is what Start sends, and a controller's guide button arrives
            // through the hotkey rather than here. All of them also work through a remote
            // session, which the guide cannot: a remote desktop delivers its keys to X and
            // never to the input devices the guide reads (ADR-0034)
            //
            // Escape is deliberately not one of them. It means "back" everywhere else in this
            // machine, and the key that opens the overlay should not also be the key everybody
            // reaches for to leave a screen (ADR-0034)
            case Qt.Key_Menu:
            case Qt.Key_Meta:
            case Qt.Key_Super_L:
            case Qt.Key_Super_R:
                Shell.openOverlayFromDashboard();
                event.accepted = true;
                break;
            case Qt.Key_Q:
                if (event.modifiers & Qt.ControlModifier) {
                    Shell.quit();
                    event.accepted = true;
                }
                break;
            }
        }

        // --- the top bar ----------------------------------------------------

        Item {
            id: topBar

            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.leftMargin: root.unit * 3
            anchors.rightMargin: root.unit * 3
            anchors.topMargin: root.unit * 2
            height: root.topBarHeight

            // the wordmark, drawn as a picture rather than set in a font so that it is the same
            // mark on every machine whatever fonts are installed. It is dropped rather than
            // broken when the artwork is missing
            Image {
                id: wordmark

                anchors.left: parent.left
                anchors.top: parent.top
                visible: Shell.logoSource !== "" && root.width > root.unit * 60
                source: Shell.logoSource
                height: root.unit * 3.4
                fillMode: Image.PreserveAspectFit
            }

            // what the machine is doing, on the right. Each chip is dropped when the machine
            // cannot answer for it, so a desktop shows no battery and a machine with no network
            // hardware shows no network, rather than a row of zeros
            Row {
                id: machineChips

                anchors.right: parent.right
                anchors.top: parent.top
                height: wordmark.height
                spacing: root.unit * 1.2

                Chip {
                    visible: Shell.networkAvailable
                    glyph: Shell.networkOnline
                        ? (Shell.networkKind === "wifi" ? Shell.icons["wifi"] : Shell.icons["wired"])
                        : Shell.icons["wired"]
                    text: Shell.networkOnline ? Shell.networkName : "Offline"
                    dim: !Shell.networkOnline
                }

                Chip {
                    visible: Shell.batteryPresent
                    glyph: Shell.batteryCharging
                        ? Shell.icons["battery-charging"]
                        : (Shell.batteryLevel <= 20 ? Shell.icons["battery"] : Shell.icons["battery-full"])
                    text: Shell.batteryLevel + "%"
                    dim: false
                }

                Chip {
                    visible: Shell.volumeAvailable
                    glyph: Shell.volumeMuted ? Shell.icons["mute"] : Shell.icons["volume"]
                    text: Shell.volumeMuted ? "Muted" : Shell.volumeLevel + "%"
                    dim: Shell.volumeMuted
                }
            }

            // the clock, under the chips. It is the one thing on this screen that is never a
            // decision, which is why it is the quietest thing on it
            Column {
                anchors.right: parent.right
                anchors.top: machineChips.bottom
                anchors.topMargin: root.unit * 0.8
                spacing: 0

                Text {
                    anchors.right: parent.right
                    text: Shell.clock
                    color: colors.text
                    font.pixelSize: Math.round(root.unit * 2.2)
                    font.bold: true
                }

                Text {
                    anchors.right: parent.right
                    text: Shell.date
                    color: colors.faint
                    font.pixelSize: Math.round(root.unit * 1.1)
                }
            }

            // the machine's own name for the person using it, on the left under the wordmark.
            // A profile is a person's, and saying whose machine this is costs one line
            Text {
                anchors.left: parent.left
                anchors.top: wordmark.bottom
                anchors.topMargin: root.unit * 0.9
                visible: Shell.profileName !== ""
                text: Shell.profileName
                color: colors.faint
                font.pixelSize: Math.round(root.unit * 1.2)
            }
        }

        // --- the rail, and the grid's own header -----------------------------

        // The sections, quiet: text with a short accent rule under the chosen one, and a filled
        // shape only while the focus is up here. That way the shelf stays the thing the screen is
        // about, and the moment up is pressed the rail level says so rather than looking like a
        // row that cannot be reached.
        //
        // The last pill is not a section. It is a button that opens the grid of everything, and
        // it wears a grid mark rather than a name, because "everything" is not a section and
        // should not read like one.
        Item {
            id: railArea

            visible: !root.gridOpen
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: topBar.bottom
            anchors.leftMargin: root.unit * 3
            anchors.rightMargin: root.unit * 3
            height: root.unit * 3.4

            Flickable {
                id: railScroll

                anchors.fill: parent
                contentWidth: rail.implicitWidth
                contentHeight: height
                interactive: false
                clip: true
                boundsBehavior: Flickable.StopAtBounds

                Behavior on contentX {
                    NumberAnimation {
                        duration: root.motionFast
                        easing.type: Easing.OutCubic
                    }
                }

                Row {
                    id: rail

                    height: parent.height
                    spacing: root.unit * 1.2

                    Repeater {
                        model: root.railLength

                        delegate: Item {
                            id: pill

                            required property int index

                            readonly property bool isGridButton: index >= root.collectionsModel.length
                            readonly property bool chosen: !isGridButton
                                && index === root.collectionIndex
                            readonly property bool pillFocused: root.focusArea === "rail"
                                && index === root.railIndex

                            width: isGridButton
                                ? root.unit * 5.4
                                : pillText.implicitWidth + root.unit * 2.4
                            height: rail.height

                            Rectangle {
                                anchors.fill: parent
                                anchors.topMargin: root.unit * 0.2
                                anchors.bottomMargin: root.unit * 0.2
                                radius: height / 2
                                color: pill.pillFocused
                                    ? colors.surfaceFocused
                                    : (pill.chosen ? colors.surface : "transparent")
                                border.width: pill.pillFocused ? 1 : 0
                                border.color: colors.accent

                                Behavior on color {
                                    ColorAnimation { duration: root.motionFast }
                                }
                            }

                            Image {
                                id: pillGlyph

                                anchors.centerIn: parent
                                visible: pill.isGridButton && source !== ""
                                source: Shell.icons["grid"]
                                width: root.unit * 1.7
                                height: width
                                opacity: pill.pillFocused ? 1.0 : 0.8
                                fillMode: Image.PreserveAspectFit
                            }

                            Text {
                                id: pillText

                                anchors.centerIn: parent
                                visible: !pill.isGridButton
                                text: pill.isGridButton
                                    ? ""
                                    : root.collectionsModel[pill.index].name
                                color: pill.pillFocused || pill.chosen ? colors.text : colors.dim
                                font.pixelSize: Math.round(root.unit * 1.35)
                                font.bold: pill.chosen

                                Behavior on color {
                                    ColorAnimation { duration: root.motionFast }
                                }
                            }

                            // the quiet marker of the chosen section while the focus is down on the
                            // shelf: a short accent rule, and nothing else
                            Rectangle {
                                anchors.horizontalCenter: parent.horizontalCenter
                                anchors.bottom: parent.bottom
                                anchors.bottomMargin: 0
                                width: pill.isGridButton ? root.unit * 1.7 : pillText.width
                                height: Math.max(2, Math.round(root.unit * 0.2))
                                radius: height / 2
                                color: colors.accent
                                opacity: pill.chosen && !pill.pillFocused ? 1 : 0

                                Behavior on opacity {
                                    NumberAnimation { duration: root.motionFast }
                                }
                            }

                            MouseArea {
                                anchors.fill: parent
                                onClicked: {
                                    if (pill.isGridButton) {
                                        root.openGrid();
                                    } else {
                                        root.railIndex = pill.index;
                                        root.selectCollection(pill.index);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // keep the focused pill inside the row. The rail is short enough to fit on the
            // screens this targets with the sections the image ships, but a person can add as
            // many collections as they like and a rail that scrolls nowhere is a dead end
            onVisibleChanged: root.scrollRail()
            Connections {
                target: root
                function onRailIndexChanged() { root.scrollRail() }
                function onFocusAreaChanged() { root.scrollRail() }
            }
        }

        // the grid's header, which is the rail's own space rather than a second row: the two
        // screens never appear at once, so they can share the room
        Item {
            id: gridHeader

            visible: root.gridOpen
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: topBar.bottom
            anchors.leftMargin: root.unit * 3
            anchors.rightMargin: root.unit * 3
            height: root.unit * 3.4

            Row {
                anchors.left: parent.left
                anchors.verticalCenter: parent.verticalCenter
                spacing: root.unit * 1.6

                Rectangle {
                    id: backChip

                    width: backRow.implicitWidth + root.unit * 2.4
                    height: root.unit * 2.8
                    radius: height / 2
                    anchors.verticalCenter: parent.verticalCenter
                    color: colors.surface
                    border.width: 1
                    border.color: colors.border

                    Row {
                        id: backRow
                        anchors.centerIn: parent
                        spacing: root.unit * 0.7

                        Image {
                            anchors.verticalCenter: parent.verticalCenter
                            visible: source !== ""
                            source: Shell.icons["back"]
                            width: root.unit * 1.3
                            height: width
                            fillMode: Image.PreserveAspectFit
                        }

                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: "Library"
                            color: colors.text
                            font.pixelSize: Math.round(root.unit * 1.3)
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        onClicked: root.closeGrid()
                    }
                }

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Everything on this machine"
                    color: colors.dim
                    font.pixelSize: Math.round(root.unit * 1.35)
                }
            }

            Text {
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                text: root.gridModel.length + (root.gridModel.length === 1 ? " item" : " items")
                color: colors.faint
                font.pixelSize: Math.round(root.unit * 1.2)
            }
        }

        // --- the shelf -------------------------------------------------------

        // the middle of the screen, between the rail and the reserved band, is where the shelf
        // lives. The shelf is centred in it rather than pinned under the rail, so the row of tiles
        // reads as the centre of the screen at any height, which is what a console dashboard is
        Item {
            id: shelfArea

            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: railArea.bottom
            anchors.bottom: statusBand.top
        }

        ListView {
            id: shelf
            objectName: "shelf"

            visible: root.hasAnything && !root.gridOpen
            orientation: ListView.Horizontal
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.verticalCenter: shelfArea.verticalCenter
            anchors.leftMargin: root.unit * 3
            anchors.rightMargin: root.unit * 3

            spacing: root.unit * 2
            height: root.tileFrameHeight

            model: root.currentEntries
            currentIndex: root.entryIndex
            clip: true

            // dragging is off, because the position of this row is the focus. A ring that
            // can be dragged away from the tile it belongs to is a row that can hide where
            // the user is, and on a couch the mouse is never the thing driving this.
            // scrollShelf is the only thing that moves it.
            interactive: false
            boundsBehavior: Flickable.StopAtBounds

            NumberAnimation {
                id: shelfScroll
                target: shelf
                property: "contentX"
                duration: root.motionBase
                easing.type: Easing.OutCubic
            }

            delegate: Item {
                id: frame

                required property var modelData
                required property int index

                width: root.tileFrameWidth
                height: root.tileFrameHeight

                CouchboxTile {
                    width: shelfMetrics.frameWidth
                    height: shelfMetrics.frameHeight
                    entry: frame.modelData
                    focused: frame.index === root.entryIndex
                    unit: shelfMetrics.unit
                    tileWidth: shelfMetrics.tileWidth
                    tileHeight: shelfMetrics.tileHeight
                    ringWidth: shelfMetrics.ringWidth
                    labelHeight: shelfMetrics.labelHeight

                    colorAccent: colors.accent
                    colorAccentBright: colors.accentBright
                    colorSurface: colors.surface
                    colorSurfaceFocused: colors.surfaceFocused
                    colorBorder: colors.border
                    colorText: colors.text
                    colorDim: colors.dim
                    colorShade: colors.shade
                    artworkRadiusFraction: colors.artworkRadiusFraction

                    motionFast: root.motionFast
                    motionBase: root.motionBase
                    focusScale: root.focusScale
                }

                MouseArea {
                    anchors.fill: parent
                    onClicked: {
                        if (root.entryIndex === frame.index) {
                            root.launchFocused();
                        } else {
                            root.entryIndex = frame.index;
                            root.scrollShelf(true);
                        }
                    }
                }
            }
        }

        // --- the grid of everything ------------------------------------------

        GridView {
            id: grid
            objectName: "grid"

            visible: root.gridOpen
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: gridHeader.bottom
            anchors.bottom: statusBand.top
            anchors.leftMargin: root.unit * 3
            anchors.rightMargin: root.unit * 3
            anchors.topMargin: root.unit * 0.6

            cellWidth: root.gridItemPitch
            cellHeight: root.gridCellHeight
            model: root.gridModel
            currentIndex: root.gridIndex
            clip: true

            // the focus is drawn by the tile, so the grid's own highlight is off and its only job
            // is to hold the items and keep them inside the window
            interactive: false
            highlight: null
            highlightFollowsCurrentItem: false
            boundsBehavior: Flickable.StopAtBounds
            flow: GridView.FlowLeftToRight
            layoutDirection: Qt.LeftToRight

            // the tiles are drawn inside a cell that is exactly their frame, so the grid lines up
            // with the shelf and a tile is the same size in both
            delegate: Item {
                id: cell

                required property var modelData
                required property int index

                width: grid.cellWidth
                height: grid.cellHeight

                CouchboxTile {
                    x: 0
                    y: 0
                    width: gridMetrics.frameWidth
                    height: gridMetrics.frameHeight
                    entry: cell.modelData
                    focused: root.gridOpen && cell.index === root.gridIndex
                    unit: gridMetrics.unit
                    tileWidth: gridMetrics.tileWidth
                    tileHeight: gridMetrics.tileHeight
                    ringWidth: gridMetrics.ringWidth
                    labelHeight: gridMetrics.labelHeight

                    colorAccent: colors.accent
                    colorAccentBright: colors.accentBright
                    colorSurface: colors.surface
                    colorSurfaceFocused: colors.surfaceFocused
                    colorBorder: colors.border
                    colorText: colors.text
                    colorDim: colors.dim
                    colorShade: colors.shade
                    artworkRadiusFraction: colors.artworkRadiusFraction

                    motionFast: root.motionFast
                    motionBase: root.motionBase
                    focusScale: root.focusScale
                }

                MouseArea {
                    anchors.fill: parent
                    onClicked: {
                        if (root.gridIndex === cell.index) {
                            root.launchGridEntry();
                        } else {
                            root.gridIndex = cell.index;
                        }
                    }
                }
            }
        }

        // a grid that has just been shown has no items laid out yet, and asking it to reveal the
        // first one before it does is a request that is quietly ignored
        Timer {
            id: gridTimer
            interval: 1
            repeat: false
            onTriggered: root.scrollGrid()
        }

        // --- what to say when there is nothing to show ---

        Item {
            id: emptyState

            visible: !root.hasAnything
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: railArea.bottom
            anchors.bottom: statusBand.top

            Column {
                anchors.centerIn: parent
                width: root.textWidth
                spacing: root.unit * 1.6

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    width: root.textWidth
                    horizontalAlignment: Text.AlignHCenter
                    color: colors.text
                    font.pixelSize: Math.round(root.unit * 2.0)
                    font.bold: true
                    wrapMode: Text.WordWrap
                    text: "This machine has nothing on it yet"
                }

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    width: root.textWidth
                    horizontalAlignment: Text.AlignHCenter
                    color: colors.dim
                    font.pixelSize: Math.round(root.unit * 1.35)
                    wrapMode: Text.WordWrap
                    text: "Couchbox OS keeps its applications separate from the system, so this "
                        + "list fills up as you install things. The store is where you do that."
                }

                StoreButton {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: Shell.storeAvailable
                }
            }
        }

        // --- the reserved band at the bottom ---

        // everything the machine has to say lives in this one band, and the band's height is
        // fixed and always reserved, so nothing that appears in it can move the shelf, the
        // band, or anything else. the faults this replaces were a status line printed over
        // the entry description and an install panel floating over the shelf: two things
        // that had never been given a place of their own.
        //
        // the first row is the focused entry: its name, and its description when it has one.
        // the name is written here rather than only on the tile because a tile with artwork
        // cannot write its own name on the artwork and stay readable at ten feet. the second
        // row is the machine: an install in progress as a compact name-then-bar row, and the
        // shell's status line beside it.
        Item {
            id: statusBand

            anchors.left: parent.left
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            anchors.leftMargin: root.unit * 3
            anchors.rightMargin: root.unit * 3
            anchors.bottomMargin: root.unit * 2
            height: root.statusBandHeight

            // one hairline separates the band from the shelf without boxing anything in,
            // and it is one static pixel rather than a drawn border
            Rectangle {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                height: 1
                color: colors.border
            }

            // first row: what is focused
            Item {
                id: captionRow

                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                anchors.topMargin: root.unit * 1.4
                height: root.unit * 3.0

                // the description arrives rather than switching, which is the small movement
                // the screen always had, and it is one short animation per change. the slide
                // is a few pixels and stays inside the reserved row, so it can never touch
                // the row below it
                property real slide: 0
                transform: Translate { y: captionRow.slide }

                SequentialAnimation {
                    id: captionSwap

                    // the start of the slide is set instantly, and only then animated, so the
                    // movement always runs the full distance instead of starting wherever the
                    // last one happened to stop
                    NumberAnimation {
                        target: captionRow
                        property: "slide"
                        to: root.unit * 0.6
                        duration: 0
                    }

                    ParallelAnimation {
                        NumberAnimation {
                            target: captionRow
                            property: "slide"
                            to: 0
                            duration: root.motionBase
                            easing.type: Easing.OutCubic
                        }

                        NumberAnimation {
                            target: captionRow
                            property: "opacity"
                            from: 0.0
                            to: 1.0
                            duration: root.motionBase
                            easing.type: Easing.OutCubic
                        }
                    }
                }

                // where this entry is in its section, and only when the section is longer than the
                // shelf can show at once.
                //
                // The shelf is the right shape for choosing between a handful of things and the
                // grid behind the rail's last pill is the right shape for sixty, and a section of
                // twelve had neither: seven tiles visible, the rest reached by pressing right, and
                // nothing saying how many there were. A person deciding whether to keep pressing
                // should not have to count tiles. It is a number and not a key hint, which is the
                // line ADR-0036 draws.
                Text {
                    id: captionPosition

                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    visible: !root.gridOpen && root.currentEntries.length > root.shelfCapacity
                    text: (root.entryIndex + 1) + " of " + root.currentEntries.length
                    color: colors.faint
                    font.pixelSize: Math.round(root.unit * 1.2)
                }

                Text {
                    id: captionName

                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    width: Math.min(captionName.implicitWidth, parent.width * 0.42)
                    text: {
                        if (root.gridOpen) {
                            return "Everything";
                        }
                        return root.focusedEntry && root.focusedEntry.name
                            ? root.focusedEntry.name : "";
                    }
                    color: colors.text
                    font.pixelSize: Math.round(root.unit * 2.1)
                    font.bold: true
                    elide: Text.ElideRight
                }

                // the section the entry belongs to, as a quiet label beside its name. It is the
                // one thing that tells a person where they are without a tab being highlighted
                Text {
                    id: captionSection

                    anchors.left: captionName.right
                    anchors.leftMargin: root.unit * 1.4
                    anchors.verticalCenter: parent.verticalCenter
                    visible: !root.gridOpen && !(root.focusedEntry && root.focusedEntry.description)
                    text: root.currentCollection ? root.currentCollection.name : ""
                    color: colors.faint
                    font.pixelSize: Math.round(root.unit * 1.2)
                }

                Text {
                    id: captionDescription

                    anchors.left: captionSection.visible ? captionSection.right : captionName.right
                    anchors.leftMargin: root.unit * 1.4
                    anchors.right: captionPosition.visible ? captionPosition.left : parent.right
                    anchors.rightMargin: captionPosition.visible ? root.unit * 1.6 : 0
                    anchors.verticalCenter: parent.verticalCenter
                    text: root.gridOpen
                        // "everything", not "every application": the grid draws the whole rail,
                        // which includes the power actions, and a caption that called Sleep an
                        // application was a caption that did not describe the screen under it
                        ? "Everything this machine has, in one place. Press back to return to the shelf."
                        : (root.focusedEntry && root.focusedEntry.description
                            ? root.focusedEntry.description : "")
                    visible: text !== ""
                    color: colors.dim
                    font.pixelSize: Math.round(root.unit * 1.35)
                    elide: Text.ElideRight
                }
            }

            // second row: the machine. the install row comes first and the status line
            // follows it, both elided, both never more than the single line this row reserves
            Item {
                id: statusRow

                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                anchors.bottomMargin: root.unit * 1.4
                height: root.unit * 2.4

                // an install is not a notification: it is a compact row with the name or
                // phrase at the left of it and a thin bar that fills in. the bar has a
                // moving block while the engine cannot say how far along it is, because a
                // bar that sits still reads as an install that has stopped
                Row {
                    id: installRow

                    // a hidden row takes no room, so the status line beside it starts at the
                    // left edge again the moment there is no install to show
                    width: visible ? implicitWidth : 0
                    height: root.unit * 2.4
                    visible: Shell.installActive
                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: root.unit * 1

                    Image {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: source !== ""
                        source: Shell.icons["download"]
                        width: root.unit * 1.6
                        height: width
                        fillMode: Image.PreserveAspectFit
                    }

                    Text {
                        id: installText

                        width: Math.min(installText.implicitWidth, root.unit * 26)
                        height: installRow.height
                        text: Shell.installText
                        color: colors.text
                        font.pixelSize: Math.round(root.unit * 1.3)
                        elide: Text.ElideRight
                        verticalAlignment: Text.AlignVCenter
                    }

                    Rectangle {
                        id: installBar

                        width: root.unit * 10
                        height: Math.max(3, Math.round(root.unit * 0.6))
                        y: Math.round((parent.height - height) / 2)
                        radius: height / 2
                        color: colors.border

                        Rectangle {
                            visible: Shell.installPercent >= 0
                            width: parent.width * Math.max(0, Math.min(1, Shell.installPercent / 100))
                            height: parent.height
                            radius: parent.radius
                            color: colors.accent
                        }

                        Rectangle {
                            id: installPulse

                            visible: Shell.installActive && Shell.installPercent < 0
                            width: installBar.width * 0.3
                            height: installBar.height
                            radius: installBar.radius
                            color: colors.accent

                            SequentialAnimation on x {
                                running: installPulse.visible
                                loops: Animation.Infinite
                                NumberAnimation {
                                    to: installBar.width - installPulse.width
                                    duration: 900
                                    easing.type: Easing.InOutSine
                                }
                                NumberAnimation {
                                    to: 0
                                    duration: 900
                                    easing.type: Easing.InOutSine
                                }
                            }
                        }
                    }
                }

                Text {
                    id: statusText

                    anchors.left: installRow.right
                    anchors.leftMargin: installRow.width > 0 ? root.unit * 2 : 0
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    text: Shell.status
                    color: colors.accent
                    font.pixelSize: Math.round(root.unit * 1.3)
                    elide: Text.ElideRight
                }
            }
        }
    }

    // --- the starting screen -------------------------------------------------

    // an application that is starting shows this until it has a window of its own, so that
    // nobody ever watches a black screen and wonders whether the machine heard them (ADR-0034).
    // It sits over the shelf and under the overlay, because the overlay is still the thing the
    // user asked for if they press the guide key while an application is starting.
    //
    // The motion is three dots and nothing else. It exists because a screen with no movement
    // on it reads as a machine that has stopped, and it stops the moment the application is on
    // screen, which is what keeps it affordable on the hardware this ships to.
    Rectangle {
        id: launchScreen

        anchors.fill: parent
        visible: Shell.launching
        gradient: Gradient {
            GradientStop { position: 0.0; color: colors.backgroundTop }
            GradientStop { position: 0.45; color: colors.backgroundMid }
            GradientStop { position: 1.0; color: colors.background }
        }

        Column {
            anchors.centerIn: parent
            spacing: root.unit * 1.6

            Image {
                anchors.horizontalCenter: parent.horizontalCenter
                visible: Shell.launchingIcon !== "" && source !== ""
                source: Shell.launchingIcon
                width: root.unit * 16
                height: width * 4 / 3
                fillMode: Image.PreserveAspectFit
                asynchronous: true
            }

            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                width: root.textWidth
                horizontalAlignment: Text.AlignHCenter
                text: Shell.launchingName
                color: colors.text
                font.pixelSize: Math.round(root.unit * 2.6)
                font.bold: true
                elide: Text.ElideRight
            }

            // "Starting" and the three dots are one line, so they are one bounded piece rather
            // than a positioner: a Row cannot align its children vertically, and the dots need
            // to sit on the text's centre line to read as an ellipsis
            Item {
                anchors.horizontalCenter: parent.horizontalCenter
                width: startingText.width + dotRow.width + root.unit * 0.8
                height: Math.max(startingText.height, dotRow.height)

                Text {
                    id: startingText

                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Starting"
                    color: colors.dim
                    font.pixelSize: Math.round(root.unit * 1.2)
                }

                Row {
                    id: dotRow

                    anchors.left: startingText.right
                    anchors.leftMargin: root.unit * 0.8
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: root.unit * 0.4

                    Repeater {
                        model: 3

                        Rectangle {
                            width: root.unit * 0.5
                            height: width
                            radius: width / 2
                            color: colors.accent
                            opacity: 0.25

                            // each dot starts a fifth of a second after the one before it, and
                            // the whole thing runs only while an application is starting
                            SequentialAnimation on opacity {
                                running: Shell.launching
                                loops: Animation.Infinite
                                PauseAnimation { duration: index * 200 }
                                NumberAnimation { to: 1.0; duration: 300 }
                                NumberAnimation { to: 0.25; duration: 300 }
                                PauseAnimation { duration: (2 - index) * 200 }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- the overlay ---------------------------------------------------------

    // the overlay, raised over whatever is on screen (docs/dashboard.md, ADR-0022).
    //
    // It appears in two shapes now, and both are the same list. Over the dashboard it is drawn
    // here, as a layer of this window. Over a running application it is a window of its own
    // (ADR-0035), because the dashboard's window is hidden while an application is in front, and
    // raising it to draw a panel on it replaced what the person was looking at with a dashboard:
    // that is a screen change, not an overlay.
    //
    // The rows and what choosing one means come from the shell now, rather than from a second copy
    // of the same logic written in this file, because there are two places that draw them.
    FocusScope {
        id: overlay

        anchors.fill: parent
        // short, and the layer stops being drawn once the fade has finished, so an overlay
        // that is closed costs nothing. Over a running application the overlay is its own
        // window instead, and this layer stays out of the way of that
        opacity: Shell.overlayOpen && !Shell.overlayOverApplication ? 1.0 : 0.0
        visible: opacity > 0
        focus: Shell.overlayOpen && !Shell.overlayOverApplication

        // the dim and the panel are one layer, and this is what fades it in. It is the slower of
        // the two motions: the dim arrives first and the panel settles into it a moment later,
        // which is what stops the whole thing reading as a rectangle being switched on
        Behavior on opacity {
            NumberAnimation {
                duration: root.motionBase
                easing.type: Easing.OutCubic
            }
        }

        Connections {
            target: Shell

            function onOverlayChanged() {
                if (Shell.overlayOpen && !Shell.overlayOverApplication) {
                    // the switcher, on whatever is already in front: the first press of a guide
                    // usually means "take me back to what I was doing"
                    listPanel.resetSelection();
                }
            }
        }

        // up and down move between the two regions and through the list; left and right move
        // along the switcher, and change the volume where the volume is chosen
        Keys.onPressed: (event) => {
            switch (event.key) {
            case Qt.Key_Up:
                listPanel.moveVertically(-1);
                event.accepted = true;
                break;
            case Qt.Key_Down:
                listPanel.moveVertically(1);
                event.accepted = true;
                break;
            case Qt.Key_Return:
            case Qt.Key_Enter:
            case Qt.Key_Space:
                listPanel.activate();
                event.accepted = true;
                break;
            case Qt.Key_Escape:
            case Qt.Key_Back:
            case Qt.Key_Menu:
            case Qt.Key_Meta:
            case Qt.Key_Super_L:
            case Qt.Key_Super_R:
                // back, and the key that opened it. closing puts the person back exactly
                // where they were, which over the dashboard is the dashboard: the key
                // opens an overlay and never takes anybody anywhere (ADR-0042)
                Shell.closeOverlay();
                event.accepted = true;
                break;
            case Qt.Key_Left:
            case Qt.Key_Right:
                // the volume row is a control, so left and right change it rather than walking
                // past it. On every other row they do what up and down do, because a row that
                // does nothing when a direction is pressed reads as a broken row
                if (listPanel.on_a_control()) {
                    Shell.volumeStep(event.key === Qt.Key_Right ? 1 : -1);
                } else {
                    listPanel.moveSideways(event.key === Qt.Key_Right ? 1 : -1);
                }
                event.accepted = true;
                break;
            }
        }

        // the dim behind the panel. Deliberately not a blur: a blur here is a stutter the
        // user sees every single time they open this, on hardware that can least afford it,
        // and the panel reads perfectly well without one
        Rectangle {
            anchors.fill: parent
            color: colors.shade
            opacity: 0.66
        }

        // the same component the overlay window wears, so the list over the shelf is the list
        // over a running application, drawn once. The height the rows ask for is held inside the
        // window, and the rows themselves are held inside the panel: measured at the tight case,
        // which is 1280x720 with every recent row the shell remembers and the three power entries
        OverlayPanel {
            id: listPanel

            anchors.centerIn: parent
            width: Math.min(root.width - root.unit * 6, root.unit * 40)
            // fitted to its rows, because this one is a layer of the dashboard's own window
            // rather than a window of its own: it is never mapped at one size and asked to grow
            // into another, so it has none of the reason the window over an application has to
            // wait for its height before it appears
            height: Math.min(listPanel.implicitHeight, root.height - root.unit * 2)
            unit: root.unit
            tiles: Shell.overlayTiles
            actions: Shell.overlayActions
            machineLine: Shell.networkOnline ? Shell.networkName : ""
            versionLine: Shell.osVersion
            clockLine: Shell.clock

            // choosing a tile goes there, choosing a row does what the row says
            onTileChosen: (kind, launcher) => Shell.overlayActivateTile(kind, launcher)
            onRowChosen: (index) => Shell.overlayActivate(index)

            // the rows are rebuilt whenever anything about them changes, which includes an
            // application finishing while this is open. A number that indexed the old list can
            // index nothing or a heading in the new one, and a cursor sitting on a heading is a
            // press that does nothing
            Connections {
                target: Shell
                function onOverlayActionsChanged() {
                    listPanel.clampSelection();
                }
            }

            revealAmount: Shell.overlayOpen && !Shell.overlayOverApplication ? 1 : 0

            Behavior on revealAmount {
                NumberAnimation {
                    duration: root.motionBase
                    easing.type: Easing.OutCubic
                }
            }
        }
    }

    // --- the pieces the screen is built from ---------------------------------

    // a chip: one small thing the machine is doing, in the top right. It is a picture, a value and
    // nothing else, because a labelled indicator is a sentence and this row is not read, it is
    // glanced at
    component Chip: Rectangle {
        id: chip

        property string glyph: ""
        property string text: ""
        property bool dim: false

        implicitWidth: chipRow.implicitWidth + root.unit * 2.2
        height: root.unit * 2.6
        radius: height / 2
        color: colors.surface
        border.width: 1
        border.color: colors.border
        opacity: chip.dim ? 0.6 : 1.0

        Row {
            id: chipRow

            anchors.centerIn: parent
            spacing: root.unit * 0.7

            Image {
                anchors.verticalCenter: parent.verticalCenter
                visible: chip.glyph !== ""
                source: chip.glyph
                width: root.unit * 1.5
                height: width
                fillMode: Image.PreserveAspectFit
            }

            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: chip.text
                color: colors.dim
                font.pixelSize: Math.round(root.unit * 1.2)
                elide: Text.ElideRight
            }
        }
    }

    // the one button on the empty state, and the only control in this interface that exists to
    // rescue somebody: a machine with nothing on it has no tile to press
    component StoreButton: Rectangle {
        id: storeButton

        width: storeLabel.implicitWidth + root.unit * 5
        height: root.unit * 4.2
        radius: height / 2
        color: storeArea.containsMouse || storeArea.pressed
            ? colors.accentBright
            : colors.accent

        Behavior on color {
            ColorAnimation { duration: root.motionFast }
        }

        Text {
            id: storeLabel

            anchors.centerIn: parent
            text: "Open the Store"
            color: "#140f04"
            font.pixelSize: Math.round(root.unit * 1.6)
            font.bold: true
        }

        MouseArea {
            id: storeArea

            anchors.fill: parent
            hoverEnabled: true
            onClicked: Shell.openStore()
        }
    }
}
