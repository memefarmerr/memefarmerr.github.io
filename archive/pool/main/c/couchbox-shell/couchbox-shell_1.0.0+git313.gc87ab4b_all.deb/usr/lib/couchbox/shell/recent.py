"""what this machine has started, most recent first.

The overlay is a way back to something, and what somebody most often wants back is what they
were doing a moment ago. Holding that in memory would lose it every time the session restarts
the dashboard, which is a thing the session does on purpose (m3-10), so it is a file.

The file is plain text in the same shape as a collection, because the person who edits a
collection by hand may well want to look at this one, and a format that needs a tool to read it
is a format that hides its own problems. It is read and written by the shell alone.

What it stores is the launcher, not the collection and the position the entry sat at. A
collection can be reorganised, renamed or removed between one launch and the next, and the
launcher is the name that survives all three, which is the whole reason a wrapper exists. The
display name is stored beside it so the overlay can say "RetroArch" without reading every
collection to find out.

One difference from a collection file is deliberate: a broken line in here is skipped rather
than refused. A collection is written by a person and a mistake in it should be loud, because
the fix is to edit the file. This one is written by the shell, so a broken line means a bug, and
refusing to draw the dashboard over it would turn that bug into a machine nobody can use.
"""

from __future__ import annotations

import dataclasses
import logging
import os
from pathlib import Path

log = logging.getLogger("couchbox.shell.recent")

# how many are remembered. Six fits the overlay without it becoming a library, and the list is a
# way back to something rather than a second menu: everything else is in the collections.
LIMIT = 6

# where the file lives: the state directory, because this is state rather than configuration or
# data, and it is the one of the three that a backup can afford to lose
STATE_SUBDIR = ("couchbox", "recent")
XDG_STATE_FALLBACK = (".local", "state")

KEY_LAUNCHER = "launcher"
KEY_NAME = "name"


@dataclasses.dataclass(frozen=True, slots=True)
class Recent:
    """one application this machine has started."""

    launcher: str
    name: str

    def as_dict(self) -> dict:
        return {"launcher": self.launcher, "name": self.name}


def path() -> Path:
    base = os.environ.get("XDG_STATE_HOME") or os.path.join(Path.home(), *XDG_STATE_FALLBACK)
    return Path(base).joinpath(*STATE_SUBDIR)


def parse(text: str) -> list[Recent]:
    """read the file's text. tolerant by design, see the module docstring."""
    items: list[Recent] = []
    launcher: str | None = None
    name = ""

    def finish() -> None:
        if launcher:
            items.append(Recent(launcher, name or launcher))

    for number, raw in enumerate(text.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            log.warning("%s:%d: not a 'key: value' line, so it was skipped", path(), number)
            continue
        key, _, value = line.partition(":")
        key = key.strip().lower()
        value = value.strip()
        if key == KEY_LAUNCHER:
            # a new entry ends the previous one, which is what makes a blank line optional and a
            # truncated file still usable
            finish()
            launcher = value or None
            name = ""
        elif key == KEY_NAME:
            name = value
        else:
            log.warning("%s:%d: unknown key '%s', skipped", path(), number, key)
    finish()
    return items[:LIMIT]


def render(items: list[Recent]) -> str:
    lines = [
        "# the applications this machine has started, most recent first.",
        "# written by the dashboard. editing it is allowed and nothing here is precious:",
        "# the next launch of something will put that something at the top.",
        "",
    ]
    for item in items:
        lines.append(f"{KEY_LAUNCHER}: {item.launcher}")
        lines.append(f"{KEY_NAME}: {item.name}")
        lines.append("")
    return "\n".join(lines)


def load() -> list[Recent]:
    try:
        text = path().read_text(encoding="utf-8")
    except FileNotFoundError:
        return []
    except OSError as error:
        log.warning("could not read the list of recent applications (%s)", error)
        return []
    return parse(text)


def note(launcher: str, name: str) -> list[Recent]:
    """record a launch and return the list it belongs at the top of."""
    if not launcher:
        return load()
    items = [Recent(launcher, name or launcher)]
    items.extend(item for item in load() if item.launcher != launcher)
    items = items[:LIMIT]
    save(items)
    return items


def save(items: list[Recent]) -> None:
    try:
        path().parent.mkdir(parents=True, exist_ok=True)
        path().write_text(render(items), encoding="utf-8")
    except OSError as error:
        # a dashboard that cannot remember what was launched still launches things
        log.warning("could not record the list of recent applications (%s)", error)
