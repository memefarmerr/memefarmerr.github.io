import QtQuick
import QtQuick.Window
import Couchbox 1.0

// the overlay when it is over a running application (ADR-0035).
//
// The dashboard's window is hidden while an application is in front. Raising it to draw the panel
// on it, which is what used to happen, replaced whatever the person was looking at with the
// dashboard: a screen change wearing the word overlay. This is a window of its own, the size of
// the panel and nothing else, sitting on top of the application, which stays exactly where it was.
//
// It is opaque on purpose. A full-screen transparent window would need a compositor to composite
// it, and on the machines this targets the compositor is the first thing that becomes a question.
// The application is visible around the panel because the panel is small, which asks nothing of
// anybody, and the application is stopped while this is up, so what surrounds the panel is a still
// picture rather than something moving underneath it.
//
// The window is exactly as tall as the panel, and the panel is compact because most of the rows
// it is handed now carry a title and nothing else. A window taller than its contents would be an
// opaque rectangle covering part of the application for no reason.
Window {
    id: panelWindow

    // the dashboard's own scale, taken from the screen it will be centred on, so that the panel
    // over a game is the same size as the panel over the shelf
    readonly property int unit: Math.max(10, Math.round(Shell.windowHeight / 72))
    readonly property int motionBase: 200

    flags: Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
    color: colors.surface

    width: Math.min(Shell.windowWidth - unit * 6, unit * 40)

    // A fixed size, settled before the window is ever mapped, and it is fixed for a reason that has
    // now been learned twice.
    //
    // The window used to be exactly as tall as its rows. The shell fills the rows a frame after it
    // decides to show the window, so the window was mapped at one size and grew a moment later, and
    // the strip that growth exposed was never painted: what showed there was whatever the server
    // had, which is a light rectangle across the bottom of the panel.
    //
    // The first attempt at fixing that waited for the height to stop changing before showing the
    // window. It worked once and then never again, because the wait was armed by timers that fire
    // once: after the first close nothing re-armed it, so the overlay could be opened exactly one
    // time per boot. That is worse than the fault it was fixing and it is why this is a fixed size
    // rather than a clever one. Nothing here depends on the rows, so there is no moment to wait
    // for, no latch to re-arm, and no way for the next change to break it.
    //
    // The list scrolls inside it, which is what OverlayPanel is already built for, and the panel
    // over the shelf keeps fitting its rows because it is a layer of this window rather than a
    // window of its own and is never mapped at one size and asked to grow into another.
    height: Math.min(Math.round(Shell.windowHeight * 0.78), Shell.windowHeight - unit * 2)
    visible: Shell.overlayOverApplication
    x: Math.round((Shell.windowWidth - width) / 2)
    y: Math.round((Shell.windowHeight - height) / 2)

    // the press that opened this is the press that means "I want out", so the first row that can
    // be chosen is where the selection starts. The window also has to be given the keyboard: a
    // window that is drawn but not activated receives no key events at all, and the keys
    // themselves are handled by the item inside, because a Window is not an Item and cannot hold
    // them
    onVisibleChanged: {
        if (visible) {
            // the switcher, on whatever is already in front: the first press of a guide usually
            // means "take me back to what I was doing"
            panel.resetSelection();
            panelWindow.requestActivate();
            keyCatcher.forceActiveFocus();
            panelReveal.restart();
        }
    }

    // the panel settles in over a fifth of a second. Nothing here can fade the window itself, so
    // this is the whole of the animation over an application, and it is the difference between the
    // panel arriving and the panel being switched on
    NumberAnimation {
        id: panelReveal

        target: panel
        property: "revealAmount"
        from: 0
        to: 1
        duration: panelWindow.motionBase
        easing.type: Easing.OutCubic
    }

    ConsolePalette {
        id: colors
    }

    // The window's own colour is set above, and this is drawn on top of it anyway. That is belt
    // and braces on purpose: a frameless window whose surface is not painted where the scene graph
    // has not reached shows whatever the server had there, which is a light rectangle, and it
    // turns up at the bottom of the panel where the row count changed the window's height. Four
    // lines of rectangle is cheaper than a fault that shows up on somebody else's machine and not
    // on this one.
    Rectangle {
        anchors.fill: parent
        color: colors.surface
    }

    Item {
        id: keyCatcher

        anchors.fill: parent
        focus: true

        OverlayPanel {
            id: panel

            anchors.fill: parent
            unit: panelWindow.unit
            tiles: Shell.overlayTiles
            actions: Shell.overlayActions
            machineLine: Shell.networkOnline ? Shell.networkName : ""
            versionLine: Shell.osVersion
            clockLine: Shell.clock

            // choosing a tile goes there, choosing a row does what the row says. The panel does
            // not know what either means, which is what keeps the two hosts drawing the same thing
            onTileChosen: (kind, launcher) => Shell.overlayActivateTile(kind, launcher)
            onRowChosen: (index) => Shell.overlayActivate(index)

            // the rows are rebuilt whenever anything about them changes, which includes an
            // application finishing while this is open. A number that indexed the old list can
            // index nothing or a heading in the new one, and a cursor sitting on a heading is a
            // press that does nothing
            Connections {
                target: Shell
                function onOverlayActionsChanged() {
                    panel.clampSelection();
                }
            }
        }

        // up and down move between the two regions and through the list; left and right move
        // along the switcher, and change the volume where the volume is chosen
        Keys.onPressed: (event) => {
            switch (event.key) {
            case Qt.Key_Up:
                panel.moveVertically(-1);
                event.accepted = true;
                break;
            case Qt.Key_Down:
                panel.moveVertically(1);
                event.accepted = true;
                break;
            case Qt.Key_Left:
            case Qt.Key_Right:
                // the volume row is a control: left and right change it rather than walking past.
                // On every other row they move the selection, because a row that does nothing when
                // a direction is pressed reads as a broken row
                if (panel.on_a_control()) {
                    Shell.volumeStep(event.key === Qt.Key_Right ? 1 : -1);
                } else {
                    panel.moveSideways(event.key === Qt.Key_Right ? 1 : -1);
                }
                event.accepted = true;
                break;
            case Qt.Key_Return:
            case Qt.Key_Enter:
            case Qt.Key_Space:
                panel.activate();
                event.accepted = true;
                break;
            case Qt.Key_Escape:
            case Qt.Key_Back:
            case Qt.Key_Menu:
            case Qt.Key_Meta:
            case Qt.Key_Super_L:
            case Qt.Key_Super_R:
                // back, and the key that opened it. closing hands the application back
                // running, exactly where the person was before the panel appeared: the
                // key opens an overlay and never takes anybody anywhere (ADR-0042)
                Shell.closeOverlay();
                event.accepted = true;
                break;
            }
        }
    }
}
