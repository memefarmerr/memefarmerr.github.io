"""input devices, read without being taken.

This module exists for one reason, and it is a reason to do something rather than a reason to
do nothing: **nothing here grabs a device.**

A grabbed device delivers its events to exactly one process. A guide that grabbed the keyboard
would take the keyboard away from the game it is supposed to be sitting on top of, so typing
would stop working the moment the guide started. Reading without grabbing is allowed more than
once: the application, Xorg and this process can all read the same keyboard at the same time,
and each sees every event.

Two consequences follow, and both are deliberate rather than unfortunate:

  * a device this process cannot open is skipped rather than fatal, because what devices exist
    and what may be read are not ours to decide. What could and could not be opened is reported,
    which is the difference between "the hotkey does not work" and "the hotkey cannot see the
    keyboard, so it is doing exactly what it can".
  * devices arrive and leave while this runs, so the set is rescanned rather than assumed. A
    controller plugged in after the session started has to work, and one that is unplugged must
    not take the guide down with it.
"""

from __future__ import annotations

import glob
import logging
import os
import select
import time
from dataclasses import dataclass

import evdev
from evdev import ecodes

log = logging.getLogger("couchbox.guide.devices")

DEVICE_GLOB = "/dev/input/event*"


# What a device is, is decided by the buttons it claims rather than by its name. The name is
# whatever the vendor wrote and it is frequently unhelpful, and keeping a list of names would
# mean maintaining the controller database this project deliberately does not maintain.
GAMEPAD_BUTTONS = frozenset(
    {
        ecodes.BTN_SOUTH,
        ecodes.BTN_EAST,
        ecodes.BTN_NORTH,
        ecodes.BTN_WEST,
        ecodes.BTN_MODE,
        ecodes.BTN_START,
        ecodes.BTN_SELECT,
        ecodes.BTN_TL,
        ecodes.BTN_TR,
        ecodes.BTN_DPAD_UP,
        ecodes.BTN_DPAD_DOWN,
        ecodes.BTN_DPAD_LEFT,
        ecodes.BTN_DPAD_RIGHT,
    }
)

KEYBOARD_KEYS = frozenset(
    {
        ecodes.KEY_LEFTMETA,
        ecodes.KEY_RIGHTMETA,
        ecodes.KEY_LEFTCTRL,
        ecodes.KEY_RIGHTCTRL,
        ecodes.KEY_LEFTALT,
        ecodes.KEY_RIGHTALT,
        ecodes.KEY_LEFTSHIFT,
        ecodes.KEY_RIGHTSHIFT,
        ecodes.KEY_SPACE,
        ecodes.KEY_ENTER,
        ecodes.KEY_TAB,
        ecodes.KEY_BACKSPACE,
        ecodes.KEY_ESC,
    }
)

# three letters or more is a keyboard. One or two could be a remote control, a headset or a
# drawer full of other things that present a few buttons and are not worth watching.
LETTERS = frozenset(
    list(range(ecodes.KEY_Q, ecodes.KEY_P + 1))
    + list(range(ecodes.KEY_A, ecodes.KEY_L + 1))
    + list(range(ecodes.KEY_Z, ecodes.KEY_M + 1))
)


def classify(keys: set[int]) -> frozenset[str]:
    """what this device appears to be, from the buttons it claims.

    A device can be more than one thing, which is not a complaint: a wireless keyboard with a
    controller mode claims both, and it should be watched for either.
    """
    kinds = set()
    if keys & GAMEPAD_BUTTONS:
        kinds.add("gamepad")
    if (keys & KEYBOARD_KEYS) or len(keys & LETTERS) >= 3:
        kinds.add("keyboard")
    return frozenset(kinds)


@dataclass
class Device:
    """one open input device."""

    path: str
    name: str
    kinds: frozenset[str]
    handle: evdev.InputDevice

    def __str__(self) -> str:
        kinds = ",".join(sorted(self.kinds)) or "unclassified"
        return f"{self.path} ({self.name}, {kinds})"


def open_device(path: str) -> Device | None:
    """open one device for reading, or return nothing and say why in the log.

    A device that cannot be read is not an error. On a machine where the session has not been
    given access to the input devices, every one of them lands here, and the guide's job is then
    to say so clearly rather than to fail in a way that looks like a broken hotkey.
    """
    try:
        handle = evdev.InputDevice(path)
    except PermissionError:
        log.debug("%s cannot be read: permission denied", path)
        return None
    except OSError as error:
        log.debug("%s could not be opened: %s", path, error)
        return None

    capabilities = handle.capabilities(verbose=False)
    keys = set(capabilities.get(ecodes.EV_KEY, ()))
    return Device(path=path, name=handle.name, kinds=classify(keys), handle=handle)


def scan(known: dict | None = None) -> list[Device]:
    """every device that can be read right now.

    `known` is what is already open, by path, and a device in it is handed back rather than opened
    again. Opening a device twice gives two handles on the same queue, and the old one is what
    events have already been delivered to: replacing it is how a press gets thrown away, which this
    did once every two seconds. The caller passes what it has and this reuses it.
    """
    known = known or {}
    devices = []
    for path in sorted(glob.glob(DEVICE_GLOB)):
        device = known.get(path)
        if device is None:
            device = open_device(path)
        if device is not None:
            devices.append(device)
    return devices


def unreadable() -> list[str]:
    """the device nodes that exist but cannot be read, which is what gets reported."""
    return [path for path in sorted(glob.glob(DEVICE_GLOB)) if not os.access(path, os.R_OK)]


def close_device(device: Device) -> None:
    try:
        device.handle.close()
    except OSError:
        log.debug("%s did not close cleanly, which does not matter", device.path)


class Watcher:
    """the readable devices, kept up to date, and the key events that matter.

    `interesting` is the set of key codes to report, or None for all of them. The guide asks for
    all of them, because telling a press apart from a shortcut needs to know about the keys it
    does not act on: Meta on its own means one thing and Meta with anything else means another.
    """

    def __init__(self, interesting: set[int] | None = None, rescan_every: float = 2.0):
        self._interesting = frozenset(interesting) if interesting is not None else None
        self._rescan_every = rescan_every
        self._devices: dict[str, Device] = {}
        self._last_scan = 0.0

    @property
    def devices(self) -> list[Device]:
        return list(self._devices.values())

    def refresh(self) -> None:
        """open what is new, close what has gone.

        A device that has not moved keeps its open handle, so a keyboard is not reopened every
        two seconds, which would be a strange thing to do to a device. That sentence described what
        this was supposed to do and not what it did: `scan` opened a fresh handle for every path on
        every scan, so the device that had not moved was replaced, and the handle it had been read
        through was closed with anything queued on it. The window is the scan itself, which is a
        fraction of a millisecond for one device and a few milliseconds for a laptop's keyboard,
        touchpad, lid switch, power button and controller, once every two seconds.
        """
        found = {device.path: device for device in scan(self._devices)}

        for path, device in found.items():
            if path not in self._devices:
                log.info("watching %s", device)

        for path, device in self._devices.items():
            if path not in found:
                log.info("%s went away", device)
                close_device(device)

        self._devices = found
        self._last_scan = time.monotonic()

    def poll(self, timeout: float = 0.5) -> list[tuple[Device, int, int]]:
        """wait for something, and return what arrived as (device, code, value)."""
        if time.monotonic() - self._last_scan >= self._rescan_every:
            self.refresh()

        if not self._devices:
            # nothing to wait on, so this is a sleep with a scan at the end of it
            time.sleep(min(timeout, 0.5))
            return []

        by_handle = {id(device.handle): device for device in self._devices.values()}
        handles = [device.handle for device in self._devices.values()]

        try:
            ready, _, _ = select.select(handles, [], [], timeout)
        except (OSError, ValueError):
            # a device went away between the scan and the wait. the next pass will sort it out,
            # and this is why the scan is cheap and happens often
            log.debug("waiting on the devices failed, so they will be rescanning")
            self.refresh()
            return []

        events: list[tuple[Device, int, int]] = []
        for handle in ready:
            device = by_handle.get(id(handle))
            try:
                for event in handle.read():
                    if event.type != ecodes.EV_KEY:
                        continue
                    if self._interesting is not None and event.code not in self._interesting:
                        continue
                    events.append((device, event.code, event.value))
            except OSError:
                # this is what an unplugged device looks like from here
                log.info("%s could not be read any more", device.path if device else "a device")
                self.refresh()
                break

        return events

    def close(self) -> None:
        for device in self._devices.values():
            close_device(device)
        self._devices = {}
