"""the dashboard's end of the guide hotkey.

couchbox-guide reads the input devices directly, because while a game has the screen the
dashboard is not drawing and cannot react to anything. When the button is pressed it sends
one word over a unix socket, and this module owns that socket.

What a word means is deliberately not decided here. It is decided by the shell, because the
shell is the only thing that knows whether an application is in front, whether the overlay
is already up, and whether anything is running at all.

Three things about this are worth knowing before changing it:

  * the socket name appears in two files, in a process with no toolkit and in this one. They
    are copies rather than an import, because the guide has to start when the dashboard has
    failed to. tests/check-socket-name.sh is what keeps the two copies honest.
  * a socket file outlives the process that made it, so a dashboard that was killed leaves
    one behind and listening then refuses to start. A file that nothing answers on is
    removed, and a file that something answers on is left alone, because taking a live
    socket would take the hotkey away from a dashboard that is actually running.
  * a word that is not understood is refused and logged rather than guessed at. A guide from
    a newer release sending something this dashboard has never heard of should say so in the
    log, which is where the recovery path looks.
"""

from __future__ import annotations

import logging
import os

from PySide6.QtCore import QObject, Signal, Slot
from PySide6.QtNetwork import QLocalServer, QLocalSocket

log = logging.getLogger("couchbox.shell.hotkey")

DEFAULT_SOCKET_NAME = "couchbox-shell.sock"
SOCKET_ENV = "COUCHBOX_SHELL_SOCKET"

# what the guide sends. They are three words rather than one because the guide cannot tell
# which of them the shell should act on: only the shell knows whether an application is in
# front, and an application that wants the guide button for its own overlay is a question
# about the application rather than about the button.
MESSAGE_GUIDE = "guide"
MESSAGE_BUTTON = "guide-button"
MESSAGE_CHORD = "chord"
MESSAGES = frozenset({MESSAGE_GUIDE, MESSAGE_BUTTON, MESSAGE_CHORD})


def socket_path() -> str:
    """where the dashboard listens, decided the same way the guide decides it.

    The session normally sets the variable, because the session starts both ends and is the
    only thing that knows the runtime directory for certain. Without it the runtime directory
    is used, and /tmp is the last resort for a machine that has none.
    """
    override = os.environ.get(SOCKET_ENV)
    if override:
        return override
    return os.path.join(os.environ.get("XDG_RUNTIME_DIR") or "/tmp", DEFAULT_SOCKET_NAME)


class HotkeyServer(QObject):
    """receives the guide's words and turns them into one signal."""

    pressed = Signal(str)

    def __init__(self, path: str | None = None, parent: QObject | None = None):
        super().__init__(parent)
        self._path = path or socket_path()
        self._server = QLocalServer(self)
        self._server.newConnection.connect(self._on_connection)
        self._listening = False

    # --- the socket ---------------------------------------------------------

    @property
    def path(self) -> str:
        return self._path

    @property
    def listening(self) -> bool:
        return self._listening

    def start(self) -> bool:
        """begin listening. returns whether it worked.

        A dashboard that cannot listen is still a dashboard: the interface, the library and
        everything a user can reach with a keyboard in front of them all still work, and the
        alternative to carrying on is a black screen because a hotkey could not be watched.
        """
        if self._listening:
            return True

        if os.path.exists(self._path) and not self._something_answers():
            log.info("removing the socket an earlier dashboard left behind: %s", self._path)
            QLocalServer.removeServer(self._path)

        if not self._server.listen(self._path):
            log.warning(
                "not listening for the guide key at %s (%s). the dashboard works without it",
                self._path,
                self._server.errorString(),
            )
            return False

        log.info("listening for the guide key at %s", self._path)
        self._listening = True
        return True

    def _something_answers(self) -> bool:
        """is there a dashboard already listening on that path."""
        probe = QLocalSocket(self)
        probe.connectToServer(self._path)
        alive = probe.waitForConnected(200)
        probe.abort()
        return alive

    def stop(self) -> None:
        """give the socket back, so the next dashboard can have it.

        Called when the shell is shutting down. A file left behind would be removed by the
        next dashboard anyway, but leaving it means the next start logs a warning about a
        problem that is not there.
        """
        if self._listening:
            self._server.close()
            QLocalServer.removeServer(self._path)
            self._listening = False

    # --- what arrives on it -------------------------------------------------

    @Slot()
    def _on_connection(self) -> None:
        while self._server.hasPendingConnections():
            connection = self._server.nextPendingConnection()
            if connection is None:
                return
            connection.readyRead.connect(lambda held=connection: self._read(held))
            connection.disconnected.connect(connection.deleteLater)
            # the guide writes and closes, so the data is normally already there by the
            # time the connection is handed over
            if connection.bytesAvailable():
                self._read(connection)

    def _read(self, connection: QLocalSocket) -> None:
        text = bytes(connection.readAll()).decode("utf-8", "replace")
        for line in text.splitlines():
            message = line.strip()
            if not message:
                continue
            if message not in MESSAGES:
                log.warning("the guide sent something this dashboard does not know: %r", message)
                continue
            log.info("the guide key was pressed: %s", message)
            self.pressed.emit(message)
