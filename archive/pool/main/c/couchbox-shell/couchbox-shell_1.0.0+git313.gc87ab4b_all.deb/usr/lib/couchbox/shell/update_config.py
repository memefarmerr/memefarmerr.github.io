"""whether this machine updates itself when it starts, and where that is kept.

One setting, in the same file-and-directory shape as the controller's preferences and for the same
reason: everything in this project that survives a reboot is a file a person can read, edit or
delete, and removing one directory puts the machine back to the defaults written below.

The default is **on**, which is a decision rather than a convenience. This machine is a console: it
is turned on from a couch and the person turning it on has no other way to find out that the
dashboard they are looking at is a year old. A machine that updates itself when it starts is a
machine that is current, and the alternative is a machine where nobody ever presses the button. See
ADR-0051.

What "on" does not mean: it does not update while an application is in front, it does not update
without a network, and it does not update more than once per start. What it does is ask, quietly,
what this machine's own configured sources offer, and act on the answer.

No toolkit is imported here, so a machine with no display can still be checked: this module is
loaded by path in `tests/check-update-config.sh` and exercised the same way the controller's is.
"""

from __future__ import annotations

import logging
import os
import tempfile
from pathlib import Path

log = logging.getLogger("couchbox.update-config")

# what the setting may be. Anything else is the default, and the first entry is the default
CHOICES: dict[str, tuple[str, ...]] = {
    "auto-update": ("on", "off"),
}

DEFAULTS: dict[str, str] = {name: values[0] for name, values in CHOICES.items()}


def config_directory() -> Path:
    """where a person's Couchbox settings live, the same place the controller's do."""
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(base) / "couchbox"


def config_path() -> Path:
    return config_directory() / "updates.conf"


def read_settings() -> dict[str, str]:
    """the settings on disk, with anything missing or unusable filled in from the defaults."""
    settings = dict(DEFAULTS)
    try:
        text = config_path().read_text(encoding="utf-8")
    except FileNotFoundError:
        return settings
    except OSError as error:
        log.warning("could not read %s (%s), so the defaults are used", config_path(), error)
        return settings

    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        name, _, value = stripped.partition("=")
        name = name.strip().lower()
        value = value.strip().lower()
        if name not in CHOICES:
            log.info("ignoring the unknown update setting '%s'", name)
            continue
        if value not in CHOICES[name]:
            log.warning(
                "'%s' is not one of %s for '%s', so %s is used",
                value,
                ", ".join(CHOICES[name]),
                name,
                DEFAULTS[name],
            )
            continue
        settings[name] = value
    return settings


def automatic() -> bool:
    """whether this machine should look for an update when the dashboard starts.

    Read fresh every time rather than cached: it is asked once per start and once whenever the
    settings application draws that page, and a cache would only be a way for the settings
    application to be told the answer it just wrote is not the answer yet.
    """
    return read_settings()["auto-update"] == "on"


def set_automatic(enabled: bool) -> None:
    """write the setting, keeping the file readable and the write atomic."""
    write_settings({"auto-update": "on" if enabled else "off"})


def write_settings(settings_wanted: dict[str, str]) -> None:
    """write the settings, keeping the file readable and the write atomic.

    The file is written beside itself and moved into place, so a machine that loses power in the
    middle has the old file rather than half of a new one. The same shape as the controller's.
    """
    lines = [
        "# written by the Couchbox settings application.",
        "#",
        "# auto-update: 'on' looks for updates when the dashboard starts and installs what this",
        "#              machine's own sources offer. 'off' means updates happen only when somebody",
        "#              asks for one on the Updates page.",
    ]
    for name in sorted(CHOICES):
        value = str(settings_wanted.get(name, DEFAULTS[name])).strip().lower()
        if value not in CHOICES[name]:
            log.warning(
                "'%s' is not one of %s, so %s is written", value, CHOICES[name], DEFAULTS[name]
            )
            value = DEFAULTS[name]
        lines.append(f"{name} = {value}")

    directory = config_directory()
    directory.mkdir(parents=True, exist_ok=True)
    handle, temporary = tempfile.mkstemp(prefix="updates-", dir=directory)
    try:
        with os.fdopen(handle, "w", encoding="utf-8") as out:
            out.write("\n".join(lines) + "\n")
        os.replace(temporary, config_path())
    except OSError:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise

    log.info("wrote %s", config_path())
