import QtQuick

// the colours of the console, in one place.
//
// The dashboard and the overlay window are separate windows and both draw with these, and the
// overlay is now drawn in two of them: over the dashboard itself, and over a running application
// (ADR-0035). Three copies of a palette is three chances for the panel over a game to come out a
// slightly different colour from the panel over the shelf, which is exactly the kind of thing
// nobody reports and everybody sees.
//
// It is instantiated rather than used as a singleton: `ConsolePalette { id: colors }`, once per
// window. A singleton needed a qmldir and a pragma and still resolved to nothing in the offscreen
// check, and a component that is constructed where it is used has no such step to get wrong.
//
// The name is deliberate: `Palette` is a value type Qt Quick itself provides, so a file called
// Palette.qml is shadowed by it, and the symptoms are memorable and quiet: every colour in the
// interface resolves to a Qt default instead, which draws a dashboard that is black except for
// blue outlines. Measured, after wondering why the palette "worked" and nothing else did.
//
// The scheme, and why it is this one. One dark background, one warm accent, and text at three
// strengths. Amber rather than a console vendor's green or blue, because Couchbox is its own
// thing and because a warm accent reads well against the dark blue-grey the tiles bring with
// them. Text is deliberately not pure white: at ten feet on a television, pure white on black
// blooms, and the reading is worse than a slightly softer tone.
QtObject {
    // the background, top to bottom. Two stops and a third at the bottom so the light appears to
    // fall from above instead of the screen being one flat colour
    readonly property color backgroundTop: "#1d1d29"
    readonly property color backgroundMid: "#0e0e14"
    readonly property color background: "#08080b"

    // surfaces: the panel of an overlay, a tile that has no artwork, a raised row
    readonly property color surface: "#20202a"
    readonly property color surfaceRaised: "#262631"
    readonly property color surfaceFocused: "#2b2b39"
    readonly property color border: "#34343f"
    readonly property color borderStrong: "#4a4a5a"

    // text, at three strengths. `text` is what a person reads, `dim` is a description, and
    // `faint` is a label that is there to be found rather than read from across the room
    readonly property color text: "#f4f4f7"
    readonly property color dim: "#9a9aa8"
    readonly property color faint: "#6b6b7a"

    // the accent. `accentBright` is for the moment something is chosen, `accentDeep` for the
    // quiet end of a gradient, and `accent` is everything else
    readonly property color accent: "#e0a13c"
    readonly property color accentBright: "#f4c069"
    readonly property color accentDeep: "#9a6516"

    // state, used sparingly: a battery that is nearly empty, an install that failed
    readonly property color good: "#63c07a"
    readonly property color warn: "#e0a13c"
    readonly property color bad: "#e06c5a"

    // the shade the dashboard dims itself with when the overlay is open over it. The overlay over
    // an application has no dim: what it is covering is the thing the person wants to see
    readonly property color shade: "#000000"

    // --- geometry that the artwork decides ----------------------------------
    //
    // The tile art `scripts/generate-artwork.py` draws is a rounded rectangle with its corners
    // cut out, and the interface draws a rounded rectangle behind it. When the two radii do not
    // match, the corners do not either, and the dark background shows through them: each tile
    // gets four little dark wedges and the focus ring around a focused tile looks square against
    // a round picture. Measured on the shipped art, the corners were three and a half times
    // rounder than the tile behind them, which is a wedge about seventeen pixels across.
    //
    // So this is not a taste in rounding, it is the artwork's own number. `RADIUS / WIDTH` in
    // `scripts/generate-artwork.py`, expressed as a fraction of the tile's width so that it holds
    // at the shelf's size and the grid's alike. `tests/check-tile-geometry.sh` reads both files
    // and fails if somebody changes one without the other, because the failure mode is a picture
    // that looks slightly wrong rather than anything that stops.
    readonly property real artworkRadiusFraction: 56 / 384

    // the artwork's proportions, for the same reason: 384 by 512 is 3:4, which is the shape of a
    // game's box, and a tile drawn at any other ratio letterboxes the art inside it
    readonly property real artworkAspect: 384 / 512
}
