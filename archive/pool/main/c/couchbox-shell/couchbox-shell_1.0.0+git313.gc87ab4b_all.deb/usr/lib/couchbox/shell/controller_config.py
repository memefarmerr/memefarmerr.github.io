"""the controller's own preferences, and where they are kept.

Two settings exist because they are the two that make a controller usable on a machine that was
not built for it: the button that means yes, which is A on an Xbox controller and B on a Nintendo
one, and whether the shoulder buttons move forwards or backwards through a screen.

They live in a small file in the user's configuration directory rather than in anything more
clever, because everything in this project that survives a reboot is a file a person can read,
edit or delete. The path is Couchbox's own, so removing one directory puts a machine back to the
defaults written below.

Nothing here imports a toolkit. The settings application writes this file, the dashboard's input
layer reads it, and a machine with no display at all can still be checked: `tests/check-controller-config.sh`
loads this module by path and exercises it.

The file is tolerated rather than trusted: an unreadable, truncated or half-written file reads as
the defaults, because the alternative is an input layer that refuses to start because a comment
lost its newline. A value that is not one of the choices is the default as well, and is said so in
the log rather than silently used.
"""

from __future__ import annotations

import logging
import os
import tempfile
import time
from pathlib import Path

log = logging.getLogger("couchbox.controller-config")

# what each setting may be. Anything else is the default, and the first entry is the default
CHOICES: dict[str, tuple[str, ...]] = {
    "confirm": ("a", "b"),
    "bumpers": ("normal", "swapped"),
}

DEFAULTS: dict[str, str] = {name: values[0] for name, values in CHOICES.items()}

# how long a read is trusted. The input layer asks on the way to every button press, which is a
# handful of times a second at most, and the settings application writes the file at the moment
# somebody changes something. A second is short enough that a change feels immediate and long
# enough that the disk is not asked once per poll
CACHE_SECONDS = 1.0

_cache: tuple[float, dict[str, str]] | None = None


def config_directory() -> Path:
    """where a person's Couchbox settings live, the same place for every user."""
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(base) / "couchbox"


def config_path() -> Path:
    return config_directory() / "controller.conf"


def read_settings() -> dict[str, str]:
    """the settings on disk, with anything missing or unusable filled in from the defaults."""
    settings = dict(DEFAULTS)
    try:
        text = config_path().read_text(encoding="utf-8")
    except FileNotFoundError:
        return settings
    except OSError as error:
        log.warning("could not read %s (%s), so the defaults are used", config_path(), error)
        return settings

    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        name, _, value = stripped.partition("=")
        # the name is lowercased as well as the value, because this file is one a person can open
        # and edit and there is nothing an uppercase name could usefully mean
        name = name.strip().lower()
        value = value.strip().lower()
        if name not in CHOICES:
            log.info("ignoring the unknown controller setting '%s'", name)
            continue
        if value not in CHOICES[name]:
            log.warning(
                "'%s' is not one of %s for '%s', so %s is used",
                value,
                ", ".join(CHOICES[name]),
                name,
                DEFAULTS[name],
            )
            continue
        settings[name] = value
    return settings


def settings(max_age: float = CACHE_SECONDS) -> dict[str, str]:
    """the settings, reusing a read that is less than `max_age` old.

    This is what the input layer calls, and the cache is here rather than in that layer so that
    there is exactly one answer to "what are the settings" in the process.
    """
    global _cache
    now = time.monotonic()
    if _cache is not None and now - _cache[0] < max_age:
        return _cache[1]
    value = read_settings()
    _cache = (now, value)
    return value


def write_settings(settings_wanted: dict[str, str]) -> None:
    """write the settings, keeping the file readable and the write atomic.

    Only the known settings are written, values are checked against the choices, and the file is
    written beside itself and moved into place, so a machine that loses power in the middle has
    the old file rather than half of a new one.
    """
    lines = [
        "# written by the Couchbox settings application.",
        "#",
        "# confirm: which button means yes. 'a' is the Xbox and PlayStation layout, 'b' is the",
        "#          Nintendo one, where the right-hand button is the one that confirms.",
        "# bumpers: 'normal' or 'swapped', which way the shoulder buttons move through a screen.",
    ]
    for name in sorted(CHOICES):
        value = str(settings_wanted.get(name, DEFAULTS[name])).strip().lower()
        if value not in CHOICES[name]:
            log.warning("'%s' is not one of %s, so %s is written", value, CHOICES[name], DEFAULTS[name])
            value = DEFAULTS[name]
        lines.append(f"{name} = {value}")

    directory = config_directory()
    directory.mkdir(parents=True, exist_ok=True)
    handle, temporary = tempfile.mkstemp(prefix="controller-", dir=directory)
    try:
        with os.fdopen(handle, "w", encoding="utf-8") as out:
            out.write("\n".join(lines) + "\n")
        os.replace(temporary, config_path())
    except OSError:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise

    global _cache
    _cache = None
    log.info("wrote %s", config_path())
