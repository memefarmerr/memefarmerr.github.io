"""what the machine is doing, for a dashboard that has to say so from a couch.

A console's home screen always answers three questions without being asked: what
time it is, how much battery is left, and whether there is a network. This module
is the whole of where those answers come from. It is deliberately separate from
`ui.py`, which is about windows and processes, because this is about reading
files and running two small tools and it can be tested on its own.

Three rules shape everything here:

  * **it never blocks and it never grows.** Every reading is either a file read or
    a command with a hard timeout, and a reading that fails returns "unknown"
    rather than raising. A dashboard that cannot start because a battery file was
    missing is a broken machine, and the person in front of it has a controller
    and no keyboard.
  * **it is cheap enough to poll.** The dashboard is idle most of the time on
    hardware from 2012, so the file reads here cost microseconds and the two
    commands (nmcli and wpctl, or their fallbacks) are run on a slow timer and
    only while the dashboard is actually on screen.
  * **it says nothing it does not know.** A desktop with no battery reports no
    battery rather than 0%, and a machine with no audio server reports no volume
    rather than a mute button that does nothing. The interface drops what it is
    not given, which is why every reading is `None`-able.

Nothing here is Couchbox-specific: it is the machine's own state, read the way
Debian already publishes it (`/sys/class/power_supply`, `/proc/net/route`,
`/sys/class/net`), with the two audio tools the project already depends on
(PipeWire's `wpctl`, or PulseAudio's `pactl`).
"""

from __future__ import annotations

import logging
import os
import pwd
import re
import shutil
import subprocess
from pathlib import Path

log = logging.getLogger("couchbox.shell.systeminfo")

# how long a tool is given before it is abandoned. These commands answer in
# milliseconds on a working machine and hang when the service behind them is not
# running, and a hung poll would freeze the interface rather than the poll
COMMAND_TIMEOUT = 2.0

POWER_SUPPLY = Path("/sys/class/power_supply")
NET_CLASS = Path("/sys/class/net")
PROC_ROUTE = Path("/proc/net/route")
VERSION_FILE = Path("/usr/share/couchbox/version")

# where the dashboard's own pictures live: the wordmark, the light behind the focused tile, and
# the fallback background. Overridable so a checkout can be looked at without installing
# anything, which is how scripts/vm/verify-shell.sh photographs the interface from a tree.
ARTWORK_DIR = Path(
    os.environ.get("COUCHBOX_ARTWORK_DIR") or "/usr/share/couchbox/artwork"
)

# where the small interface glyphs live: the network, battery and volume marks, and the two that
# label the shelf and grid buttons. They are separate from the tile art because they are drawn in
# the text colour and are not a launcher's picture.
ICON_DIR = Path(
    os.environ.get("COUCHBOX_ICON_DIR") or "/usr/share/couchbox/icons"
)


def artwork(name: str) -> str:
    """one of the dashboard's own pictures as something a Qt image can load, or "".

    `file://` is prepended for the reason `entries.Entry.artwork` explains: a bare absolute path
    is a relative URL to QML and resolves to nothing. Empty when the file is not there, so the
    interface can drop the element instead of drawing a broken image.
    """
    path = ARTWORK_DIR / name
    return f"file://{path}" if path.is_file() else ""


def icon(name: str) -> str:
    """one interface glyph by its path under the icon directory, or "" when it is missing."""
    path = ICON_DIR / name
    return f"file://{path}" if path.is_file() else ""


def _run(command: list[str]) -> str | None:
    """run a command and return its output, or None if it could not be run.

    Never raises. A missing tool and a tool that hangs are the same thing to the
    caller: this machine cannot answer that question right now.
    """
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=COMMAND_TIMEOUT,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    return result.stdout


def which(name: str) -> str | None:
    """where a tool is, or None. Asked once per name by the caller that caches it."""
    return shutil.which(name)


# --- the battery -------------------------------------------------------------


def battery() -> tuple[int, bool] | None:
    """(percent, charging) for the first battery, or None on a machine without one.

    A desktop is not a broken laptop, so the absence of a battery is an ordinary
    answer and the interface shows nothing. A laptop whose battery reports a
    status this does not know is still shown, with the level and no plug.
    """
    try:
        supplies = sorted(path for path in POWER_SUPPLY.iterdir() if path.name.startswith("BAT"))
    except OSError:
        return None

    for supply in supplies:
        try:
            raw = (supply / "capacity").read_text(encoding="utf-8").strip()
            percent = int(raw)
        except (OSError, ValueError):
            continue
        try:
            status = (supply / "status").read_text(encoding="utf-8").strip().lower()
        except OSError:
            status = ""
        # "Full" is on the mains as far as a person is concerned, and a laptop
        # held at 100% by the charger should not show a plug that is not there
        charging = status in ("charging", "full")
        return max(0, min(100, percent)), charging
    return None


# --- the network -------------------------------------------------------------


def _default_interface() -> str | None:
    """the interface carrying the default route, read from the kernel.

    Read from `/proc/net/route` rather than asked of NetworkManager, because this
    has to be cheap enough to poll and because it is the kernel's own answer to
    "is anything actually reachable", which is the question the indicator asks.
    """
    try:
        lines = PROC_ROUTE.read_text(encoding="utf-8").splitlines()
    except OSError:
        return None
    for line in lines[1:]:
        fields = line.split()
        # Iface Destination Gateway Flags ... ; a default route has destination 0.0.0.0,
        # which the kernel prints as 00000000, and the route has to be up (flag 0x1)
        if len(fields) < 4:
            continue
        interface, destination, _gateway, flags = fields[0], fields[1], fields[2], fields[3]
        if destination != "00000000":
            continue
        try:
            if not int(flags, 16) & 0x1:
                continue
        except ValueError:
            continue
        return interface
    return None


def _wireless(interface: str) -> bool:
    try:
        return (NET_CLASS / interface / "wireless").exists()
    except OSError:
        return False


def connection_name() -> str:
    """the name of the network in use, in words a person recognises, or "".

    NetworkManager knows the name a person gave a network ("Home wi-fi") and the
    kernel does not, so it is asked first and the interface name is the fallback.
    That way the indicator is useful on a machine running NetworkManager, which is
    every machine this project ships, and still answers on one where nmcli is
    missing or the service is down.
    """
    interface = _default_interface()
    if interface is None:
        return ""

    nmcli = which("nmcli")
    if nmcli is not None:
        output = _run([nmcli, "-t", "-f", "NAME,DEVICE", "connection", "show", "--active"])
        if output:
            for line in output.splitlines():
                # -t is colon separated and escapes a colon inside a value as \:
                fields = re.split(r"(?<!\\):", line)
                if len(fields) >= 2 and fields[1].strip() == interface and fields[0].strip():
                    name = fields[0].replace("\\:", ":").strip()
                    if name:
                        return name
    if _wireless(interface):
        return "Wi-fi"
    return "Wired"


def network_kind() -> str:
    """one of "wifi", "wired", or "" when there is no default route."""
    interface = _default_interface()
    if interface is None:
        return ""
    return "wifi" if _wireless(interface) else "wired"


def network_available() -> bool:
    """is there anything to join a network with, whatever the state of the link."""
    try:
        return any(
            path.name != "lo" and not path.name.startswith(("virbr", "docker", "veth", "br-"))
            for path in NET_CLASS.iterdir()
        )
    except OSError:
        return False


# --- the volume --------------------------------------------------------------


def _wpctl() -> str | None:
    return which("wpctl")


def _pactl() -> str | None:
    return which("pactl")


def audio_available() -> bool:
    return _wpctl() is not None or _pactl() is not None


def volume() -> tuple[int, bool] | None:
    """(percent, muted) for the default sink, or None when there is no answer.

    PipeWire's `wpctl` first, then PulseAudio's `pactl`, because the image ships
    PipeWire and a machine where the person replaced it should still show a
    volume. Neither is required: a machine with no audio stack shows no volume
    rather than a control that does nothing.
    """
    wpctl = _wpctl()
    if wpctl is not None:
        output = _run([wpctl, "get-volume", "@DEFAULT_AUDIO_SINK@"])
        if output:
            match = re.search(r"Volume:\s*([0-9.]+)", output)
            if match:
                try:
                    percent = int(round(float(match.group(1)) * 100))
                except ValueError:
                    percent = 0
                # wpctl prints "[MUTED]" beside the level when the sink is muted,
                # and prints nothing at all when there is no default sink
                return max(0, min(100, percent)), "MUTED" in output.upper()
        return None

    pactl = _pactl()
    if pactl is not None:
        output = _run([pactl, "get-sink-volume", "@DEFAULT_SINK@"])
        if output:
            match = re.search(r"(\d+)%", output)
            if match:
                percent = int(match.group(1))
                muted = "yes" in (_run([pactl, "get-sink-mute", "@DEFAULT_SINK@"]) or "").lower()
                return max(0, min(100, percent)), muted
    return None


def volume_step(percent: int) -> tuple[bool, str]:
    """turn the volume up or down. Returns (it worked, what went wrong).

    Turning it up stops at full volume. PipeWire can go past it, which is amplification rather than
    volume, and every surface of this interface speaks in percent: the bar cannot draw more than its
    own width and the chip would read 100 while the sound kept rising. So the cap is here, where one
    reading serves all of them, rather than in each of the four places that draw a number.
    """
    if percent > 0:
        current = volume()
        if current is not None and current[0] >= 100:
            return (True, "")
    step = f"{abs(percent)}%{'+' if percent >= 0 else '-'}"
    wpctl = _wpctl()
    if wpctl is not None:
        output = _run([wpctl, "set-volume", "@DEFAULT_AUDIO_SINK@", step])
        return (output is not None, "" if output is not None else "PipeWire did not answer")
    pactl = _pactl()
    if pactl is not None:
        sign = "+" if percent >= 0 else "-"
        output = _run([pactl, "set-sink-volume", "@DEFAULT_SINK@", f"{sign}{abs(percent)}%"])
        return (output is not None, "" if output is not None else "PulseAudio did not answer")
    return (False, "there is no volume control on this machine")


def toggle_mute() -> tuple[bool, str]:
    """mute or unmute the default sink. Returns (it worked, what went wrong)."""
    wpctl = _wpctl()
    if wpctl is not None:
        output = _run([wpctl, "set-mute", "@DEFAULT_AUDIO_SINK@", "toggle"])
        return (output is not None, "" if output is not None else "PipeWire did not answer")
    pactl = _pactl()
    if pactl is not None:
        output = _run([pactl, "set-sink-mute", "@DEFAULT_SINK@", "toggle"])
        return (output is not None, "" if output is not None else "PulseAudio did not answer")
    return (False, "there is no volume control on this machine")


# --- the machine's own name --------------------------------------------------


def profile_name() -> str:
    """what to call the person using this machine, for the chip in the corner.

    The full name from the account when there is one, because a console profile is
    a name rather than a login, and the login itself when there is not. This is a
    display string and nothing decides anything by it.
    """
    try:
        account = pwd.getpwuid(os.getuid())
    except (KeyError, OSError):
        return os.environ.get("USER", "")
    full = (account.pw_gecos or "").split(",")[0].strip()
    return full or account.pw_name


def friendly_version(text: str) -> str:
    """an apt version as something to put on a television.

    `1.0.0+git196.gb5bd740` is what apt compares and what a bug report needs, and it is not a thing
    to show somebody who asked what version they are on. The interesting part is that it is 1.0.0
    and that it is build 196; the rest is a commit hash, and it belongs in the log rather than on
    the screen. Reported as "the version needs to be simplified ... to something nicer".
    """
    base, separator, build = text.partition("+git")
    if not separator:
        return text
    count = build.split(".", 1)[0]
    return f"{base} (build {count})" if count.isdigit() else base


def version() -> str:
    """the version of Couchbox OS this machine is running, or "" when unknown."""
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return ""
