"""the Qt side of the Couchbox dashboard: the window, and starting things.

Separated from couchbox-shell so that the entry point can answer --check without a
GUI toolkit installed. Nothing else in the project depends on this module.

The shape is small on purpose. QML gets the entries and two slots and owns its own
navigation state, because a view that has to ask Python where the focus is produces
a round trip for something the view already knew.
"""

from __future__ import annotations

import dataclasses
import logging
import os
import signal
import sys
import time
from pathlib import Path

from PySide6.QtCore import (
    Property,
    QCoreApplication,
    QEvent,
    QObject,
    QProcess,
    Qt,
    QTimer,
    QUrl,
    Signal,
    Slot,
)
from PySide6.QtGui import QGuiApplication, QKeyEvent
from PySide6.QtQml import QQmlApplicationEngine, qmlRegisterSingletonInstance

import entries as entry_model
import gamepad as gamepad_input
import hotkey as hotkey_input
import recent as recent_model

# the catalogue and the question "is this application on the machine". They live in the parent
# directory because the store's own command line and its application read them too: one catalogue,
# one parser, one answer (ADR-0026), and this is the third reader of it
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

try:
    import catalog as catalog_model
    import store as store_model
except ImportError as error:  # pragma: no cover - a broken image
    catalog_model = None
    store_model = None
    # spelled out rather than through the module's own logger, which is defined below this point
    logging.getLogger("couchbox.shell").warning(
        "the catalogue is not available, so entries cannot be checked against it: %s", error
    )

log = logging.getLogger("couchbox.shell")

# where this directory is, so the QML beside it is found without a build step
HERE = Path(__file__).resolve().parent

# the program that gives an application a process group of its own.
#
# Pausing an application has to stop what the application started as well, or a wrapper that
# starts a game and waits for it would leave the game drawing behind the overlay while the
# wrapper is the thing that stopped. QProcess can do this in C++ through
# setChildProcessModifier, and that setter is **not bound in PySide6** while the signal that
# reports it failing is, which is the worst of both: the design looks supported, the attribute
# check that looks like it covers the case reports a signal rather than a method, and the
# process everything depends on then never becomes a group leader. That was measured rather
# than reasoned about, by asking a running application what its group was.
#
# So the application is started through setsid instead. It is util-linux, it is essential in
# Debian, and it does not fork when the process calling it is not already a group leader,
# which is this case: the pid QProcess watches stays the pid of the application itself, which
# is what the launcher rules depend on. A machine that somehow lacks it still starts
# applications and still pauses them, one process at a time, and says so in the log.
SETSID = next(
    (path for path in ("/usr/bin/setsid", "/bin/setsid") if os.access(path, os.X_OK)),
    None,
)

# how long after one guide word a second one is still the same press. A keyboard reaches the
# dashboard twice, once from the guide reading the devices and once from the window manager
# claiming the key, and the two arrive within milliseconds of each other. Nobody presses a key
# twice in this window on purpose
GUIDE_REPEAT_SECONDS = 0.3

# how long an application is given to stop when it is asked to, before it is made to. Four
# seconds is longer than a program that handles the request needs and shorter than a person
# pressing a key twice and deciding it does not work
STOP_GRACE_MS = 4000


class Shell(QObject):
    """everything QML is allowed to know about."""

    collectionsChanged = Signal()
    statusChanged = Signal()
    overlayChanged = Signal()
    recentChanged = Signal()
    # whether an application is running, which the overlay reads to decide which rows make
    # sense. separate from the overlay's own signal because the two change at different
    # moments and a row that says "resume" while nothing is running is worse than no row
    runningChanged = Signal()

    # where a paused application's process group is written, so that a dashboard which
    # dies while something is paused can be recovered from. See _pause_application.
    PAUSED_MARKER = "couchbox-paused"

    def __init__(self, windowed: bool = False, size: tuple[int, int] | None = None):
        super().__init__()
        self._windowed = windowed
        # the size to lay out. in fullscreen the window manager sizes the window and
        # this is not used, but the layout is a function of the window size, so in a
        # window this reproduces any screen exactly. 1280x720 is the reference.
        self._size = size if size is not None else (1280, 720)
        self._collections: list[entry_model.Collection] = []
        self._status = ""
        self._process: QProcess | None = None
        self._window = None
        self._gamepad: gamepad_input.Gamepad | None = None
        self._hotkeys: hotkey_input.HotkeyServer | None = None
        self._overlay = False
        # whether the application, rather than the dashboard, is the thing on screen.
        # the guide key means "let me out" when it is and "let me back in" when it is not,
        # so the two cases have to be told apart
        self._application_in_front = False
        # the process group of an application that has been stopped, or None. never a
        # single pid: stopping one process of a wrapper that started something else
        # leaves the thing the user is looking at running
        self._paused_group: int | None = None
        # whether an application can be given a process group of its own, which is what makes
        # pausing it mean pausing everything it started
        self._own_group = SETSID is not None
        # the name of what is running, so that a line of text can name it rather than
        # say "something"
        self._running_entry_name = ""
        # when the last guide word arrived, so that the same press arriving twice is one press
        self._last_guide = 0.0
        self._recent = recent_model.load()
        self.reload()
        if not self._own_group:
            log.warning(
                "setsid is missing, so pausing an application stops only its own process. "
                "a wrapper that starts something else will leave that something on screen"
            )

    # --- what QML reads ------------------------------------------------------

    @Property("QVariantList", notify=collectionsChanged)
    def collections(self):
        return [collection.as_dict() for collection in self._collections]

    @Property(str, notify=statusChanged)
    def status(self):
        """a line of text for the user when there is something to say.

        Empty the rest of the time, so the interface shows nothing rather than an
        empty box with a border around it.
        """
        return self._status

    @Property(bool, constant=True)
    def windowed(self):
        return self._windowed

    @Property(bool, notify=overlayChanged)
    def overlayOpen(self):
        """is the overlay the thing on screen.

        The overlay is the dashboard raised over a running application rather than a second
        interface, so this is a state of the same window and not a second window. QML draws
        the panel when it is true and nothing at all when it is false.
        """
        return self._overlay

    @Property("QVariantList", notify=recentChanged)
    def recent(self):
        """the applications this machine has started, most recent first.

        Read by the overlay, which offers them as a way back to something. It is a list of
        launchers rather than of positions, so reorganising a collection does not break it.
        """
        return [item.as_dict() for item in self._recent]

    @Property(bool, notify=runningChanged)
    def applicationRunning(self):
        return self._process is not None

    @Property(str, notify=runningChanged)
    def runningName(self):
        """what is running, for a row that has to name it rather than say "the application".

        Empty when nothing is running, so the interface can tell the two states apart rather than
        showing a row that stops nothing.
        """
        return self._running_name() if self._process is not None else ""

    @Property(int, constant=True)
    def windowWidth(self):
        """the width to lay out. the window manager overrides this when fullscreen."""
        return self._size[0]

    @Property(int, constant=True)
    def windowHeight(self):
        """the height to lay out. everything else in the layout scales from this."""
        return self._size[1]

    # --- what QML calls -----------------------------------------------------

    @Slot()
    def reload(self):
        """read the collections again.

        Called at start and available from the interface, because the alternative is
        restarting the dashboard to pick up a file that changed.
        """
        self._collections = self._installed_only(entry_model.load())
        log.info(
            "loaded %d collection(s): %s",
            len(self._collections),
            ", ".join(
                f"{collection.name}({len(collection.entries)})" for collection in self._collections
            )
            or "none",
        )
        self.collectionsChanged.emit()

    def _installed_only(self, collections):
        """drop the entries whose application is not on this machine.

        An entry that names a catalogue id is shown only while that application is installed,
        because that is the rule the whole store turns on: something that is not installed is not
        on the dashboard at all, rather than a tile that explains that it could be. An entry with no
        catalogue id is shown as it always was, which is what leaves the wrappers the image ships
        (the test entry, the power actions) alone.

        If the catalogue cannot be read, nothing is hidden. A dashboard that shows an entry it should
        not is a small fault the store can correct in a moment; a dashboard that shows nothing at all
        because a file went missing is the machine looking broken, which is much worse.
        """
        keep: set[str] | None = None

        if catalog_model is not None and store_model is not None:
            try:
                keep = {
                    entry.id for entry in catalog_model.load() if store_model.installed(entry)
                }
            except Exception as error:  # the catalogue is unreadable, or dpkg cannot be asked
                log.warning("entries were not filtered against the catalogue: %s", error)
                keep = None

        if keep is None:
            return collections

        kept = []
        for collection in collections:
            entries = tuple(
                entry for entry in collection.entries if not entry.catalogue or entry.catalogue in keep
            )
            if entries:
                kept.append(dataclasses.replace(collection, entries=entries))
            else:
                log.info("collection %s has nothing installed in it, so it is not shown", collection.name)
        return tuple(kept)

    @Slot(int, int)
    def launch(self, collection_index: int, entry_index: int):
        """start the entry at those positions.

        Whatever the application does, the user ends up back at the dashboard. The
        cases that matter are the ones where that is not automatic: an application
        that crashes, one that forks and leaves children behind, and one that never
        exits at all. This handles the first two by watching the process rather than
        by assuming, and leaves the third to the session, which is what owns the
        restart policy.
        """
        if self._process is not None:
            log.warning("something is already running, so nothing else will be started")
            # saying nothing here is a press that appears to do nothing, which is the one
            # thing an interface must not do. The guide key is the way back to what is
            # running, and until the shelf can show that itself this line is how the user
            # finds out (docs/tasks.md, m3-23)
            self._set_status(f"{self._running_name()} is still running. Press the guide key to go back")
            return

        entry = self._entry_at(collection_index, entry_index)
        if entry is None:
            return
        if not entry.exists():
            self._set_status(f"{entry.name} is not available on this machine")
            return

        self._set_status("")
        self._start(entry, hide=True)

    @Slot(int)
    def launchRecent(self, index: int):
        """start one of the applications from the recent list again.

        It is looked up by launcher rather than remembered as a position, so a collection that
        has been reorganised, renamed or removed since still works as long as the wrapper is
        there. A launcher that has gone is reported rather than silently doing nothing.
        """
        if not 0 <= index < len(self._recent):
            log.error("there is no recent application at %d", index)
            return
        wanted = self._recent[index]
        for collection_index, collection in enumerate(self._collections):
            for entry_index, entry in enumerate(collection.entries):
                if entry.launcher == wanted.launcher:
                    self.launch(collection_index, entry_index)
                    return
        log.warning("the recent application '%s' is not in any collection any more", wanted.name)
        self._set_status(f"{wanted.name} is no longer listed anywhere")

    @Slot(int, int)
    def runSystemAction(self, collection_index: int, entry_index: int):
        """run a system action from the overlay, leaving a running application as it is.

        The power actions sleep, restart or switch the machine off while a game is
        running. None of those should end the game or un-pause it: somebody who put the
        machine to sleep in the middle of a game expects to wake up to the dashboard with
        the game still there, and somebody who restarted has lost it either way. So the
        application is left exactly as the overlay left it, and the dashboard stays in
        front, because putting a game back on screen while a shutdown is happening is the
        wrong thing to show.
        """
        entry = self._entry_at(collection_index, entry_index)
        if entry is None:
            return
        if not entry.system:
            # an application started over another application is two things fighting for
            # one screen, which is never what the press meant
            log.warning("'%s' is not a system action, so the overlay will not run it", entry.name)
            return
        if not entry.exists():
            self._set_status(f"{entry.name} is not available on this machine")
            return

        self._set_status("")
        self._set_overlay(False)
        self._start(entry, hide=False)

    def _entry_at(self, collection_index: int, entry_index: int):
        """the entry at those positions, or None with the reason written to the log."""
        if not 0 <= collection_index < len(self._collections):
            log.error("there is no collection at %d", collection_index)
            return None
        collection = self._collections[collection_index]
        if not 0 <= entry_index < len(collection.entries):
            log.error("there is no entry at %d in '%s'", entry_index, collection.name)
            return None
        return collection.entries[entry_index]

    def _start(self, entry, hide: bool) -> None:
        """start an entry, either in front of the dashboard or behind it."""
        log.info(
            "starting '%s' with %s%s",
            entry.name,
            entry.path,
            # the path is the wrapper either way, and saying that setsid is in front of it is
            # the difference between "the pid here is the application" and a mystery
            " (through setsid, in its own process group)" if self._own_group else "",
        )
        self._running_entry_name = entry.name
        self._process = QProcess(self)
        if self._own_group:
            self._process.setProgram(SETSID)
            self._process.setArguments([entry.path])
        else:
            self._process.setProgram(entry.path)
        # recorded before it is started, so that an application which crashes immediately is
        # still in the list of what this machine tried to run, which is more useful than a
        # list that only holds the ones that worked
        self._recent = recent_model.note(entry.launcher, entry.name)
        self.recentChanged.emit()
        self.runningChanged.emit()
        # the wrapper's own output is forwarded to the dashboard's log rather than
        # going into a pipe nobody reads, because a wrapper that fails silently is
        # the exact failure this project keeps having to design against
        self._process.setProcessChannelMode(QProcess.ProcessChannelMode.ForwardedChannels)
        self._process.finished.connect(self._on_finished)
        self._process.errorOccurred.connect(self._on_failed)

        # the dashboard gets out of the way. it stays running, because it has to be
        # there to come back to and it is what owns the overlay, but it stops
        # drawing, which is what keeps its cost at nothing while a game runs.
        if hide:
            if self._window is not None and not self._windowed:
                self._window.hide()
            self._application_in_front = True

        self._process.start()

    @Slot()
    def resumeApplication(self):
        """put the application back in front of the dashboard, and let it run again."""
        if self._process is None:
            return
        self._set_overlay(False)
        self._resume_application()
        if self._window is not None and not self._windowed:
            self._window.hide()
        self._application_in_front = True
        log.info("the application is back in front")

    @Slot()
    def closeOverlay(self):
        """close the overlay, and let go of anything it paused.

        With an application running this is the same as choosing resume, which is the one outcome
        a user can always expect from backing out of something. With nothing running it is only a
        state change, and that is what makes the overlay usable over the dashboard rather than
        only over an application. The second press of the guide key comes here rather than to
        resumeApplication, because that does nothing when nothing is running and the key would
        then open something it could not close.
        """
        if self._process is not None:
            self.resumeApplication()
            return
        self._set_overlay(False)
        log.info("the overlay closed over the dashboard")

    @Slot()
    def stopApplication(self):
        """stop the running application, and come back to the dashboard.

        What stopping means is the wrapper's to declare (ADR-0022), and a wrapper that declares
        nothing gets the safe reading: one process, stop it to leave. The declaration is not built
        yet, so that is what everything gets today, and Steam's own answer belongs in Steam's
        wrapper when it arrives rather than here.
        """
        if self._process is None:
            return
        group = int(self._process.processId())
        if group <= 0:
            log.warning("the application has no process to stop yet")
            return

        # an application the overlay paused cannot act on a signal until it runs again, so the
        # pause this process created is undone before it is asked to leave. Otherwise the request
        # would sit unread and the four seconds below would end in a signal it cannot ignore
        self._resume_application()
        self._set_status(f"Closing {self._running_name()}")
        log.info("asking '%s' to stop (process group %d)", self._running_name(), group)

        try:
            if self._own_group:
                os.killpg(group, signal.SIGTERM)
            else:
                os.kill(group, signal.SIGTERM)
        except ProcessLookupError:
            return
        except OSError as error:
            log.warning("could not ask '%s' to stop (%s)", self._running_name(), error)
            return

        # and if it is still there, it is made to stop. A program that ignores the request would
        # otherwise leave somebody pressing a key that appears to do nothing, which is the failure
        # this whole overlay exists to end
        QTimer.singleShot(STOP_GRACE_MS, lambda: self._insist(group))

    def _insist(self, group: int) -> None:
        """send the signal that cannot be ignored, if the application is still running."""
        if self._process is None:
            # it went away, which is what was asked of it
            return
        log.warning("'%s' did not stop when asked, so it is being killed", self._running_name())
        self._set_status(f"{self._running_name()} did not stop and is being forced to")
        try:
            if self._own_group:
                os.killpg(group, signal.SIGKILL)
            else:
                os.kill(group, signal.SIGKILL)
        except ProcessLookupError:
            return
        except OSError as error:
            log.error("could not stop '%s' (%s)", self._running_name(), error)

    @Slot()
    def showDashboard(self):
        """come back to the dashboard without stopping the application.

        The application keeps running, because that is the whole of what "leaves the
        application where it is" means, and the guide key is then the way back to it.
        """
        if self._process is None:
            return
        self._set_overlay(False)
        self._resume_application()
        self.showShell()
        log.info("the dashboard is in front and the application is still running")

    @Slot()
    def showShell(self):
        """bring the dashboard back to the front."""
        self._application_in_front = False
        if self._window is None:
            return
        if self._windowed:
            self._window.show()
        else:
            self._window.showFullScreen()
        self._window.raise_()

    @Slot()
    def quit(self):
        # nothing is left stopped. a stopped process whose dashboard has gone away is a
        # frozen screen with no way out of it, and quitting in front of one is the last
        # moment this can be undone
        self._resume_application()
        if self._hotkeys is not None:
            self._hotkeys.stop()
        QCoreApplication.quit()

    # --- the overlay ---------------------------------------------------------

    @Slot(str)
    def _on_guide(self, message: str) -> None:
        """one press of the guide key. what it means depends on what is on screen."""
        # the same press can arrive twice, and usually does: a keyboard gives the guide's word,
        # because it can read the devices, and the session's window manager gives its own word,
        # because it can claim the key from the display server. Either on its own is a working
        # hotkey; both together would open the overlay and shut it again. So a word that arrives
        # while the last one is still a moment old is the same press arriving twice, and is
        # ignored. The window is short enough that a person cannot press twice inside it
        now = time.monotonic()
        if now - self._last_guide < GUIDE_REPEAT_SECONDS:
            log.debug("ignoring a second %s within %.0f ms of the first", message,
                      GUIDE_REPEAT_SECONDS * 1000)
            return
        self._last_guide = now

        if self._overlay:
            # a second press closes what the first one opened. It has to be this and not
            # "resume the application", because the overlay also opens with nothing running: a
            # resume does nothing in that case, and a key that opens something it cannot close is
            # worse than a key that does nothing at all
            self.closeOverlay()
            return
        if self._process is None:
            # nothing is running, so nothing is raised and nothing is paused: the overlay opens
            # over the dashboard, which is where the recent applications and the power actions
            # are worth having. It used to do nothing at all here, on the grounds that an
            # overlay over nothing was pointless, and that was wrong twice over: it is also the
            # way to what was launched a moment ago, and doing nothing is the one thing a key
            # cannot be seen to do
            self.openOverlay(message)
            return
        if not self._application_in_front:
            # an application is running and the dashboard is already in front of it, so
            # the press means "take me back", which is what a console does and needs no
            # interface of its own
            log.info("guide key (%s): returning to the application that is still running", message)
            self.resumeApplication()
            return
        self.openOverlay(message)

    @Slot()
    def openOverlayFromDashboard(self) -> None:
        """open the overlay from the interface rather than from the hotkey.

        Two reasons this exists separately from the key the guide sends. The first is that the
        guide reads the input devices directly and a session that is not on this machine's own
        hardware never appears there: a remote desktop delivers its keys to X and not to evdev,
        so on a remote session the guide is blind and this is the only way in. The second is that
        pressing a key in the interface is the discoverable route for somebody who has never
        heard of a guide button.
        """
        if self._process is not None and not self._application_in_front and not self._overlay:
            # an application is running behind the dashboard, and the sensible reading of the
            # gesture there is still "take me back"
            self.resumeApplication()
            return
        self.openOverlay("the dashboard")

    def openOverlay(self, message: str = hotkey_input.MESSAGE_GUIDE) -> None:
        """raise the dashboard over the application, and stop it drawing.

        Pausing is the default (ADR-0022): the overlay is modal, and both it and the
        application are competing for the same very small amount of graphics. An application
        that would suffer from being frozen in the middle of a connection opts out by saying
        so in its wrapper, which is not built yet: everything gets the safe reading today.
        """
        if self._overlay:
            return
        log.info("showing the overlay after %s", message)
        self.showShell()
        self._pause_application()
        self._set_overlay(True)

    def _set_overlay(self, open_: bool) -> None:
        if open_ != self._overlay:
            self._overlay = open_
            self.overlayChanged.emit()

    # --- pausing, and the two ways it can go wrong ---------------------------

    def _pause_application(self) -> None:
        """stop the application drawing until the overlay is closed."""
        if self._paused_group is not None or self._process is None:
            return

        pid = int(self._process.processId())
        if pid <= 0:
            log.warning("the application has not started yet, so there is nothing to pause")
            return

        try:
            if self._own_group:
                os.killpg(pid, signal.SIGSTOP)
            else:
                os.kill(pid, signal.SIGSTOP)
        except ProcessLookupError:
            # it finished between the request and the signal, which is an ordinary thing
            # for a short application to do
            return
        except OSError as error:
            log.warning(
                "the application could not be paused (%s), so it keeps running behind "
                "the overlay, which is a supported outcome rather than a failure",
                error,
            )
            return

        self._paused_group = pid
        self._write_marker(pid)
        log.info("paused the application (process group %d) while the overlay is up", pid)

    def _resume_application(self) -> None:
        """let a stopped application run again."""
        if self._paused_group is None:
            return
        group = self._paused_group
        self._paused_group = None
        self._clear_marker()

        try:
            if self._own_group:
                os.killpg(group, signal.SIGCONT)
            else:
                os.kill(group, signal.SIGCONT)
        except ProcessLookupError:
            return
        except OSError as error:
            log.warning("the application could not be resumed (%s)", error)
            return
        log.info("resumed the application (process group %d)", group)

    def marker_path(self) -> str:
        """where a paused application is remembered.

        A stopped process stays stopped when the thing that stopped it goes away, and the
        user is then looking at a screen that does not move with no way out of it but the
        power button. This file is what lets the session undo that the next time it starts
        a dashboard, and couchbox-xsession is where that happens.
        """
        return os.path.join(os.environ.get("XDG_RUNTIME_DIR") or "/tmp", self.PAUSED_MARKER)

    def _write_marker(self, pid: int) -> None:
        try:
            with open(self.marker_path(), "w", encoding="utf-8") as handle:
                handle.write(f"{pid}\n")
        except OSError as error:
            log.warning("could not record the paused application (%s)", error)

    def _clear_marker(self) -> None:
        try:
            os.unlink(self.marker_path())
        except FileNotFoundError:
            pass
        except OSError as error:
            log.warning("could not remove the record of the paused application (%s)", error)

    # --- the process --------------------------------------------------------

    @Slot(int, QProcess.ExitStatus)
    def _on_finished(self, code: int, status):
        log.info("the application finished with exit code %d", code)
        self._cleanup_process()
        # the collections are read again on the way back, because the store's whole purpose is that
        # installing something puts a tile on this dashboard. Without this the entry would only
        # appear after the next restart or after the reload key, which reads as the install having
        # failed
        self.reload()
        self.showShell()

    @Slot(QProcess.ProcessError)
    def _on_failed(self, error):
        if self._process is not None:
            # a process that started and was then killed is a different thing from one that
            # never started, and the difference is the whole of a bug report. Both arrive
            # here as an error rather than as a normal exit, which is why they are told
            # apart here rather than left as one line saying neither.
            if error == QProcess.ProcessError.Crashed:
                log.error(
                    "the application was killed by signal %d (%s)",
                    self._process.exitCode(),
                    self._process.errorString(),
                )
            else:
                log.error("the application could not be started: %s", self._process.errorString())
        self._cleanup_process()
        self.showShell()

    def _cleanup_process(self) -> None:
        if self._process is not None:
            self._process.deleteLater()
            self._process = None
        self._running_entry_name = ""
        # an application that has finished is not paused, whatever happened to it
        self._paused_group = None
        self._clear_marker()
        self._set_overlay(False)
        self.overlayChanged.emit()
        self.runningChanged.emit()

    def _running_name(self) -> str:
        """what is running, for the one line of text that has to name it."""
        return self._running_entry_name or "an application"

    def _set_status(self, text: str) -> None:
        if text != self._status:
            self._status = text
            self.statusChanged.emit()

    # --- the pieces QML cannot reach on its own ------------------------------

    def attach_window(self, window) -> None:
        self._window = window

    def start_gamepad(self) -> None:
        self._gamepad = gamepad_input.Gamepad(self)
        self._gamepad.keyPressed.connect(self._on_gamepad_key)
        if not self._gamepad.start():
            log.info("continuing without a gamepad, which is a supported machine")

    def start_hotkeys(self) -> None:
        """begin listening for the guide key.

        Called once the interface is up rather than before it, so that a socket which
        cannot be created costs a line in the log instead of a screen that never appears.
        The dashboard is worth having without a hotkey, and a black screen is not.
        """
        self._hotkeys = hotkey_input.HotkeyServer(parent=self)
        self._hotkeys.pressed.connect(self._on_guide)
        self._hotkeys.start()

    @Slot(int)
    def _on_gamepad_key(self, key: int) -> None:
        """turn a controller button into a key press and give it to the window.

        This is the whole of the gamepad support as far as the interface is
        concerned. The QML sees the key and cannot tell whether a controller or a
        keyboard produced it, which is what makes both work everywhere, instead of
        in the places where somebody remembered to write two handlers.
        """
        if self._window is None:
            return
        for kind in (QEvent.Type.KeyPress, QEvent.Type.KeyRelease):
            QCoreApplication.sendEvent(
                self._window, QKeyEvent(kind, key, Qt.KeyboardModifier.NoModifier)
            )


def run(windowed: bool = False, size: tuple[int, int] | None = None) -> int:
    """start the dashboard. returns the process exit code."""
    application = QGuiApplication(sys.argv)
    application.setApplicationName("couchbox-shell")
    application.setDesktopFileName("couchbox-shell")

    shell = Shell(windowed=windowed, size=size)
    # a singleton rather than a context property, so that the QML declares what it
    # uses rather than picking a name out of the air
    qmlRegisterSingletonInstance(Shell, "Couchbox", 1, 0, "Shell", shell)

    engine = QQmlApplicationEngine()
    engine.addImportPath(str(HERE / "qml"))

    qml_file = HERE / "qml" / "dashboard.qml"
    engine.load(QUrl.fromLocalFile(str(qml_file)))
    if not engine.rootObjects():
        log.error("the dashboard did not load. the QML error above is the reason")
        return 1

    shell.attach_window(engine.rootObjects()[0])
    shell.start_gamepad()
    shell.start_hotkeys()

    return application.exec()
