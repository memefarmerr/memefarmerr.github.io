"""what the store's applications need to know about the machine.

The catalogue says what *could* be installed; this says what is on the machine, and it is the half
of the store that runs as a person rather than as root. Nothing here changes anything: installing is
the helper's job (ADR-0026), and this is what the interface asks before it draws a row.

It lives beside `catalog.py` rather than inside the dashboard, because three programs ask it the same
question: the store application, the store command line, and the dashboard itself, which uses it to
decide whether an entry's application is on the machine at all.

Two questions, and both of them are asked of the system rather than remembered:

  * is the application behind this entry installed, which is `dpkg-query` for a Debian package
  * which entries are in the catalogue at all, which is `catalog.load`, the same module the
    installer and the helper read

Progress and results are not here either. The helper prints as it goes and the interface shows what
it prints, because the alternative is two places that believe they know what apt is doing.
"""

from __future__ import annotations

import logging
import subprocess

import catalog

log = logging.getLogger("couchbox.store")

DPKG_QUERY = "/usr/bin/dpkg-query"

# what dpkg says about a package that is properly installed, and the only line worth matching. A
# package that was removed but not purged reports "deinstall ok config-files", and a package that
# failed half way says something else again: neither is installed, and both would be a lie to offer
# as such
INSTALLED_STATUS = "install ok installed"


def installed(entry: catalog.CatalogEntry) -> bool:
    """is the application behind this entry on the machine."""
    if not entry.apt:
        # a flatpak entry cannot be asked about yet, because the catalogue has none and this cannot
        # install one. Saying no is honest; guessing would put a row in the interface that lies
        return False
    try:
        result = subprocess.run(
            [DPKG_QUERY, "-W", "-f=${Status}", entry.apt],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as error:
        # a machine without dpkg-query is not a machine this can answer for, and saying "not
        # installed" is better than a traceback in a log on every redraw
        log.warning("could not ask dpkg about %s (%s)", entry.apt, error)
        return False
    return result.returncode == 0 and INSTALLED_STATUS in result.stdout


def listing() -> list[dict]:
    """the catalogue, each entry with whether it is installed.

    Returns what an interface draws, and raises CatalogError rather than returning a short list: a
    catalogue that half loads would put a store on screen that is quietly missing something.
    """
    return [
        {**entry.as_dict(), "installed": installed(entry)}
        for entry in catalog.load()
    ]
