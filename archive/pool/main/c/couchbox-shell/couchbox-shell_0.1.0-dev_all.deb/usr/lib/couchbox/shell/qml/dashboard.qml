import QtQuick
import QtQuick.Window
import Couchbox 1.0

// the Couchbox dashboard.
//
// written for a television at couch distance, driven by a controller or a keyboard.
// mouse input works because Qt gives it to us, but nothing here needs it and
// nothing here is reachable only with it.
//
// the shape of the screen is a console's: quiet section tabs along the top, one wide
// horizontal shelf of large tiles as the thing the screen is about, and a reserved band
// at the bottom holding the focused tile's name and description and whatever the machine
// has to say. the focused tile is larger, unshaded and ringed in the accent; the rest are
// smaller and shaded, so the eye reads the row as one shelf with one place in it.
//
// focus moves in two levels. left and right move along the shelf, up leaves the shelf for
// the tabs and down returns to it, and the shoulder buttons, which arrive as Tab and
// Backtab, change section from either level (ADR-0034). there is no second screen, so
// nothing can be hidden behind a navigation step and back cannot go somewhere unexpected.
//
// every tile is drawn at all times, focused or not. a shelf where only the focused
// entry is visible is not a shelf: it means reading the entries one at a time
// instead of seeing them, which is the wrong thing to ask of somebody on a couch
// six feet away.
//
// the background is a single static gradient, and there is no blur, no shader and
// nothing that redraws while the screen is idle. a ten foot interface invites
// movement, but this has to stay responsive on integrated graphics from around
// 2012, which is also why the shell must go completely quiet while an application
// is running in front of it.

Window {
    id: root

    visible: true
    // fullscreen is the product. windowed exists so the shell can be run in a
    // terminal on a development machine, which is how it gets worked on, and so that
    // a screen size this machine does not have can be laid out and looked at.
    visibility: Shell.windowed ? Window.Windowed : Window.FullScreen
    width: Shell.windowWidth
    height: Shell.windowHeight
    color: "#08080b"
    title: "Couchbox"

    // the palette, taken from the shared singleton so that the overlay window over an application
    // and this window cannot come out slightly different. These are the only colours in the
    // interface, so tuning the look happens in one place: shell/qml/ConsolePalette.qml
    ConsolePalette {
        id: colors
    }

    readonly property color colorBackgroundTop: colors.backgroundTop
    readonly property color colorBackground: colors.background
    readonly property color colorSurface: colors.surface
    readonly property color colorSurfaceFocused: colors.surfaceFocused
    readonly property color colorBorder: colors.border
    readonly property color colorText: colors.text
    readonly property color colorDim: colors.dim
    readonly property color colorAccent: colors.accent

    // the two colours a tile is drawn with when it is not the focused one: a shade over
    // the artwork, and the border it takes instead of the accent. both are animated, so
    // the difference between focused and not is something the eye follows rather than
    // something that changes between two frames.
    readonly property color colorShade: colors.shade
    readonly property real shadeOpacity: 0.35

    // motion. every duration in the interface comes from here, so the whole thing can be
    // slowed down or sped up in one place, and so that nothing accidentally runs long.
    //
    // these are deliberately short. This has to stay responsive on integrated graphics
    // from around 2012, and a transition that is felt as a delay is worse than no
    // transition at all. Nothing here is continuous: every one of them runs because
    // somebody pressed something and then stops.
    readonly property int motionFast: 120
    readonly property int motionBase: 180
    readonly property int motionSlow: 260

    // how much the focused tile grows. the ring goes around the tile and the whole thing
    // lifts together, so the growth is the visible difference between the focused tile and
    // the ones beside it, and the frame each tile lives in is sized for the lifted state.
    readonly property real tileScale: 1.08

    // one scale factor derived from the screen height drives everything, so the
    // layout stays proportional on both 1280x720 and 1920x1080, which are the two
    // target televisions.
    readonly property int unit: Math.max(10, Math.round(height / 72))

    // box artwork is portrait, so the tile takes the same shape and the artwork
    // fills it instead of floating in the middle of an unrelated rectangle. the tile is
    // large on purpose: the shelf is the primary element of the screen, not a strip of
    // thumbnails above a description.
    readonly property int tileWidth: unit * 16
    readonly property int tileHeight: unit * 24

    // the band at the bottom of the screen is reserved whether or not it has anything to
    // say, and this is its one fixed height. its contents cannot change it, so the shelf
    // above never moves when a status line or an install appears or goes away.
    readonly property int statusBandHeight: unit * 8

    // the focus ring is drawn around the tile so it never lands on the artwork, and it is
    // deliberately thick: it has to read from a couch, and a thin line disappears against
    // box art of almost any colour.
    readonly property int focusWidth: Math.max(3, Math.round(unit * 0.5))

    // the box the focus lifts: the tile and the ring together. the frame each tile lives in
    // is larger than this box, because scaling an item whose frame exactly fits it pushes
    // the ring at its edge outside the shelf's clip region. that was measured on the old
    // layout, where the ring came out two pixels thick at the top and bottom and five at
    // the sides.
    readonly property int focusBoxWidth: tileWidth + focusWidth * 2
    readonly property int focusBoxHeight: tileHeight + focusWidth * 2

    // the frame each tile gets, large enough for the lifted box with a hair to spare, and
    // how far apart two tiles sit, which is what the shelf scrolls by
    readonly property int tileFrameWidth: Math.ceil(focusBoxWidth * tileScale) + 2
    readonly property int tileFrameHeight: Math.ceil(focusBoxHeight * tileScale) + 2
    readonly property real itemPitch: tileFrameWidth + unit * 2

    // long lines are hard to read across a room, so the description is held to a
    // comfortable measure rather than the width of the screen
    readonly property int textWidth: Math.min(width - unit * 8, unit * 52)

    // --- the model ----------------------------------------------------------

    // re-reading on every change rather than holding a copy, because a stale copy
    // is a dashboard that disagrees with its own files
    readonly property var collectionsModel: Shell.collections

    property int collectionIndex: 0

    readonly property var currentCollection:
        collectionsModel.length > 0
            ? collectionsModel[Math.min(collectionIndex, collectionsModel.length - 1)]
            : null

    readonly property var currentEntries: currentCollection ? currentCollection.entries : []

    property int entryIndex: 0

    readonly property var focusedEntry:
        currentEntries.length > 0
            ? currentEntries[Math.min(entryIndex, currentEntries.length - 1)]
            : null

    readonly property bool hasAnything: collectionsModel.length > 0 && currentEntries.length > 0

    // the tabs only earn their space when there is more than one section to choose
    // between, so a machine with a single collection looks exactly like a machine
    // with one section rather than like a broken row of tabs
    readonly property bool showRail: collectionsModel.length > 1

    // the tabs are the only thing above the shelf, so a machine without them has no
    // second level for the focus to get lost in
    onShowRailChanged: {
        if (!showRail) {
            focusArea = "shelf";
        }
    }

    // a collection can arrive with fewer entries than the last one had, so the
    // cursor is brought back inside the model whenever the model changes
    onCollectionsModelChanged: {
        if (collectionIndex >= collectionsModel.length) {
            collectionIndex = 0;
        }
        entryIndex = 0;
    }

    onCurrentEntriesChanged: {
        if (entryIndex >= currentEntries.length) {
            entryIndex = 0;
        }
        root.detailChanged();
    }

    // the description is replaced when the entry changes, so it is asked to arrive
    // rather than to appear
    onEntryIndexChanged: root.detailChanged()

    // --- navigation ---------------------------------------------------------

    // which level has the keys: the shelf, which is where the interface lives, or the tabs
    // above it, which are reached with up and left alone with down. the tabs are not a
    // second screen: whatever moves there, the shelf below is already showing it.
    property string focusArea: "shelf"

    // the chosen section, and the one place a section change happens, so clicking a tab,
    // a shoulder button and an arrow at the end of the row all land in the same state
    function selectCollection(index) {
        if (collectionsModel.length === 0) {
            return;
        }
        // wrapping, so the ends of the row of tabs are not dead ends on a controller whose
        // shoulder buttons arrive as Tab and Backtab (ADR-0034)
        collectionIndex = ((index % collectionsModel.length) + collectionsModel.length) % collectionsModel.length;
        entryIndex = 0;
        // a section change replaces every tile at once, so this one is not animated:
        // sliding a row of tiles that no longer exist is a slide of nothing
        root.scrollShelf(false);
    }

    function moveSection(step) {
        if (collectionsModel.length < 2) {
            return;
        }
        root.selectCollection(collectionIndex + step);
    }

    function moveEntry(step) {
        if (currentEntries.length === 0) {
            return;
        }
        entryIndex = (entryIndex + step + currentEntries.length) % currentEntries.length;
        root.scrollShelf(true);
    }

    // The shelf is scrolled here rather than with positionViewAtIndex, because that
    // jumps: the focused tile is put in view at the speed of the next redraw, which
    // reads as the whole row teleporting under the focus ring. This puts the focused
    // tile in the middle of the row when there is room for it, stays inside the row at
    // both ends, and runs the move as one short animation.
    //
    // The clamping is the part that matters. Without it the first and last tiles would
    // be centred with empty row beside them, which looks like a shelf that has come off
    // its rails.
    function scrollShelf(animated) {
        const itemWidth = tileFrameWidth;
        const maxOffset = Math.max(0, shelf.contentWidth - shelf.width);
        const centred = entryIndex * itemPitch + itemWidth / 2 - shelf.width / 2;
        const target = Math.max(0, Math.min(centred, maxOffset));

        if (!animated) {
            shelfScroll.stop();
            shelf.contentX = target;
            return;
        }

        shelfScroll.to = target;
        shelfScroll.restart();
    }

    // The animations below are named in the interface and are started from here, and the
    // guards are not decoration: the model can change while the interface is still being
    // built, before the object that owns the animation exists, and a signal handler that
    // throws on the way up is a dashboard that does not start.
    function detailChanged() {
        if (captionSwap) {
            captionSwap.restart();
        }
    }

    function launchFocused() {
        if (focusedEntry) {
            Shell.launch(collectionIndex, entryIndex);
        }
    }

    // --- the screen ---------------------------------------------------------

    // three stops rather than two, so the light falls off towards the edges instead of
    // stepping from one colour to the other across a visible line
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: root.colorBackgroundTop }
            GradientStop { position: 0.45; color: root.colorBackground }
            GradientStop { position: 1.0; color: root.colorBackground }
        }
    }

    FocusScope {
        id: content
        anchors.fill: parent
        // the overlay takes the keyboard while it is up, so the shelf must not. one of the
        // two owns the keys at any moment, and it is never both
        focus: !Shell.overlayOpen

        // the interface comes up rather than switching on. It is one opacity ramp over
        // the whole screen, it runs once, and it covers the moment between the window
        // being mapped and the first frame being drawn.
        opacity: 0
        Component.onCompleted: appear.start()

        NumberAnimation {
            id: appear
            target: content
            property: "opacity"
            to: 1.0
            duration: root.motionSlow
            easing.type: Easing.OutCubic
        }

        // The fade is the one animation here whose failure would be worse than not having
        // it: an interface that fades up and never arrives is a black screen with a
        // working machine behind it. This puts the screen back unconditionally, and it is
        // harmless when the fade has worked, because by then it is setting the value the
        // fade has already reached.
        Timer {
            interval: root.motionSlow + 400
            running: true
            repeat: false
            onTriggered: content.opacity = 1
        }

        // one handler, because the gamepad arrives here as key events too. this is
        // why nothing in this file has to know whether a controller or a keyboard
        // is in use.
        Keys.onPressed: (event) => {
            switch (event.key) {
            case Qt.Key_Left:
                if (root.focusArea === "tabs") {
                    root.moveSection(-1);
                } else {
                    root.moveEntry(-1);
                }
                event.accepted = true;
                break;
            case Qt.Key_Right:
                if (root.focusArea === "tabs") {
                    root.moveSection(1);
                } else {
                    root.moveEntry(1);
                }
                event.accepted = true;
                break;
            case Qt.Key_Up:
                // up leaves the shelf for the tabs and nowhere else, because the tabs are
                // the only thing above the shelf
                if (root.showRail) {
                    root.focusArea = "tabs";
                }
                event.accepted = true;
                break;
            case Qt.Key_Down:
                root.focusArea = "shelf";
                event.accepted = true;
                break;
            // the shoulder buttons arrive as Tab and Backtab (ADR-0034), and this is where
            // they mean "another section", from either level, so moving between sections
            // never costs a trip back down through the shelf
            case Qt.Key_Tab:
                root.moveSection(1);
                event.accepted = true;
                break;
            case Qt.Key_Backtab:
                root.moveSection(-1);
                event.accepted = true;
                break;
            case Qt.Key_Return:
            case Qt.Key_Enter:
            case Qt.Key_Space:
                if (root.focusArea === "tabs") {
                    // the tab changed as the selection moved along the row, so activating
                    // one is only the trip back down to the shelf
                    root.focusArea = "shelf";
                } else {
                    root.launchFocused();
                }
                event.accepted = true;
                break;
            // the overlay, from the interface rather than from the hotkey. Super is the key
            // that means "the system" on a desktop keyboard, Menu is the key that exists for
            // exactly this and is what Start sends, and a controller's guide button arrives
            // through the hotkey rather than here. All of them also work through a remote
            // session, which the guide cannot: a remote desktop delivers its keys to X and
            // never to the input devices the guide reads (ADR-0034)
            //
            // Escape is deliberately not one of them any more. It means "back" everywhere
            // else in this machine, and the key that opens the overlay should not also be
            // the key everybody reaches for to leave a screen (ADR-0034)
            case Qt.Key_Menu:
            case Qt.Key_Meta:
            case Qt.Key_Super_L:
            case Qt.Key_Super_R:
                Shell.openOverlayFromDashboard();
                event.accepted = true;
                break;
            case Qt.Key_Q:
                if (event.modifiers & Qt.ControlModifier) {
                    Shell.quit();
                    event.accepted = true;
                }
                break;
            }
        }

        // --- the tabs ---

        // the sections, quiet: text with a short accent rule under the chosen one, and a
        // filled shape only while the focus is up here. that way the shelf stays the thing
        // the screen is about, and the moment up is pressed the tab level says so rather
        // than looking like a row that cannot be reached.
        Row {
            id: tabs
            visible: root.showRail
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: root.unit * 3
            anchors.bottomMargin: 0
            spacing: root.unit * 1.5

            Repeater {
                model: root.showRail ? root.collectionsModel : []

                delegate: Item {
                    id: tab

                    required property var modelData
                    required property int index

                    readonly property bool chosen: index === root.collectionIndex
                    readonly property bool tabFocused: root.focusArea === "tabs" && chosen

                    width: tabText.implicitWidth + root.unit * 2
                    height: root.unit * 2.6

                    Rectangle {
                        anchors.fill: parent
                        radius: root.unit * 0.6
                        color: tab.tabFocused ? root.colorSurfaceFocused : "transparent"
                        border.width: tab.tabFocused ? 1 : 0
                        border.color: root.colorAccent

                        Behavior on color {
                            ColorAnimation { duration: root.motionFast }
                        }
                    }

                    Text {
                        id: tabText
                        anchors.centerIn: parent
                        text: tab.modelData.name
                        color: tab.chosen ? root.colorText : root.colorDim
                        font.pixelSize: Math.round(root.unit * 1.2)
                        font.bold: tab.chosen

                        Behavior on color {
                            ColorAnimation { duration: root.motionFast }
                        }
                    }

                    // the quiet marker of the chosen tab while the focus is down on the
                    // shelf: a short accent rule, and nothing else
                    Rectangle {
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.bottom: parent.bottom
                        anchors.bottomMargin: root.unit * 0.25
                        width: tabText.width
                        height: Math.max(2, Math.round(root.unit * 0.18))
                        radius: height / 2
                        color: root.colorAccent
                        opacity: tab.chosen && !tab.tabFocused ? 1 : 0

                        Behavior on opacity {
                            NumberAnimation { duration: root.motionFast }
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        onClicked: root.selectCollection(tab.index)
                    }
                }
            }
        }

        // --- the shelf ---

        // the middle of the screen, between the tabs and the reserved band, is where the
        // shelf lives. the shelf is centred in it rather than pinned under the tabs, so the
        // row of tiles reads as the centre of the screen at any height, which is what a
        // console dashboard is
        Item {
            id: middle

            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: tabs.visible ? tabs.bottom : parent.top
            anchors.bottom: statusBand.top
        }

        ListView {
            id: shelf
            objectName: "shelf"

            visible: root.hasAnything
            orientation: ListView.Horizontal
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.verticalCenter: middle.verticalCenter
            anchors.leftMargin: root.unit * 3
            anchors.rightMargin: root.unit * 3

            height: root.tileFrameHeight
            spacing: root.unit * 2

            model: root.currentEntries
            currentIndex: root.entryIndex
            clip: true

            // dragging is off, because the position of this row is the focus. A ring that
            // can be dragged away from the tile it belongs to is a row that can hide where
            // the user is, and on a couch the mouse is never the thing driving this.
            // scrollShelf is the only thing that moves it.
            interactive: false
            boundsBehavior: Flickable.StopAtBounds

            NumberAnimation {
                id: shelfScroll
                target: shelf
                property: "contentX"
                duration: root.motionBase
                easing.type: Easing.OutCubic
            }

            delegate: Item {
                id: frame

                required property var modelData
                required property int index

                readonly property bool focusedTile: index === root.entryIndex
                readonly property bool hasArtwork: modelData.icon !== ""

                width: root.tileFrameWidth
                height: root.tileFrameHeight

                // everything the focus lifts is in this one box, and the box is scaled as a
                // whole. the frame around it is larger than the box, so the lifted ring
                // lands inside the shelf rather than being clipped at its edge, and the row
                // does not reflow because the frame itself never changes size
                Item {
                    id: focusBox

                    anchors.centerIn: parent
                    width: root.focusBoxWidth
                    height: root.focusBoxHeight

                    scale: frame.focusedTile ? root.tileScale : 1.0

                    Behavior on scale {
                        NumberAnimation {
                            duration: root.motionBase
                            easing.type: Easing.OutCubic
                        }
                    }

                    // the ring hugs the tile and fades in and out rather than being drawn
                    // and not drawn, and it is the only thing that marks the focused tile
                    Rectangle {
                        anchors.fill: parent
                        color: "transparent"
                        radius: root.unit * 0.5
                        border.width: root.focusWidth
                        border.color: root.colorAccent
                        opacity: frame.focusedTile ? 1 : 0

                        Behavior on opacity {
                            NumberAnimation { duration: root.motionFast }
                        }
                    }

                    Rectangle {
                        id: tile

                        anchors.centerIn: parent
                        width: root.tileWidth
                        height: root.tileHeight
                        radius: root.unit * 0.4
                        border.width: 1
                        border.color: root.colorBorder

                        // slightly lighter at the top than the bottom, which is what makes a
                        // flat rectangle read as a surface instead of as a hole in the screen
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: root.colorSurfaceFocused }
                            GradientStop { position: 1.0; color: root.colorSurface }
                        }

                        Image {
                            anchors.fill: parent
                            anchors.margins: 1
                            source: frame.hasArtwork ? frame.modelData.icon : ""
                            fillMode: Image.PreserveAspectCrop
                            asynchronous: true
                            visible: frame.hasArtwork && status === Image.Ready
                        }

                        // the unfocused tiles are shaded rather than made translucent, so
                        // that the background does not show through them, and the shade is
                        // animated so that the eye follows the focus along the row
                        Rectangle {
                            anchors.fill: parent
                            radius: parent.radius
                            color: root.colorShade
                            opacity: frame.focusedTile ? 0 : root.shadeOpacity

                            Behavior on opacity {
                                NumberAnimation { duration: root.motionBase }
                            }
                        }

                        // every entry shows a name, so an entry without artwork is a
                        // readable tile rather than an empty rectangle
                        Text {
                            anchors.centerIn: parent
                            anchors.margins: root.unit
                            width: parent.width - root.unit * 2
                            visible: !frame.hasArtwork
                            text: frame.modelData.name
                            color: root.colorText
                            font.pixelSize: Math.round(root.unit * 1.15)
                            horizontalAlignment: Text.AlignHCenter
                            wrapMode: Text.WordWrap
                        }
                    }
                }

                MouseArea {
                    anchors.fill: parent
                    onClicked: {
                        root.entryIndex = frame.index;
                        root.launchFocused();
                    }
                }
            }
        }

        // --- what to say when there is nothing to show ---

        Text {
            visible: !root.hasAnything
            anchors.centerIn: parent
            width: root.textWidth
            horizontalAlignment: Text.AlignHCenter
            color: root.colorDim
            font.pixelSize: Math.round(root.unit * 1.3)
            wrapMode: Text.WordWrap
            text: "Nothing is set up on this machine yet.\n\n"
                + "Applications are installed separately from Couchbox OS, so this list is empty "
                + "until something is installed."
        }

        // --- the reserved band at the bottom ---

        // everything the machine has to say lives in this one band, and the band's height is
        // fixed and always reserved, so nothing that appears in it can move the shelf, the
        // band, or anything else. the faults this replaces were a status line printed over
        // the entry description and an install panel floating over the shelf: two things
        // that had never been given a place of their own.
        //
        // the first row is the focused entry: its name, and its description when it has one.
        // the name is written here rather than on the tile because a tile with artwork cannot
        // write its own name on the artwork and stay readable. the second row is the machine:
        // an install in progress as a compact name-then-bar row, and the shell's status line
        // beside it.
        Item {
            id: statusBand

            anchors.left: parent.left
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            anchors.leftMargin: root.unit * 3
            anchors.rightMargin: root.unit * 3
            anchors.bottomMargin: root.unit * 3
            height: root.statusBandHeight

            // one hairline separates the band from the shelf without boxing anything in,
            // and it is one static pixel rather than a drawn border
            Rectangle {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                height: 1
                color: root.colorBorder
            }

            // first row: what is focused
            Item {
                id: captionRow

                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                anchors.topMargin: root.unit * 1.2
                height: root.unit * 2.6

                // the description arrives rather than switching, which is the small movement
                // the screen always had, and it is one short animation per change. the slide
                // is a few pixels and stays inside the reserved row, so it can never touch
                // the row below it
                property real slide: 0
                transform: Translate { y: captionRow.slide }

                SequentialAnimation {
                    id: captionSwap

                    // the start of the slide is set instantly, and only then animated, so the
                    // movement always runs the full distance instead of starting wherever the
                    // last one happened to stop
                    NumberAnimation {
                        target: captionRow
                        property: "slide"
                        to: root.unit * 0.6
                        duration: 0
                    }

                    ParallelAnimation {
                        NumberAnimation {
                            target: captionRow
                            property: "slide"
                            to: 0
                            duration: root.motionBase
                            easing.type: Easing.OutCubic
                        }

                        NumberAnimation {
                            target: captionRow
                            property: "opacity"
                            from: 0.0
                            to: 1.0
                            duration: root.motionBase
                            easing.type: Easing.OutCubic
                        }
                    }
                }

                Text {
                    id: captionName

                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    width: Math.min(captionName.implicitWidth, parent.width * 0.45)
                    text: root.focusedEntry && root.focusedEntry.name ? root.focusedEntry.name : ""
                    color: root.colorText
                    font.pixelSize: Math.round(root.unit * 1.8)
                    font.bold: true
                    elide: Text.ElideRight
                }

                Text {
                    id: captionDescription

                    anchors.left: captionName.right
                    anchors.leftMargin: root.unit * 1.2
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    text: root.focusedEntry && root.focusedEntry.description
                        ? root.focusedEntry.description
                        : ""
                    visible: text !== ""
                    color: root.colorDim
                    font.pixelSize: Math.round(root.unit * 1.2)
                    elide: Text.ElideRight
                }
            }

            // second row: the machine. the install row comes first and the status line
            // follows it, both elided, both never more than the single line this row reserves
            Item {
                id: statusRow

                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                anchors.bottomMargin: root.unit * 1.2
                height: root.unit * 2.4

                // an install is not a notification: it is a compact row with the name or
                // phrase at the left of it and a thin bar that fills in. the bar has a
                // moving block while the engine cannot say how far along it is, because a
                // bar that sits still reads as an install that has stopped
                Row {
                    id: installRow

                    // a hidden row takes no room, so the status line beside it starts at the
                    // left edge again the moment there is no install to show
                    width: visible ? implicitWidth : 0
                    height: root.unit * 2.4
                    visible: Shell.installActive
                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: root.unit * 1

                    Text {
                        id: installText

                        width: Math.min(installText.implicitWidth, root.unit * 20)
                        height: installRow.height
                        text: Shell.installText
                        color: root.colorText
                        font.pixelSize: Math.round(root.unit * 1.2)
                        elide: Text.ElideRight
                        verticalAlignment: Text.AlignVCenter
                    }

                    Rectangle {
                        id: installBar

                        width: root.unit * 12
                        height: Math.max(3, Math.round(root.unit * 0.6))
                        y: Math.round((parent.height - height) / 2)
                        radius: height / 2
                        color: root.colorBorder

                        Rectangle {
                            visible: Shell.installPercent >= 0
                            width: parent.width * Math.max(0, Math.min(1, Shell.installPercent / 100))
                            height: parent.height
                            radius: parent.radius
                            color: root.colorAccent
                        }

                        Rectangle {
                            id: installPulse

                            visible: Shell.installActive && Shell.installPercent < 0
                            width: installBar.width * 0.3
                            height: installBar.height
                            radius: installBar.radius
                            color: root.colorAccent

                            SequentialAnimation on x {
                                running: installPulse.visible
                                loops: Animation.Infinite
                                NumberAnimation {
                                    to: installBar.width - installPulse.width
                                    duration: 900
                                    easing.type: Easing.InOutSine
                                }
                                NumberAnimation {
                                    to: 0
                                    duration: 900
                                    easing.type: Easing.InOutSine
                                }
                            }
                        }
                    }
                }

                Text {
                    id: statusText

                    anchors.left: installRow.right
                    anchors.leftMargin: installRow.width > 0 ? root.unit * 2 : 0
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    text: Shell.status
                    color: root.colorAccent
                    font.pixelSize: Math.round(root.unit * 1.2)
                    elide: Text.ElideRight
                }
            }
        }
    }

    // --- the starting screen -------------------------------------------------

    // an application that is starting shows this until it has a window of its own, so that
    // nobody ever watches a black screen and wonders whether the machine heard them (ADR-0034).
    // It sits over the shelf and under the overlay, because the overlay is still the thing the
    // user asked for if they press the guide key while an application is starting.
    //
    // The motion is three dots and nothing else. It exists because a screen with no movement
    // on it reads as a machine that has stopped, and it stops the moment the application is on
    // screen, which is what keeps it affordable on the hardware this ships to.
    Rectangle {
        id: launchScreen

        anchors.fill: parent
        visible: Shell.launching
        gradient: Gradient {
            GradientStop { position: 0.0; color: root.colorBackgroundTop }
            GradientStop { position: 0.45; color: root.colorBackground }
            GradientStop { position: 1.0; color: root.colorBackground }
        }

        Column {
            anchors.centerIn: parent
            spacing: root.unit * 1.4

            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                width: root.textWidth
                horizontalAlignment: Text.AlignHCenter
                text: Shell.launchingName
                color: root.colorText
                font.pixelSize: Math.round(root.unit * 2.6)
                font.bold: true
                elide: Text.ElideRight
            }

            // "Starting" and the three dots are one line, so they are one bounded piece rather
            // than a positioner: a Row cannot align its children vertically, and the dots need
            // to sit on the text's centre line to read as an ellipsis
            Item {
                anchors.horizontalCenter: parent.horizontalCenter
                width: startingText.width + dotRow.width + root.unit * 0.8
                height: Math.max(startingText.height, dotRow.height)

                Text {
                    id: startingText

                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Starting"
                    color: root.colorDim
                    font.pixelSize: Math.round(root.unit * 1.2)
                }

                Row {
                    id: dotRow

                    anchors.left: startingText.right
                    anchors.leftMargin: root.unit * 0.8
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: root.unit * 0.4

                    Repeater {
                        model: 3

                        Rectangle {
                            width: root.unit * 0.5
                            height: width
                            radius: width / 2
                            color: root.colorAccent
                            opacity: 0.25

                            // each dot starts a fifth of a second after the one before it, and
                            // the whole thing runs only while an application is starting
                            SequentialAnimation on opacity {
                                running: Shell.launching
                                loops: Animation.Infinite
                                PauseAnimation { duration: index * 200 }
                                NumberAnimation { to: 1.0; duration: 300 }
                                NumberAnimation { to: 0.25; duration: 300 }
                                PauseAnimation { duration: (2 - index) * 200 }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- the overlay ---------------------------------------------------------

    // the overlay, raised over whatever is on screen (docs/dashboard.md, ADR-0022).
    //
    // It appears in two shapes now, and both are the same list. Over the dashboard it is drawn
    // here, as a layer of this window. Over a running application it is a window of its own
    // (ADR-0035), because the dashboard's window is hidden while an application is in front, and
    // raising it to draw a panel on it replaced what the person was looking at with a dashboard:
    // that is a screen change, not an overlay.
    //
    // The rows and what choosing one means come from the shell now, rather than from a second copy
    // of the same logic written in this file, because there are two places that draw them.
    FocusScope {
        id: overlay

        anchors.fill: parent
        // short, and the layer stops being drawn once the fade has finished, so an overlay
        // that is closed costs nothing. Over a running application the overlay is its own
        // window instead, and this layer stays out of the way of that
        opacity: Shell.overlayOpen && !Shell.overlayOverApplication ? 1.0 : 0.0
        visible: opacity > 0
        focus: Shell.overlayOpen && !Shell.overlayOverApplication

        Behavior on opacity {
            NumberAnimation {
                duration: root.motionFast
                easing.type: Easing.OutCubic
            }
        }

        Connections {
            target: Shell

            function onOverlayChanged() {
                if (Shell.overlayOpen && !Shell.overlayOverApplication) {
                    // the first row that can be chosen, because the first row of all is a
                    // heading whenever there is a recent list to put under one
                    listPanel.selection = listPanel.firstSelectable();
                }
            }
        }

        // up and down rather than left and right, because this is a list and not a shelf
        Keys.onPressed: (event) => {
            switch (event.key) {
            case Qt.Key_Up:
                listPanel.move(-1);
                event.accepted = true;
                break;
            case Qt.Key_Down:
                listPanel.move(1);
                event.accepted = true;
                break;
            case Qt.Key_Return:
            case Qt.Key_Enter:
            case Qt.Key_Space:
                listPanel.activate(listPanel.selection);
                event.accepted = true;
                break;
            case Qt.Key_Escape:
            case Qt.Key_Menu:
            case Qt.Key_Meta:
            case Qt.Key_Super_L:
            case Qt.Key_Super_R:
                // closing the overlay and choosing resume are the same thing, which is the
                // one outcome a user can always expect from backing out of anything, and the
                // key that opened this closes it again (ADR-0034)
                Shell.closeOverlay();
                event.accepted = true;
                break;
            }
        }

        // the dim behind the panel. Deliberately not a blur: a blur here is a stutter the
        // user sees every single time they open this, on hardware that can least afford it,
        // and the panel reads perfectly well without one
        Rectangle {
            anchors.fill: parent
            color: root.colorShade
            opacity: 0.62
        }

        // the same component the overlay window wears, so the list over the shelf is the list
        // over a running application, drawn once. The height the rows ask for is held inside the
        // window, and the rows themselves are held inside the panel: measured at the tight case,
        // which is 1280x720 with every recent row the shell remembers and the three power entries
        OverlayPanel {
            id: listPanel

            anchors.centerIn: parent
            width: Math.min(root.width - root.unit * 6, root.unit * 38)
            height: Math.min(listPanel.implicitHeight, root.height - root.unit * 2)
            unit: root.unit
            actions: Shell.overlayActions
        }
    }

}
