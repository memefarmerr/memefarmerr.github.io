import QtQuick
import QtQuick.Window
import Couchbox 1.0

// the Couchbox dashboard.
//
// written for a television at couch distance, driven by a controller or a keyboard.
// mouse input works because Qt gives it to us, but nothing here needs it and
// nothing here is reachable only with it.
//
// the layout is one screen deep: a rail of sections, a shelf of entries, and the
// focused entry described underneath. there is no second screen, so nothing can be
// hidden behind a navigation step and back cannot go somewhere unexpected.
//
// every tile is drawn at all times, focused or not. a shelf where only the focused
// entry is visible is not a shelf: it means reading the entries one at a time
// instead of seeing them, which is the wrong thing to ask of somebody on a couch
// six feet away.
//
// the background is a single static gradient, and there is no blur, no shader and
// nothing that redraws while the screen is idle. a ten foot interface invites
// movement, but this has to stay responsive on integrated graphics from around
// 2012, which is also why the shell must go completely quiet while an application
// is running in front of it.

Window {
    id: root

    visible: true
    // fullscreen is the product. windowed exists so the shell can be run in a
    // terminal on a development machine, which is how it gets worked on, and so that
    // a screen size this machine does not have can be laid out and looked at.
    visibility: Shell.windowed ? Window.Windowed : Window.FullScreen
    width: Shell.windowWidth
    height: Shell.windowHeight
    color: "#08080b"
    title: "Couchbox"

    // the palette. these are the only colours in the interface, so tuning the look
    // happens in one place. carried over from the theme that came before this.
    //
    // the background is a gradient rather than a flat colour because a flat dark
    // screen at this size looks like a display that has not switched on, and because
    // it costs one extra stop and no work to draw. it is static: nothing here redraws
    // while the screen is idle.
    readonly property color colorBackgroundTop: "#191922"
    readonly property color colorBackground: "#08080b"
    readonly property color colorSurface: "#20202a"
    readonly property color colorSurfaceFocused: "#2b2b39"
    readonly property color colorBorder: "#34343f"
    readonly property color colorText: "#f4f4f7"
    readonly property color colorDim: "#9a9aa8"
    readonly property color colorAccent: "#e0a13c"

    // the two colours a tile is drawn with when it is not the focused one: a shade over
    // the artwork, and the border it takes instead of the accent. both are animated, so
    // the difference between focused and not is something the eye follows rather than
    // something that changes between two frames.
    readonly property color colorShade: "#000000"
    readonly property real shadeOpacity: 0.28

    // motion. every duration in the interface comes from here, so the whole thing can be
    // slowed down or sped up in one place, and so that nothing accidentally runs long.
    //
    // these are deliberately short. This has to stay responsive on integrated graphics
    // from around 2012, and a transition that is felt as a delay is worse than no
    // transition at all. Nothing here is continuous: every one of them runs because
    // somebody pressed something and then stops.
    readonly property int motionFast: 120
    readonly property int motionBase: 180
    readonly property int motionSlow: 260

    // how much the focused tile grows. The focus ring is drawn outside the tile and
    // focusPad reserves room for it, so a lift smaller than that cannot overlap the tile
    // beside it, which is why this number is small.
    readonly property real tileScale: 1.04

    // one scale factor derived from the screen height drives everything, so the
    // layout stays proportional on both 1280x720 and 1920x1080, which are the two
    // target televisions.
    readonly property int unit: Math.max(10, Math.round(height / 72))

    // box artwork is portrait, so the tile takes the same shape and the artwork
    // fills it instead of floating in the middle of an unrelated rectangle
    readonly property int tileWidth: unit * 14
    readonly property int tileHeight: unit * 21

    // the focus ring is drawn outside the tile so it never lands on the artwork,
    // and it is deliberately thick: it has to read from a couch, and a thin line
    // disappears against box art of almost any colour.
    readonly property int focusPad: Math.round(unit * 0.6)
    readonly property int focusWidth: Math.max(3, Math.round(unit * 0.5))

    // how far apart two tiles sit, which is what the shelf scrolls by
    readonly property real itemPitch: tileWidth + focusPad * 2 + unit * 2

    // long lines are hard to read across a room, so the description is held to a
    // comfortable measure rather than the width of the screen
    readonly property int textWidth: Math.min(width - unit * 8, unit * 52)

    // --- the model ----------------------------------------------------------

    // re-reading on every change rather than holding a copy, because a stale copy
    // is a dashboard that disagrees with its own files
    readonly property var collectionsModel: Shell.collections

    property int collectionIndex: 0

    readonly property var currentCollection:
        collectionsModel.length > 0
            ? collectionsModel[Math.min(collectionIndex, collectionsModel.length - 1)]
            : null

    readonly property var currentEntries: currentCollection ? currentCollection.entries : []

    property int entryIndex: 0

    readonly property var focusedEntry:
        currentEntries.length > 0
            ? currentEntries[Math.min(entryIndex, currentEntries.length - 1)]
            : null

    readonly property bool hasAnything: collectionsModel.length > 0 && currentEntries.length > 0

    // the rail only earns its space when there is more than one section to choose
    // between, so a machine with a single collection looks exactly like a machine
    // with one section rather than like a broken rail
    readonly property bool showRail: collectionsModel.length > 1

    // a collection can arrive with fewer entries than the last one had, so the
    // cursor is brought back inside the model whenever the model changes
    onCollectionsModelChanged: {
        if (collectionIndex >= collectionsModel.length) {
            collectionIndex = 0;
        }
        entryIndex = 0;
    }

    onCurrentEntriesChanged: {
        if (entryIndex >= currentEntries.length) {
            entryIndex = 0;
        }
        root.detailChanged();
    }

    // the description is replaced when the entry changes, so it is asked to arrive
    // rather than to appear
    onEntryIndexChanged: root.detailChanged()

    // --- navigation ---------------------------------------------------------

    function moveSection(step) {
        if (collectionsModel.length < 2) {
            return;
        }
        // wrapping, so the ends of the rail are not dead ends on a controller with
        // no dedicated shoulder buttons
        collectionIndex = (collectionIndex + step + collectionsModel.length) % collectionsModel.length;
        entryIndex = 0;
        // a section change replaces every tile at once, so this one is not animated:
        // sliding a row of tiles that no longer exist is a slide of nothing
        root.scrollShelf(false);
    }

    function moveEntry(step) {
        if (currentEntries.length === 0) {
            return;
        }
        entryIndex = (entryIndex + step + currentEntries.length) % currentEntries.length;
        root.scrollShelf(true);
    }

    // The shelf is scrolled here rather than with positionViewAtIndex, because that
    // jumps: the focused tile is put in view at the speed of the next redraw, which
    // reads as the whole row teleporting under the focus ring. This puts the focused
    // tile in the middle of the row when there is room for it, stays inside the row at
    // both ends, and runs the move as one short animation.
    //
    // The clamping is the part that matters. Without it the first and last tiles would
    // be centred with empty row beside them, which looks like a shelf that has come off
    // its rails.
    function scrollShelf(animated) {
        const itemWidth = tileWidth + focusPad * 2;
        const maxOffset = Math.max(0, shelf.contentWidth - shelf.width);
        const centred = entryIndex * itemPitch + itemWidth / 2 - shelf.width / 2;
        const target = Math.max(0, Math.min(centred, maxOffset));

        if (!animated) {
            shelfScroll.stop();
            shelf.contentX = target;
            return;
        }

        shelfScroll.to = target;
        shelfScroll.restart();
    }

    // The animations below are named in the interface and are started from here, and the
    // guards are not decoration: the model can change while the interface is still being
    // built, before the object that owns the animation exists, and a signal handler that
    // throws on the way up is a dashboard that does not start.
    function detailChanged() {
        if (detailSwap) {
            detailSwap.restart();
        }
    }

    function launchFocused() {
        if (focusedEntry) {
            Shell.launch(collectionIndex, entryIndex);
        }
    }

    // --- the screen ---------------------------------------------------------

    // three stops rather than two, so the light falls off towards the edges instead of
    // stepping from one colour to the other across a visible line
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: root.colorBackgroundTop }
            GradientStop { position: 0.45; color: root.colorBackground }
            GradientStop { position: 1.0; color: root.colorBackground }
        }
    }

    FocusScope {
        id: content
        anchors.fill: parent
        // the overlay takes the keyboard while it is up, so the shelf must not. one of the
        // two owns the keys at any moment, and it is never both
        focus: !Shell.overlayOpen

        // the interface comes up rather than switching on. It is one opacity ramp over
        // the whole screen, it runs once, and it covers the moment between the window
        // being mapped and the first frame being drawn.
        opacity: 0
        Component.onCompleted: appear.start()

        NumberAnimation {
            id: appear
            target: content
            property: "opacity"
            to: 1.0
            duration: root.motionSlow
            easing.type: Easing.OutCubic
        }

        // The fade is the one animation here whose failure would be worse than not having
        // it: an interface that fades up and never arrives is a black screen with a
        // working machine behind it. This puts the screen back unconditionally, and it is
        // harmless when the fade has worked, because by then it is setting the value the
        // fade has already reached.
        Timer {
            interval: root.motionSlow + 400
            running: true
            repeat: false
            onTriggered: content.opacity = 1
        }

        // one handler, because the gamepad arrives here as key events too. this is
        // why nothing in this file has to know whether a controller or a keyboard
        // is in use.
        Keys.onPressed: (event) => {
            switch (event.key) {
            case Qt.Key_Left:
                root.moveEntry(-1);
                event.accepted = true;
                break;
            case Qt.Key_Right:
                root.moveEntry(1);
                event.accepted = true;
                break;
            case Qt.Key_Up:
                root.moveSection(-1);
                event.accepted = true;
                break;
            case Qt.Key_Down:
                root.moveSection(1);
                event.accepted = true;
                break;
            case Qt.Key_Return:
            case Qt.Key_Enter:
            case Qt.Key_Space:
                root.launchFocused();
                event.accepted = true;
                break;
            case Qt.Key_R:
                Shell.reload();
                event.accepted = true;
                break;
            // the overlay, from the interface rather than from the hotkey. Escape is on every
            // keyboard and is what the B and X buttons on a controller send, and Menu is the key
            // that exists for exactly this on a keyboard and is what Start sends. Both work
            // through a remote session, which the guide cannot: a remote desktop delivers its
            // keys to X and never to the input devices the guide reads
            case Qt.Key_Menu:
            case Qt.Key_Escape:
                Shell.openOverlayFromDashboard();
                event.accepted = true;
                break;
            case Qt.Key_Q:
                if (event.modifiers & Qt.ControlModifier) {
                    Shell.quit();
                    event.accepted = true;
                }
                break;
            }
        }

        // --- the rail ---

        Row {
            id: rail
            visible: root.showRail
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: root.unit * 3
            anchors.bottomMargin: 0
            spacing: root.unit

            Repeater {
                model: root.showRail ? root.collectionsModel : []

                delegate: Rectangle {
                    id: pill

                    required property var modelData
                    required property int index

                    readonly property bool chosen: index === root.collectionIndex

                    width: pillText.implicitWidth + root.unit * 2
                    height: root.unit * 2.6
                    radius: height / 2
                    color: pill.chosen ? root.colorSurfaceFocused : "transparent"
                    border.color: root.colorBorder
                    border.width: 1

                    // the chosen pill fills in and gains an accent outline, and both are
                    // animated, so the rail reads as one selection moving along it rather
                    // than as two pills being repainted
                    Behavior on color {
                        ColorAnimation { duration: root.motionFast }
                    }

                    Rectangle {
                        anchors.fill: parent
                        radius: parent.radius
                        color: "transparent"
                        border.width: 1
                        border.color: root.colorAccent
                        opacity: pill.chosen ? 1 : 0

                        Behavior on opacity {
                            NumberAnimation { duration: root.motionFast }
                        }
                    }

                    Text {
                        id: pillText
                        anchors.centerIn: parent
                        text: pill.modelData.name
                        color: pill.chosen ? root.colorText : root.colorDim
                        font.pixelSize: Math.round(root.unit * 1.1)
                        font.bold: pill.chosen

                        Behavior on color {
                            ColorAnimation { duration: root.motionFast }
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        onClicked: root.collectionIndex = pill.index
                    }
                }
            }
        }

        // --- the shelf ---

        ListView {
            id: shelf
            objectName: "shelf"

            visible: root.hasAnything
            orientation: ListView.Horizontal
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: rail.visible ? rail.bottom : parent.top
            anchors.topMargin: root.unit * 4
            anchors.leftMargin: root.unit * 3
            anchors.rightMargin: root.unit * 3

            height: root.tileHeight + root.focusPad * 2
            spacing: root.unit * 2

            model: root.currentEntries
            currentIndex: root.entryIndex
            clip: true

            // dragging is off, because the position of this row is the focus. A ring that
            // can be dragged away from the tile it belongs to is a row that can hide where
            // the user is, and on a couch the mouse is never the thing driving this.
            // scrollShelf is the only thing that moves it.
            interactive: false
            boundsBehavior: Flickable.StopAtBounds

            NumberAnimation {
                id: shelfScroll
                target: shelf
                property: "contentX"
                duration: root.motionBase
                easing.type: Easing.OutCubic
            }

            delegate: Item {
                id: frame

                required property var modelData
                required property int index

                readonly property bool focusedTile: index === root.entryIndex
                readonly property bool hasArtwork: modelData.icon !== ""

                width: root.tileWidth + root.focusPad * 2
                height: root.tileHeight + root.focusPad * 2

                // the focused tile lifts. It is a scale rather than a change of size, so
                // that the row does not reflow while the focus moves along it: growing the
                // item would push every tile after it sideways.
                scale: frame.focusedTile ? root.tileScale : 1.0

                Behavior on scale {
                    NumberAnimation {
                        duration: root.motionBase
                        easing.type: Easing.OutCubic
                    }
                }

                // the ring fades in and out rather than being drawn and not drawn, and it
                // is the only thing that marks the focused tile
                Rectangle {
                    anchors.fill: parent
                    anchors.margins: root.focusPad - root.focusWidth
                    color: "transparent"
                    radius: root.unit * 0.5
                    border.width: root.focusWidth
                    border.color: root.colorAccent
                    opacity: frame.focusedTile ? 1 : 0

                    Behavior on opacity {
                        NumberAnimation { duration: root.motionFast }
                    }
                }

                Rectangle {
                    id: tile
                    anchors.centerIn: parent
                    width: root.tileWidth
                    height: root.tileHeight
                    radius: root.unit * 0.4
                    border.width: 1
                    border.color: root.colorBorder

                    // slightly lighter at the top than the bottom, which is what makes a
                    // flat rectangle read as a surface instead of as a hole in the screen
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: root.colorSurfaceFocused }
                        GradientStop { position: 1.0; color: root.colorSurface }
                    }

                    Image {
                        anchors.fill: parent
                        anchors.margins: 1
                        source: frame.hasArtwork ? frame.modelData.icon : ""
                        fillMode: Image.PreserveAspectCrop
                        asynchronous: true
                        visible: frame.hasArtwork && status === Image.Ready
                    }

                    // the unfocused tiles are shaded rather than made translucent, so that
                    // the background does not show through them, and the shade is animated
                    // so that the eye follows the focus along the row
                    Rectangle {
                        anchors.fill: parent
                        radius: parent.radius
                        color: root.colorShade
                        opacity: frame.focusedTile ? 0 : root.shadeOpacity

                        Behavior on opacity {
                            NumberAnimation { duration: root.motionBase }
                        }
                    }

                    // every entry shows a name, so an entry without artwork is a
                    // readable tile rather than an empty rectangle
                    Text {
                        anchors.centerIn: parent
                        anchors.margins: root.unit
                        width: parent.width - root.unit * 2
                        visible: !frame.hasArtwork
                        text: frame.modelData.name
                        color: root.colorText
                        font.pixelSize: Math.round(root.unit * 1.15)
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.WordWrap
                    }
                }

                MouseArea {
                    anchors.fill: parent
                    onClicked: {
                        root.entryIndex = frame.index;
                        root.launchFocused();
                    }
                }
            }
        }

        // --- what the focused entry is ---

        // The description sits at the bottom of the screen rather than directly under the
        // tiles. Under the tiles it left the lower half of a television empty, which reads
        // as a screen that has not finished loading, and it left the tiles stranded in the
        // top third. At the bottom, the row of artwork holds the top and the description
        // holds the bottom, and the quiet space in between is a gap rather than a hole.
        //
        // The distance between the two is the reason the accent rule above the name exists:
        // it is what ties the description to the row, at a size that reads from a couch.
        //
        // This assumes a screen at least 720 tall, which is the smaller of the two targets.
        // The numbers there: the rail, the gap and the tiles come to about 300, and the
        // description is about 100 tall against a bottom margin of 33, so they cannot meet.
        Column {
            id: detail
            visible: root.hasAnything
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            anchors.leftMargin: root.unit * 3
            anchors.rightMargin: root.unit * 3
            anchors.bottomMargin: root.unit * 3
            spacing: root.unit * 0.6

            // the description arrives rather than appearing: it fades in while sliding up
            // by a few pixels. This is the one animation that also runs on a section
            // change, because a section change replaces what is written here too.
            property real slide: 0
            transform: Translate { y: detail.slide }

            SequentialAnimation {
                id: detailSwap

                // the start of the slide is set instantly, and only then animated, so the
                // movement always runs the full distance instead of starting wherever the
                // last one happened to stop
                NumberAnimation {
                    target: detail
                    property: "slide"
                    to: root.unit * 0.9
                    duration: 0
                }

                ParallelAnimation {
                    NumberAnimation {
                        target: detail
                        property: "slide"
                        to: 0
                        duration: root.motionBase
                        easing.type: Easing.OutCubic
                    }

                    NumberAnimation {
                        target: detail
                        property: "opacity"
                        from: 0.0
                        to: 1.0
                        duration: root.motionBase
                        easing.type: Easing.OutCubic
                    }
                }
            }

            // a short rule in the accent colour, which is what separates the description
            // from the row of tiles above it without drawing a border around anything
            Rectangle {
                width: root.unit * 2.4
                height: Math.max(2, Math.round(root.unit * 0.16))
                radius: height / 2
                color: root.colorAccent
            }

            Text {
                width: root.textWidth
                text: root.focusedEntry ? root.focusedEntry.name : ""
                color: root.colorText
                font.pixelSize: Math.round(root.unit * 1.8)
                font.bold: true
                elide: Text.ElideRight
            }

            Text {
                width: root.textWidth
                visible: root.focusedEntry && root.focusedEntry.description !== ""
                text: root.focusedEntry ? root.focusedEntry.description : ""
                color: root.colorDim
                font.pixelSize: Math.round(root.unit * 1.1)
                wrapMode: Text.WordWrap
                maximumLineCount: 3
                elide: Text.ElideRight
            }
        }

        // --- what to say when there is nothing to show ---

        Text {
            visible: !root.hasAnything
            anchors.centerIn: parent
            width: root.textWidth
            horizontalAlignment: Text.AlignHCenter
            color: root.colorDim
            font.pixelSize: Math.round(root.unit * 1.3)
            wrapMode: Text.WordWrap
            text: "Nothing is set up on this machine yet.\n\n"
                + "Applications are installed separately from Couchbox OS, so this list is empty "
                + "until something is installed."
        }

        // --- the one line of text the shell needs to say out loud ---

        Text {
            visible: Shell.status !== ""
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottom: parent.bottom
            anchors.bottomMargin: root.unit * 3
            color: root.colorAccent
            font.pixelSize: Math.round(root.unit * 1.1)
            text: Shell.status
        }

        // the overlay is reachable two ways, and this is the one nobody has to be told about.
        // Deliberately small and dim: it is there to be found, not to be read from the couch.
        //
        // The second line names the keys that work while an application has the screen, because
        // nothing on screen can say so at that moment: the dashboard is not drawing, so the only
        // way to learn them is before they are needed. A console has a guide button for this; a
        // keyboard has Super, and a client that keeps Super for itself needs the combination
        Text {
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            anchors.margins: root.unit * 1.5
            horizontalAlignment: Text.AlignRight
            text: "Menu or Escape opens this\nOver an application: Super, Menu, or Ctrl+Alt+Escape"
            color: root.colorDim
            opacity: 0.7
            font.pixelSize: Math.round(root.unit * 0.9)
            lineHeight: 1.35
        }
    }

    // --- the overlay ---------------------------------------------------------

    // the dashboard raised over a running application (docs/dashboard.md, ADR-0022). It is the
    // same window, the same palette and the same input model, in the state where the shelf is
    // not what is wanted: somebody is in a game and pressed the guide key, and what they need
    // is a short list of ways out rather than a library.
    //
    // The list below is two things this side already knows about and then the system actions,
    // which are found by looking for entries whose wrapper is a system one rather than by
    // matching a collection name. Nothing here knows what any application is, so an
    // application that wants an overlay action of its own can have one without this file
    // changing (ADR-0022, not built yet: see docs/tasks.md).
    //
    // The application is paused while this is up, and that is the shell's doing rather than
    // this file's, which is also where the decision lives to stop doing it when a wrapper asks.
    FocusScope {
        id: overlay

        anchors.fill: parent
        // short, and the layer stops being drawn once the fade has finished, so an overlay
        // that is closed costs nothing
        opacity: Shell.overlayOpen ? 1.0 : 0.0
        visible: opacity > 0
        focus: Shell.overlayOpen

        Behavior on opacity {
            NumberAnimation {
                duration: root.motionFast
                easing.type: Easing.OutCubic
            }
        }

        // the press that opened this is the press that means "I want out", so the first row,
        // which is the way back, is where the selection starts
        property int selection: 0

        Connections {
            target: Shell

            function onOverlayChanged() {
                if (Shell.overlayOpen) {
                    // the first row that can be chosen, because the first row of all is a
                    // heading whenever there is a recent list to put under one
                    overlay.selection = overlay.firstSelectable();
                }
            }
        }

        readonly property var actions: {
            const items = [];
            if (Shell.applicationRunning) {
                items.push({
                    "title": "Resume",
                    "detail": "Go back to what is running",
                    "kind": "resume",
                    "index": -1,
                    "collection": -1,
                    "entry": -1
                });
                items.push({
                    "title": "Dashboard",
                    "detail": "Leave it running and come back here",
                    "kind": "dashboard",
                    "index": -1,
                    "collection": -1,
                    "entry": -1
                });
                // stopping it is deliberately below the two that only change what is on screen, and
                // its second line says what it costs. This is the row ADR-0022 says an application
                // should be able to define for itself: a wrapper that declares what stopping means
                // gets its own behaviour, and everything else gets this, which is to stop
                items.push({
                    "title": "Close " + Shell.runningName,
                    "detail": "Stop it and come back to the dashboard",
                    "kind": "stop",
                    "index": -1,
                    "collection": -1,
                    "entry": -1
                });
            }
            // what this machine started last, which is what somebody most often wants back. It
            // goes above the power actions because it is the reason the overlay opens when
            // nothing is running at all
            const recent = Shell.recent;
            if (recent.length > 0) {
                items.push({ "title": "Recent", "detail": "", "kind": "header", "index": -1, "collection": -1, "entry": -1 });
                for (let r = 0; r < recent.length; ++r) {
                    items.push({
                        "title": recent[r].name,
                        // no detail line: the heading above already says what these are, and
                        // repeating "start it again" six times costs 100 pixels of height and
                        // tells nobody anything
                        "detail": "",
                        "kind": "recent",
                        "index": r,
                        "collection": -1,
                        "entry": -1
                    });
                }
            }
            const system = [];
            for (let c = 0; c < root.collectionsModel.length; ++c) {
                const collection = root.collectionsModel[c];
                for (let e = 0; e < collection.entries.length; ++e) {
                    const entry = collection.entries[e];
                    if (entry.system) {
                        system.push({
                            "title": entry.name,
                            "detail": entry.description,
                            "kind": "system",
                            "index": -1,
                            "collection": c,
                            "entry": e
                        });
                    }
                }
            }
            if (system.length > 0) {
                items.push({ "title": "Power", "detail": "", "kind": "header", "index": -1, "collection": -1, "entry": -1 });
                for (let s = 0; s < system.length; ++s) {
                    items.push(system[s]);
                }
            }
            return items;
        }

        // the selection only ever lands on something that can be chosen: a heading is not a
        // destination, and landing on one would mean a press that did nothing
        function firstSelectable() {
            for (let i = 0; i < actions.length; ++i) {
                if (actions[i].kind !== "header") {
                    return i;
                }
            }
            return 0;
        }

        function move(step) {
            if (actions.length === 0) {
                return;
            }
            let next = selection;
            for (let tried = 0; tried < actions.length; ++tried) {
                next = (next + step + actions.length) % actions.length;
                if (actions[next].kind !== "header") {
                    selection = next;
                    return;
                }
            }
        }

        function activate(index) {
            const item = actions[index];
            if (!item || item.kind === "header") {
                return;
            }
            if (item.kind === "resume") {
                Shell.resumeApplication();
            } else if (item.kind === "dashboard") {
                Shell.showDashboard();
            } else if (item.kind === "stop") {
                Shell.stopApplication();
            } else if (item.kind === "recent") {
                Shell.launchRecent(item.index);
            } else {
                Shell.runSystemAction(item.collection, item.entry);
            }
        }

        // up and down rather than left and right, because this is a list and not a shelf
        Keys.onPressed: (event) => {
            switch (event.key) {
            case Qt.Key_Up:
                overlay.move(-1);
                event.accepted = true;
                break;
            case Qt.Key_Down:
                overlay.move(1);
                event.accepted = true;
                break;
            case Qt.Key_Return:
            case Qt.Key_Enter:
            case Qt.Key_Space:
                overlay.activate(overlay.selection);
                event.accepted = true;
                break;
            case Qt.Key_Escape:
                // closing the overlay and choosing resume are the same thing, which is the
                // one outcome a user can always expect from backing out of anything
                Shell.closeOverlay();
                event.accepted = true;
                break;
            }
        }

        // the dim behind the panel. Deliberately not a blur: a blur here is a stutter the
        // user sees every single time they open this, on hardware that can least afford it,
        // and the panel reads perfectly well without one
        Rectangle {
            anchors.fill: parent
            color: root.colorShade
            opacity: 0.62
        }

        Rectangle {
            id: overlayPanel

            anchors.centerIn: parent
            width: Math.min(root.width - root.unit * 6, root.unit * 38)
            // the height the rows ask for, held inside the window, and the rows themselves held
            // inside the panel. Measured at the tight case, which is 1280x720 with every recent
            // row the shell remembers and the three power entries: the rows come to about 620 of
            // the 720 available, so it fits with room to spare, and this bound exists so that a
            // later release adding a fourth power action cuts a row off rather than drawing a
            // panel over the edges of a television. Clipping rather than scaling keeps the text
            // at a size that reads from a couch
            height: Math.min(
                panelColumn.implicitHeight + root.unit * 4,
                root.height - root.unit * 2)
            clip: true
            radius: root.unit * 0.8
            color: root.colorSurface
            border.color: root.colorBorder
            border.width: 1

            Column {
                id: panelColumn

                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                anchors.margins: root.unit * 2
                spacing: root.unit * 0.5

                Text {
                    text: "Couchbox"
                    color: root.colorDim
                    font.pixelSize: Math.round(root.unit * 1.1)
                    font.capitalization: Font.AllUppercase
                    font.letterSpacing: root.unit * 0.12
                }

                Repeater {
                    model: overlay.actions

                    delegate: Rectangle {
                        id: overlayRow

                        required property var modelData
                        required property int index

                        readonly property bool chosen: index === overlay.selection
                        readonly property bool heading: modelData.kind === "header"

                        width: panelColumn.width
                        height: heading
                                ? rowTitle.implicitHeight + root.unit * 0.9
                                : rowText.implicitHeight + root.unit * 1.5
                        radius: root.unit * 0.5
                        color: overlayRow.heading || !overlayRow.chosen
                                ? "transparent"
                                : root.colorSurfaceFocused
                        border.width: !overlayRow.heading && overlayRow.chosen
                                ? Math.max(1, Math.round(root.unit * 0.12))
                                : 0
                        border.color: root.colorAccent

                        // the row fills in rather than switching, so moving down the list is
                        // something the eye follows
                        Behavior on color {
                            ColorAnimation {
                                duration: root.motionFast
                            }
                        }

                        Column {
                            id: rowText

                            anchors.left: parent.left
                            anchors.right: parent.right
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.leftMargin: root.unit * 1.2
                            anchors.rightMargin: root.unit * 1.2
                            spacing: root.unit * 0.2

                            Text {
                                id: rowTitle

                                width: rowText.width
                                text: overlayRow.modelData.title
                                color: overlayRow.heading ? root.colorDim : root.colorText
                                font.pixelSize: Math.round(
                                    root.unit * (overlayRow.heading ? 0.95 : 1.5))
                                font.bold: !overlayRow.heading && overlayRow.chosen
                                font.capitalization: overlayRow.heading
                                    ? Font.AllUppercase
                                    : Font.MixedCase
                                elide: Text.ElideRight
                            }

                            Text {
                                width: rowText.width
                                visible: !overlayRow.heading && overlayRow.modelData.detail !== ""
                                text: overlayRow.modelData.detail
                                color: root.colorDim
                                font.pixelSize: Math.round(root.unit * 1.0)
                                wrapMode: Text.WordWrap
                                // one line, because the panel's height is what decides whether
                                // everything in it is reachable on a 720 high screen
                                maximumLineCount: 1
                                elide: Text.ElideRight
                            }
                        }

                        // a mouse can click a row, which costs one handler and is never the
                        // only way to do anything
                        MouseArea {
                            anchors.fill: parent
                            enabled: !overlayRow.heading
                            onClicked: {
                                overlay.selection = overlayRow.index;
                                overlay.activate(overlayRow.index);
                            }
                        }
                    }
                }

                // the way out is worth naming once, because pressing the key again is the
                // gesture a console user will try first and this says that it works
                Text {
                    topPadding: root.unit * 0.5
                    text: "Press the guide key again, or Escape, to close"
                    color: root.colorDim
                    font.pixelSize: Math.round(root.unit * 0.95)
                }
            }
        }
    }
}
