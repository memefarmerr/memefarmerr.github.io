"""the screens this machine is plugged into, and how to arrange them.

A console is plugged into whatever television is in the room, and the machine cannot work out what
that television wants. It overscans or it does not, its aspect is not always what it claims, and
somebody with two screens may want the same picture on both or a desktop spread across them. So this
is the one part of the settings that cannot be read off the machine and has to be asked about.

Everything here is `xrandr`, which is the only thing on a Linux machine that knows about outputs,
apart from the drivers' own tools. It answers in a text format designed for people to read, so the
parsing lives here with a test beside it against real output rather than a shape somebody imagined.

Two things this module deliberately does not do.

It does not use `--transform` to fix overscan. A transform is the generic answer and it is the one
that would work on every driver, but the coefficients and the sign of them are not something to
guess at, and this machine has no display that accepts one to measure against: Xvfb refuses, and
changing the screen of the machine this was written on is not a thing to do. What it does instead is
use the property the driver publishes for exactly this, which can be read back and is what the
driver's own documentation tells people to set.

And it does not remember a layout as a description of itself. It remembers the `xrandr` commands
that produced it, because running them again is what restores it, and because a description would
have to be turned back into commands by guessing.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

# where a person's own arrangement lives. Not in /etc: this is about the television in the room,
# not about the machine, and it is the person sitting in front of it who knows.
CONFIG_PATH = Path.home() / ".config" / "couchbox" / "display.json"

# xrandr answers in a second. It is talking to the X server on the same machine, not to a network,
# so anything slower than this is a display that has stopped answering rather than one that is busy.
COMMAND_TIMEOUT = 8


def run(command: list[str], timeout: int = COMMAND_TIMEOUT) -> tuple[int, str]:
    """run xrandr and give back its status and what it said."""
    try:
        done = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as error:
        return 1, str(error)
    return done.returncode, (done.stdout or "") + (done.stderr or "")


# a mode line is indented and starts with the mode's name, which for everything the machine
# generated itself is its size: "   1920x1080     60.00*+  50.00". A mode somebody added by hand
# keeps the name they gave it, which is why the name is kept rather than turned into numbers.
def _is_size(text: str) -> bool:
    width, _, height = text.partition("x")
    return width.isdigit() and height[:1].isdigit()


def _mode(line: str) -> dict | None:
    """one line of a connected output's mode list."""
    parts = line.split()
    if not parts:
        return None
    name = parts[0]
    widescreen = _is_size(name)
    mode: dict = {
        "name": name,
        "width": int(name.split("x")[0]) if widescreen else 0,
        "height": int(name.split("x")[1].rstrip("i")) if widescreen else 0,
        "interlaced": name.endswith("i"),
        "rates": [],
        "current": False,
        "preferred": False,
    }
    for token in parts[1:]:
        if token.startswith("("):
            # "(interlace)" and friends come after the rates and are not rates
            break
        # the marks are * for what is being shown and + for the mode the screen prefers, and they
        # come in either order: real output has a mode line reading "60.00*+", so asking whether the
        # token ends with either one is asking the wrong question
        current = "*" in token
        preferred = "+" in token
        number = token.rstrip("*+")
        if number.replace(".", "", 1).isdigit():
            mode["rates"].append(float(number))
        if current:
            mode["current"] = True
        if preferred:
            mode["preferred"] = True
    return mode


def _output(line: str) -> dict:
    """the line that names an output and says whether anything is plugged into it."""
    parts = line.split()
    name = parts[0]
    state = parts[1] if len(parts) > 1 else "unknown"
    found: dict = {
        "name": name,
        "connected": state == "connected",
        "primary": "primary" in parts[2:3],
        "width": 0,
        "height": 0,
        "x": 0,
        "y": 0,
        "modes": [],
    }
    for token in parts[2:]:
        # "1920x1080+0+0", and an output that is connected but not configured has none of these
        if "x" in token and "+" in token:
            size, _, rest = token.partition("+")
            width, _, height = size.partition("x")
            left, _, top = rest.partition("+")
            if width.isdigit() and height.isdigit():
                found["width"] = int(width)
                found["height"] = int(height)
                found["x"] = int(left) if left.lstrip("-").isdigit() else 0
                found["y"] = int(top) if top.lstrip("-").isdigit() else 0
            break
    return found


def outputs(from_text: str | None = None) -> list[dict]:
    """every output the machine knows about, with its modes on the connected ones.

    Pass `from_text` to parse a saved answer instead of running xrandr, which is what the test does.
    """
    if from_text is None:
        code, text = run(["xrandr", "--query"])
        if code != 0:
            return []
    else:
        text = from_text

    found: list[dict] = []
    current: dict | None = None
    for line in text.splitlines():
        if line.startswith(("Screen ", "\t", " ")):
            if current is not None and line.strip() and not line.startswith("Screen "):
                mode = _mode(line)
                if mode is not None:
                    current["modes"].append(mode)
            continue
        if not line.strip():
            continue
        current = _output(line)
        found.append(current)
    return found


def connected(from_text: str | None = None) -> list[dict]:
    """the outputs with something plugged into them, the primary first."""
    found = [output for output in outputs(from_text) if output["connected"]]
    return sorted(found, key=lambda output: (not output["primary"], output["name"]))


def fitted(output: dict) -> dict | None:
    """the mode an output is showing, which is the one xrandr marked with a star."""
    for mode in output["modes"]:
        if mode["current"]:
            return mode
    return None


def sizes(output: dict) -> list[tuple[int, int]]:
    """the distinct sizes an output offers, largest first, without the interlaced ones.

    Interlaced modes are left out because a console does not want one: they are for broadcast
    video, they shimmer on fine detail, and offering them beside the progressive mode of the same
    size is offering somebody a way to make their own screen worse.
    """
    found: list[tuple[int, int]] = []
    for mode in output["modes"]:
        if not mode["width"] or mode["interlaced"]:
            continue
        pair = (mode["width"], mode["height"])
        if pair not in found:
            found.append(pair)
    return sorted(found, key=lambda pair: (pair[0] * pair[1], pair[0]), reverse=True)


def rates(output: dict, width: int, height: int) -> list[float]:
    """the refresh rates an output offers at one size, fastest first."""
    found: list[float] = []
    for mode in output["modes"]:
        if mode["width"] == width and mode["height"] == height and not mode["interlaced"]:
            for rate in mode["rates"]:
                # a rate of zero is a driver that did not say, which the Xvfb screen does. It is
                # not a choice anybody can make, and offering it as one puts "0 Hz" on a button.
                if rate > 0 and rate not in found:
                    found.append(rate)
    return sorted(found, reverse=True)


def set_mode(name: str, mode: str, rate: float | None = None) -> list[str]:
    """show one output at one of its modes."""
    command = ["xrandr", "--output", name, "--mode", mode]
    if rate is not None:
        command += ["--rate", f"{rate:g}"]
    return command


def mirror(name: str, other: str) -> list[str]:
    """put the same picture on two screens."""
    return ["xrandr", "--output", name, "--same-as", other]


def extend(name: str, other: str, side: str = "right") -> list[str]:
    """spread the desktop across two screens, with this one beside that one."""
    where = {
        "right": "--right-of",
        "left": "--left-of",
        "above": "--above",
        "below": "--below",
    }[side]
    return ["xrandr", "--output", name, where, other]


PROPERTY_TIMEOUT = 8


def properties(name: str, from_text: str | None = None) -> dict[str, dict]:
    """the properties one output publishes, which is what a driver offers to be told about a screen.

    This is where overscan is fixed on the drivers that support it: amdgpu and radeon publish
    `underscan` and the two borders, and `scaling mode` is how the picture is fitted to a screen
    whose aspect is not the one being sent. There is no property on a driver that does not have one,
    which is why the page only offers what the output actually advertises rather than a control that
    silently does nothing on somebody else's machine.

    Each property comes back with what it is set to, what it will accept, and the range if it takes
    a number, because a control that offers only the value it already has is not a control.

    A property line is introduced by a tab and the line under it says what it accepts. A mode line
    is introduced by spaces, which is how the two are told apart in output that mixes them.
    """
    if from_text is None:
        code, text = run(["xrandr", "--prop"], timeout=PROPERTY_TIMEOUT)
        if code != 0:
            return {}
    else:
        text = from_text

    found: dict[str, dict] = {}
    inside = False
    prop: str | None = None
    for line in text.splitlines():
        if not line.startswith(("\t", " ")):
            parts = line.split()
            inside = bool(parts) and parts[0] == name
            prop = None
            continue
        if not inside:
            continue
        # the lines under a property: "supported: a, b" and "range: (0, 12)"
        if line.startswith("\t\t"):
            if prop is None:
                continue
            detail = line.strip()
            if detail.startswith("supported:"):
                found[prop]["allowed"] = [
                    value.strip() for value in detail[len("supported:"):].split(",") if value.strip()
                ]
            elif detail.startswith("range:"):
                bounds = detail[len("range:"):].strip().strip("()").split(",")
                numbers = [int(bound.strip()) for bound in bounds if bound.strip().lstrip("-").isdigit()]
                if len(numbers) == 2:
                    found[prop]["range"] = numbers
            continue
        if not line.startswith("\t"):
            # a mode line, which is indented with spaces rather than a tab
            continue
        body = line.strip()
        if not body or ":" not in body:
            continue
        prop, _, values = body.partition(":")
        prop = prop.strip()
        found[prop] = {"current": values.split(), "allowed": [], "range": None}
    return found


def set_property(name: str, prop: str, value: str) -> list[str]:
    """tell one output's driver something about the screen it is plugged into."""
    return ["xrandr", "--output", name, "--set", prop, value]


def forgetting(name: str) -> list[str]:
    """put an output back under the machine's own control, so the desktop can use the space."""
    return ["xrandr", "--output", name, "--auto"]


# --- what the settings remembered ------------------------------------------------------------
#
# The commands themselves, not a description of the arrangement. Running them again is what brings
# the layout back, and a description would have to be turned back into commands by guessing at what
# was meant. It is also what makes the file readable: `cat` on it shows somebody exactly what their
# machine is being told.


def save(commands: list[list[str]]) -> str:
    """write the arrangement down, and say what happened for the page to show."""
    if not commands:
        return "there is nothing to remember yet"
    path = CONFIG_PATH
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps({"commands": commands}, indent=2) + "\n",
            encoding="utf-8",
        )
    except OSError as error:
        return f"could not write {path}: {error}"
    return f"remembered, in {path}"


def saved() -> list[list[str]]:
    """the commands from last time, or nothing if there are none."""
    try:
        held = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    commands = held.get("commands") if isinstance(held, dict) else None
    if not isinstance(commands, list):
        return []
    # and only the ones that are xrandr commands, because this file is read and run at every login
    # and a file that can hold anything is a file that runs anything
    return [
        [str(word) for word in command]
        for command in commands
        if isinstance(command, list)
        and command
        and command[0] == "xrandr"
        and all(isinstance(word, str) for word in command)
    ]


def apply_saved() -> str:
    """put the machine back the way the person left it. Called once, at the start of a session."""
    commands = saved()
    if not commands:
        return "nothing remembered"
    for command in commands:
        code, said = run(command)
        if code != 0:
            # the television from last time is not the television this time, and the layout for it
            # is not a fault. The machine keeps whatever the driver worked out and says so.
            return f"the remembered arrangement did not fit this screen: {said.strip()}"
    return f"put back {len(commands)} of the machine's own settings"
