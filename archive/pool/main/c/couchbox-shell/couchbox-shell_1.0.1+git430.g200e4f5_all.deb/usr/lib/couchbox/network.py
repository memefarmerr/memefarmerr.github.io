"""what this machine can connect to, and how it is asked.

The installer asks these questions once, while somebody is sitting in front of it, and then
copies the answers onto the disk. The settings application asks them again a year later and has
its own copy of this logic inside it, which should become this module: two implementations of
one rule drift, and the rule about where a wi-fi password goes is one that must not drift.

Two things here are the whole point of the module rather than a detail:

A wi-fi secret is never passed as an argument. It goes into a file with mode 0600 that nmcli
reads once and that is removed immediately afterwards, because an argument is in the process
list where every account on the machine can read it while the command runs.

And nothing here decides anything. It reports what is there - a cable, a wireless card, a
bluetooth adapter - and the screen decides what to ask, because "there is no wireless card" and
"there is one and it is switched off" are different sentences.
"""

from __future__ import annotations

import subprocess
import os
import tempfile
from pathlib import Path

NMCLI = "/usr/bin/nmcli"
BLUETOOTHCTL = "/usr/bin/bluetoothctl"
NET_CLASS = Path("/sys/class/net")
BLUETOOTH_CLASS = Path("/sys/class/bluetooth")

# long enough for nmcli to bring an adapter up and scan, short enough that a page which has
# stopped waiting is a page somebody can still press Back on
SHORT = 20
LONG = 45


def _run(command: list[str], timeout: int = SHORT) -> tuple[int, str]:
    try:
        result = subprocess.run(
            command, capture_output=True, text=True, timeout=timeout, check=False
        )
        return result.returncode, result.stdout
    except (OSError, subprocess.SubprocessError):
        return 1, ""


def _interfaces() -> list[Path]:
    try:
        return [
            path
            for path in NET_CLASS.iterdir()
            if path.name != "lo"
            and not path.name.startswith(("virbr", "docker", "veth", "br-", "tap", "tun"))
        ]
    except OSError:
        return []


def is_wireless(interface: Path) -> bool:
    return (interface / "wireless").exists()


def wireless_present() -> bool:
    """is there a wireless card at all, whatever it is doing."""
    return any(is_wireless(interface) for interface in _interfaces())


def wired_connected() -> bool:
    """is a cable in, and carrying.

    The carrier file is the kernel's own answer to whether the link is up, which is the question
    worth asking: a card that exists with no cable in it is not a network.
    """
    for interface in _interfaces():
        if is_wireless(interface):
            continue
        try:
            if (interface / "carrier").read_text().strip() == "1":
                return True
        except OSError:
            continue
    return False


def online() -> bool:
    """is there a default route, whatever kind of link it is on."""
    try:
        for line in Path("/proc/net/route").read_text().splitlines()[1:]:
            fields = line.split()
            if len(fields) > 2 and fields[1] == "00000000" and fields[2] != "00000000":
                return True
    except OSError:
        pass
    return False


def visible_networks() -> list[dict[str, str]]:
    """the wireless networks in range, best signal first, named once each."""
    if not Path(NMCLI).exists():
        return []
    code, output = _run([NMCLI, "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "device", "wifi", "list"])
    if code != 0:
        return []

    found: dict[str, dict[str, str]] = {}
    for line in output.splitlines():
        fields = line.split(":")
        if len(fields) < 4:
            continue
        in_use, ssid, signal, security = fields[0], fields[1], fields[2], fields[3]
        if not ssid or ssid in found:
            continue
        found[ssid] = {
            "ssid": ssid,
            "signal": signal,
            "security": "" if security in ("", "--") else security,
            "in_use": in_use.strip(),
        }
    return sorted(found.values(), key=lambda row: (-int(row["signal"] or 0), row["ssid"]))


def _secret_file(password: str) -> str:
    """write a wi-fi secret where nmcli can read it and nothing else can.

    The same arrangement the settings application uses, and the reason it exists: as an argument
    the password is in the process list for as long as the command runs.

    Where it goes is the session's own runtime directory, falling back to the temporary directory.
    It used to be written straight into `/run`, which is root's, so on the live image this failed
    with a permission error before nmcli was ever reached: the installer could not join a network
    and said "the password could not be prepared". A file with mode 0600 in a directory anybody can
    write to is still a file only its owner can read.
    """
    directory = os.environ.get("XDG_RUNTIME_DIR") or tempfile.gettempdir()
    handle, path = tempfile.mkstemp(prefix="couchbox-wifi-", dir=directory)
    try:
        os.fchmod(handle, 0o600)
        with os.fdopen(handle, "w", encoding="utf-8") as secrets:
            secrets.write(f"802-11-wireless-security.psk:{password}\n")
    except OSError:
        Path(path).unlink(missing_ok=True)
        raise
    return path


def join_command(ssid: str, secret: str = "") -> list[str]:
    """the nmcli command that joins a network, with or without a password.

    `passwd-file` is an argument of the connect command rather than an option of nmcli itself, and
    the difference is not cosmetic: given as an option, the nmcli in Debian 13 answers "Option
    '--passwd-file' is unknown" and refuses to run at all. Measured against the man page for the
    version the image ships, which is where the order below comes from.
    """
    command = [NMCLI, "device", "wifi", "connect", ssid]
    if secret:
        command += ["passwd-file", secret]
    return command


def join(ssid: str, password: str = "") -> tuple[bool, str]:
    """join a network, and say what happened in one short sentence."""
    if not Path(NMCLI).exists():
        return False, "there is no way to join a network on this machine"

    secret = ""
    command = join_command(ssid)
    if password:
        try:
            secret = _secret_file(password)
        except OSError as error:
            return False, f"the password could not be prepared: {error}"
        command = join_command(ssid, secret)

    try:
        code, _ = _run(command, timeout=LONG)
    finally:
        if secret:
            Path(secret).unlink(missing_ok=True)

    if code == 0:
        return True, f"joined {ssid}"
    return False, f"could not join {ssid}"


def bluetooth_present() -> bool:
    try:
        return any(BLUETOOTH_CLASS.iterdir())
    except OSError:
        return False


def bluetooth_devices() -> list[dict[str, str]]:
    """what a scan can see, as address and name, ignoring the ones already known."""
    if not Path(BLUETOOTHCTL).exists():
        return []
    _run([BLUETOOTHCTL, "--timeout", "12", "scan", "on"], timeout=SHORT)
    code, output = _run([BLUETOOTHCTL, "devices"], timeout=SHORT)
    if code != 0:
        return []

    found = []
    for line in output.splitlines():
        fields = line.split(" ", 2)
        if len(fields) >= 3 and fields[0] == "Device":
            found.append({"address": fields[1], "name": fields[2].strip()})
    return found


def pair(address: str) -> tuple[bool, str]:
    """pair with something, which is the long way round: pair, trust, connect."""
    if not Path(BLUETOOTHCTL).exists():
        return False, "there is no bluetooth on this machine"
    for verb, timeout in (("pair", LONG), ("trust", SHORT), ("connect", SHORT)):
        code, _ = _run([BLUETOOTHCTL, "--timeout", str(timeout), verb, address], timeout=timeout + 5)
        if code != 0 and verb == "pair":
            return False, "it did not want to pair"
    return True, "connected"
