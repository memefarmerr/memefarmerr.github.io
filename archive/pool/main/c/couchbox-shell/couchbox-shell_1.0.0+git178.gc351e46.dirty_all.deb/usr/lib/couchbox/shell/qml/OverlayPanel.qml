import QtQuick
import Couchbox 1.0

// the overlay's list, drawn once and worn by both places it appears: the dashboard, when the
// overlay opens over the dashboard, and a small window of its own, when it opens over a running
// application (ADR-0035).
//
// The rows come from the shell (`Shell.overlayActions`) and choosing one goes back to the shell
// (`Shell.overlayActivate`), so the two hosts cannot disagree about what a row does. What lives
// here is only how it looks and how the selection moves.
//
// The panel is a header and a list. The header says which machine this is - the name, the version,
// the network, the time - because the overlay is the one screen that is always one press away
// wherever the person is, and a console's overlay is where you glance to find out what you are
// on. The list underneath is what can be done from here.
//
// The rows are inside a Flickable, and the selection follows the view rather than the other way
// round. That is not decoration: the panel's height is what decides whether every row is reachable
// on a 720 high screen, and the rows it can hold changed when the quick settings were added. A
// list that silently became un-scrollable the next time a row was added is exactly the kind of
// fault that only shows up on the smallest screen the project supports.
Item {
    id: panel

    property var actions: []
    property int selection: 0
    property int unit: 10

    // how far in the panel has come: 0 before it is on screen, 1 when it has settled. The two
    // hosts animate it, because they arrive differently. Over the dashboard the whole layer fades
    // and this is what makes the panel settle a moment after the dim behind it; over a running
    // application the window cannot fade at all - an X server with no compositor ignores a
    // window's opacity - so this is the only part of that appearance that can be animated, and
    // without it the panel appears in one frame.
    property real reveal: 1

    // what the header says about the machine. Empty strings are dropped rather than drawn, so a
    // machine with no network shows no network rather than an empty space
    property string machineLine: ""
    property string versionLine: ""
    property string clockLine: ""

    // the panel is deliberately compact: its height is what decides whether every row it holds
    // is reachable on a 720 high screen, so the padding and the per-row room are the smallest
    // that still read from a couch
    readonly property int padding: unit * 1.4
    readonly property int itemHeight: unit * 3.6
    readonly property int headerRowHeight: unit * 2.0

    readonly property Item column: rows

    implicitHeight: header.implicitHeight + padding * 2 + scroller.contentHeight

    ConsolePalette {
        id: colors
    }

    // the selection only ever lands on something that can be chosen: a heading is not a
    // destination, and landing on one would mean a press that did nothing
    function firstSelectable() {
        for (let i = 0; i < panel.actions.length; ++i) {
            if (panel.actions[i].kind !== "header") {
                return i;
            }
        }
        return 0;
    }

    function move(step) {
        if (panel.actions.length === 0) {
            return;
        }
        let next = panel.selection;
        for (let tried = 0; tried < panel.actions.length; ++tried) {
            next = (next + step + panel.actions.length) % panel.actions.length;
            if (panel.actions[next].kind !== "header") {
                panel.selection = next;
                panel.reveal();
                return;
            }
        }
    }

    function activate(index) {
        const item = panel.actions[index];
        if (!item || item.kind === "header") {
            return;
        }
        Shell.overlayActivate(index);
    }

    // keep the chosen row inside the panel, moving the view as little as it takes. This is what
    // makes the panel safe to grow: without it, a row added below the fold is a row nobody can
    // reach, and it fails on the smallest screen rather than the largest
    function reveal() {
        const row = rows.children[panel.selection];
        if (!row) {
            return;
        }
        const top = row.y;
        const bottom = row.y + row.height;
        if (top < scroller.contentY) {
            scroller.contentY = top;
        } else if (bottom > scroller.contentY + scroller.height) {
            scroller.contentY = bottom - scroller.height;
        }
    }

    onSelectionChanged: reveal()

    Rectangle {
        anchors.fill: parent
        radius: panel.unit * 0.8
        color: colors.surface
        border.color: colors.border
        border.width: 1
        opacity: panel.reveal

        Column {
            anchors.fill: parent
            anchors.margins: panel.padding
            spacing: panel.unit * 0.8
            opacity: panel.reveal

            // a few pixels of settle, from below, so that the rows arrive rather than being
            // switched on. A transform rather than a margin, because a margin would move the
            // layout and make the rows re-measure while the animation runs
            transform: Translate {
                y: (1 - panel.reveal) * panel.unit * 1.2
            }

            // --- the header: whose machine this is, and what it is doing ---------

            Item {
                id: header

                width: parent.width
                implicitHeight: Math.max(left.implicitHeight, right.implicitHeight)

                Column {
                    id: left

                    anchors.left: parent.left
                    anchors.top: parent.top
                    spacing: panel.unit * 0.1

                    Text {
                        text: "Couchbox"
                        color: colors.dim
                        font.pixelSize: Math.round(panel.unit * 1.15)
                        font.capitalization: Font.AllUppercase
                        font.letterSpacing: panel.unit * 0.12
                    }

                    Text {
                        visible: panel.versionLine !== ""
                        text: panel.versionLine === "" ? "" : "version " + panel.versionLine
                        color: colors.faint
                        font.pixelSize: Math.round(panel.unit * 1.0)
                    }
                }

                Column {
                    id: right

                    anchors.right: parent.right
                    anchors.top: parent.top
                    spacing: panel.unit * 0.1

                    Text {
                        anchors.right: parent.right
                        visible: panel.clockLine !== ""
                        text: panel.clockLine
                        color: colors.text
                        font.pixelSize: Math.round(panel.unit * 1.5)
                        font.bold: true
                    }

                    Text {
                        anchors.right: parent.right
                        visible: panel.machineLine !== ""
                        text: panel.machineLine
                        color: colors.dim
                        font.pixelSize: Math.round(panel.unit * 1.05)
                        elide: Text.ElideRight
                        width: Math.min(implicitWidth, panel.width * 0.5)
                        horizontalAlignment: Text.AlignRight
                    }
                }

                // one hairline, so the list reads as separate from the header without a box
                Rectangle {
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.bottom: parent.bottom
                    anchors.bottomMargin: -panel.unit * 0.4
                    height: 1
                    color: colors.border
                }
            }

            // --- the rows --------------------------------------------------------

            Flickable {
                id: scroller

                width: parent.width
                height: Math.min(rows.implicitHeight, panel.maximumListHeight())
                contentWidth: width
                contentHeight: rows.implicitHeight
                interactive: false
                clip: true
                boundsBehavior: Flickable.StopAtBounds

                Column {
                    id: rows

                    width: scroller.width
                    spacing: panel.unit * 0.35

                    Repeater {
                        model: panel.actions

                        delegate: Rectangle {
                            id: overlayRow

                            required property var modelData
                            required property int index

                            readonly property bool chosen: index === panel.selection
                            readonly property bool heading: modelData.kind === "header"

                            // most rows are title-only, and a detail that is absent rather than
                            // empty must not become a line of text. when one is present it is
                            // drawn here as the single elided line the row gives it
                            readonly property string detailText: {
                                const given = overlayRow.modelData.detail;
                                return given === undefined || given === null ? "" : String(given);
                            }

                            width: rows.width
                            height: heading ? panel.headerRowHeight : panel.itemHeight
                            radius: panel.unit * 0.5
                            color: overlayRow.heading || !overlayRow.chosen
                                    ? "transparent"
                                    : colors.surfaceFocused
                            border.width: !overlayRow.heading && overlayRow.chosen
                                    ? Math.max(1, Math.round(panel.unit * 0.12))
                                    : 0
                            border.color: colors.accent

                            // the row fills in rather than switching, so moving down the list is
                            // something the eye follows
                            Behavior on color {
                                ColorAnimation {
                                    duration: 120
                                }
                            }

                            // the accent bar down the left of the chosen row, which is what makes
                            // the choice readable from a couch even when the row itself is dim
                            Rectangle {
                                anchors.left: parent.left
                                anchors.top: parent.top
                                anchors.bottom: parent.bottom
                                anchors.leftMargin: panel.unit * 0.35
                                anchors.topMargin: panel.unit * 0.5
                                anchors.bottomMargin: panel.unit * 0.5
                                width: Math.max(2, Math.round(panel.unit * 0.28))
                                radius: width / 2
                                color: colors.accent
                                opacity: !overlayRow.heading && overlayRow.chosen ? 1 : 0

                                Behavior on opacity {
                                    NumberAnimation { duration: 120 }
                                }
                            }

                            Text {
                                id: rowTitle

                                anchors.left: parent.left
                                anchors.right: rowDetail.left
                                anchors.leftMargin: panel.unit * 1.3
                                anchors.rightMargin: panel.unit * 1.2
                                anchors.verticalCenter: parent.verticalCenter
                                text: overlayRow.modelData.title === undefined
                                    ? ""
                                    : overlayRow.modelData.title
                                color: overlayRow.heading ? colors.faint : colors.text
                                font.pixelSize: Math.round(
                                    panel.unit * (overlayRow.heading ? 0.95 : 1.5))
                                font.bold: !overlayRow.heading && overlayRow.chosen
                                font.capitalization: overlayRow.heading
                                    ? Font.AllUppercase
                                    : Font.MixedCase
                                elide: Text.ElideRight
                            }

                            Text {
                                id: rowDetail

                                anchors.right: parent.right
                                anchors.rightMargin: panel.unit * 1.3
                                anchors.verticalCenter: parent.verticalCenter
                                visible: !overlayRow.heading && overlayRow.detailText !== ""
                                text: overlayRow.detailText
                                color: colors.accent
                                font.pixelSize: Math.round(panel.unit * 1.2)
                                elide: Text.ElideRight
                                width: Math.min(implicitWidth, panel.width * 0.35)
                                horizontalAlignment: Text.AlignRight
                            }

                            // a mouse can click a row, which costs one handler and is never the
                            // only way to do anything
                            MouseArea {
                                anchors.fill: parent
                                enabled: !overlayRow.heading
                                onClicked: {
                                    panel.selection = overlayRow.index;
                                    panel.activate(overlayRow.index);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // how tall the list may be: the panel is given a height by its host and this is what is left
    // of it after the header and the padding. Not being able to ask the host directly is why this
    // is a function on the panel rather than a number computed by the caller
    function maximumListHeight() {
        const available = panel.height - panel.padding * 2 - header.implicitHeight - panel.unit * 0.8;
        return Math.max(panel.itemHeight, available);
    }
}
